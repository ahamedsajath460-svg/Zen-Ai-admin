# Zen AI + Zen Admin Studio — build and release status

Updated: 2026-11-26

## Confirmed from supplied source/configuration
- Both supplied source ZIPs were extracted and inspected.
- Firebase project ID in the supplied Android configuration is `own-project-bdeee` (project number `164047180415`).
- The supplied multi-client `google-services.json` includes `com.a2z.ai` and `com.aistudio.zenadmin.kxqmzp`.
- The Admin Studio module contains Firebase Auth and Firestore dependencies, an email/password sign-in repository, a Cloud Functions backend source tree, Firestore rules and indexes, and deployment documentation.
- The supplied screenshots show Email/Password and Google providers enabled and a default Firestore database with a `users` collection.
- A GitHub Actions workflow was added at `.github/workflows/build-zen-admin-apk.yml`. It validates the Admin Firebase client config, runs unit tests, builds the debug APK, and uploads the APK as a workflow artifact.

## Not completed (do not treat this package as production-ready)
- Local APK build was attempted with `./gradlew :app:assembleDebug`; it could not start because this environment cannot resolve `services.gradle.org` to download the required Gradle 9.3.1 distribution (`UnknownHostException`). No APK was produced here.
- The GitHub Actions workflow has been authored but has not been run; its successful build is not yet verified.
- Firebase Cloud Functions and Firestore rules/indexes have not been deployed to the user's Firebase project.
- The first Super Admin bootstrap still requires the owner to set `ZEN_BOOTSTRAP_SUPER_ADMIN_EMAIL` in the trusted Functions runtime and deploy the backend.
- Google sign-in is enabled in Firebase Console but the Admin Studio source currently implements Email/Password sign-in only.
- Release APK signing cannot be completed without the owner's existing private release keystore and passwords. A debug keystore is not a release signing key.
- Live Firebase authentication, admin-role bootstrap, device testing, and end-to-end dashboard operations remain unverified.

## Required user-side handoff
1. Upload this workspace to the intended GitHub repository, preserving `.github/workflows/build-zen-admin-apk.yml` at repository root.
2. Run **Actions → Build Zen Admin Studio APK → Run workflow**.
3. If the workflow succeeds, download the `zen-admin-studio-debug` artifact. This is a debug APK for testing, not a Play Store/release APK.
4. Deploy Firebase rules/functions only after reviewing the deployment guide and setting the bootstrap allowlist securely.
5. Configure release signing with the owner's existing private keystore in GitHub Actions secrets before producing a release APK.

## Safety
- Do not place Firebase service-account JSON, provider API keys, GitHub tokens, or private signing keys in this ZIP or Android source.
- Do not manually create administrator role documents from the client. The backend is intended to issue and synchronize claims.
- Existing Zen AI source is retained in this workspace; the Admin Studio integration is a separate Android application.
