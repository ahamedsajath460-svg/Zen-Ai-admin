# Zen AI Super Admin Control Studio — Security Architecture

## 1. Zero-Trust Trust Boundaries
- **No Client-Side Privilege Trust**: Client UI role gating (`AdminPermission`) is strictly a presentation convenience. Authoritative authorization runs inside `backend/firestore.rules` and `backend/functions/src/index.ts` via verified Firebase ID tokens + `adminRole` custom claims + `admin_roles/{uid}` server document checks.
- **No Secrets in APK**: Provider API keys, GitHub signing keys, and Firebase service account credentials are never packaged into `BuildConfig`, `.env`, or APK resources. Server-side key rotation transmits keys over TLS directly to Google Cloud Secret Manager and returns only masked previews (`sk-ab••••xy12`).

## 2. Device-Side Cryptographic Protection
- **Android Keystore (`KeystoreCryptoManager`)**: Generates a 256-bit `AES/GCM/NoPadding` key inside `AndroidKeyStore` (`zen_super_admin_vault_key_v1`) to encrypt optional operator tokens in DataStore.
- **PBKDF2 Passphrase Vault (`AdminSessionManager`)**: Administrator passphrases are salted (16-byte `SecureRandom`) and hashed with 120,000 rounds of `PBKDF2WithHmacSHA256` with constant-time digest comparison (`MessageDigest.isEqual`).
- **Sensitive Action Re-Authentication**: Destructive or high-impact mutations (user deletion/suspension, emergency AI provider shutdown, key rotation, workflow dispatch/cancellation, FCM campaigns, and RBAC role changes) require live passphrase re-authentication via `ReAuthConfirmationDialog`.
- **Backup Exclusion**: `android:allowBackup="false"` prevents cloud OS backup extraction of local vault state.

## 3. Privacy & Audit Immutability
- **Chat Privacy Isolation**: `backend/firestore.rules` blocks administrator read access to `/users/{userId}/conversations/...`. Administrators inspect metadata counts only.
- **Immutable Audit Logs**: `ZenAdminDao` exposes insert-only audit methods locally (`OnConflictStrategy.ABORT`), and `firestore.rules` sets `allow write: if false` on `/audit_logs/{logId}` and `/security_events/{eventId}` so only Cloud Functions can append server-verified records.
