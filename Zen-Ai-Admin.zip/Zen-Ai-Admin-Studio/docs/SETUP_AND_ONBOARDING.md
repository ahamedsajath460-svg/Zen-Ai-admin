# Zen AI Super Admin Control Studio — Setup & Onboarding Guide

## 1. Independent Application Identity
- **Application ID**: `com.aistudio.zenadmin.kxqmzp`
- **App Name**: `Zen Admin`
- **Architecture**: Standalone native Android app (Kotlin + Jetpack Compose + Room + Android Keystore + Retrofit) designed to administer an existing Zen AI Firebase ecosystem remotely without requiring `Zen-Ai.zip` or modifying the Zen AI client app.

## 2. Current Provisioning Status
- Firebase provisioning in AI Studio was **declined** during setup, so:
  - No `google-services.json` is bundled in `app/`.
  - Live Firebase Auth, Firestore, FCM, and Gemini via Firebase AI Logic are inactive until Firebase is enabled and deployed.
  - The AI Admin Assistant runs through `PlaceholderAdminAiRepository` with clearly labeled diagnostic sample outputs and no embedded API keys.
  - **GitHub Control** (`GitHubApiService`) works immediately for public repositories via GitHub REST API v3, and supports Keystore-encrypted tokens for private repositories and workflow dispatches.

## 3. Deploying the Included Firebase Backend (`backend/`)
1. **Select your existing Zen AI Firebase project**:
   ```bash
   firebase use <your-zen-ai-firebase-project-id>
   ```
2. **Deploy hardened Firestore Security Rules & Composite Indexes**:
   ```bash
   firebase deploy --only firestore:rules,firestore:indexes --project <your-zen-ai-firebase-project-id>
   ```
3. **Bootstrap the initial Super Admin custom claim** (server-side only via Firebase Admin SDK):
   ```js
   await admin.auth().setCustomUserClaims(superAdminUid, { adminRole: "SUPER_ADMIN" });
   await db.collection("admin_roles").doc(superAdminUid).set({
     uid: superAdminUid,
     email: "owner@your-domain.com",
     displayName: "Owner",
     role: "SUPER_ADMIN",
     mfaEnabled: true,
     status: "active",
     updatedAt: admin.firestore.FieldValue.serverTimestamp(),
   });
   ```
4. **Deploy Cloud Functions API Proxy**:
   ```bash
   cd backend/functions && npm install && npm run build && firebase deploy --only functions
   ```
5. **Configure Secrets Server-Side**:
   - Store AI provider API keys (`Gemini`, `OpenAI`, `Claude`, `DeepSeek`, `Groq`, `OpenRouter`, `Mistral`, `Together AI`, `Pollinations`, `Tavily`) in Google Cloud Secret Manager via the `POST /admin/providers/:providerId/rotate-key` endpoint or `gcloud secrets create`.
   - Never store privileged API keys or GitHub signing secrets inside the Android APK.

## 4. Connecting the Admin Studio APK
1. Launch **Zen Admin** and create your local hardware-backed **Super Admin Vault** passphrase.
2. Open **Settings**:
   - Paste your deployed Cloud Functions HTTPS Base URL (`https://us-central1-<project>.cloudfunctions.net/api`).
   - Enter your Zen AI Firebase Project ID and GitHub `owner` + `repo`.
   - Save & Sync to probe backend health and stream live telemetry.
3. To enable live Gemini AI Admin Assistant inside the Android app, re-enable Firebase setup in AI Studio so Firebase AI Logic and App Check are provisioned.
