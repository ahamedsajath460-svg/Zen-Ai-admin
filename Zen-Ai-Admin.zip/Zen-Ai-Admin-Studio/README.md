# Zen AI Admin Control Studio

Native Android Super Admin Control Studio for the existing Zen AI Firebase project.

## Firebase project
- Project: `own-project-bdeee`
- Android application ID: `com.aistudio.zenadmin.kxqmzp`
- Firebase Auth: Email/Password
- Firestore: existing `(default)` database and `users` collection

## Build
Open this folder in Android Studio, or use `./gradlew assembleDebug` in a Gradle-enabled environment. The project includes its Gradle wrapper.

## Firebase deployment
Read [FIREBASE_DEPLOYMENT.md](FIREBASE_DEPLOYMENT.md) before deploying. The Android source is configured for Firebase Auth and Firestore; Cloud Functions and Firestore rules must be deployed separately.

## Security
Never commit service-account credentials, provider API keys, GitHub tokens, or private signing keys. The local Android vault is not an administrator identity provider. Firebase custom claims and `/admin_roles` are authoritative.
