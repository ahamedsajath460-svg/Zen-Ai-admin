# Zen Admin Studio — Firebase connection and secure bootstrap

## Connected project
- Firebase project ID: `own-project-bdeee`
- Project number: `164047180415`
- Admin Android application ID: `com.aistudio.zenadmin.kxqmzp`
- `app/google-services.json` contains both registered Android clients from the supplied multi-client Firebase configuration.

## What is integrated in this source
- Google Services Gradle plugin and Firebase BoM.
- Firebase Authentication (Email/Password) and Cloud Firestore Android SDK.
- Admin sign-in validates a verified Firebase email, the `adminRole` custom claim, and a matching `/admin_roles/{uid}` document before unlocking the local Android Keystore vault.
- The local vault no longer creates or grants a Super Admin role by itself.
- Cloud Functions API checks token revocation, verified email, role claim, role document status, role consistency, and expiry.
- One-time Super Admin bootstrap and Super Admin-only role assignment endpoints.
- Firestore rules and indexes are wired to Firebase CLI deployment configuration.

## Required one-time Firebase Console setup
1. Ensure Email/Password is enabled in Authentication (the supplied screenshot showed it enabled).
2. Create the first administrator account in Firebase Authentication and verify its email. Do not grant admin rights by writing Firestore from the client.
3. Install Node.js 20 and Firebase CLI in a trusted build/deployment environment.
4. In `backend/functions`, run `npm install` and `npm run build`.
5. Configure the Functions runtime environment variable `ZEN_BOOTSTRAP_SUPER_ADMIN_EMAIL` to the exact verified email of the first administrator. Do not commit this value to source control.
6. Deploy Firestore rules/indexes and Functions using `firebase deploy --only firestore:rules,firestore:indexes,functions`.
7. Open Admin Studio and sign in with that account. If the account has no admin claim yet, the app attempts the one-time bootstrap endpoint. The endpoint rejects every email except the verified allowlisted address and rejects all calls after the first admin role is created.
8. The app refreshes the Firebase ID token and verifies the `adminRole=SUPER_ADMIN` claim against `/admin_roles/{uid}` before opening the dashboard.
9. After bootstrap, remove/unset `ZEN_BOOTSTRAP_SUPER_ADMIN_EMAIL` from the Functions runtime configuration. The endpoint will also reject future calls once an admin role exists.

## Important security notes
- `google-services.json` contains a Firebase client API key and app identifiers; it is normal Android client configuration, not a server credential. Never add service-account JSON, private keys, GitHub PATs, provider API keys, or Secret Manager credentials to the Android app or repository.
- Do not manually create `/admin_roles` documents or set client-side role fields. Admin roles are assigned only by the trusted Cloud Functions API.
- The app currently uses Email/Password administrator sign-in. Google provider is enabled in Firebase, but Google Credential Manager sign-in has not yet been wired into this admin source.
- The AI Admin Assistant remains a clearly marked placeholder until Firebase AI Logic is separately configured.
- Deploying backend code and setting Functions runtime configuration require a trusted deployment environment; packaging this source ZIP does not deploy cloud resources automatically.
