import * as admin from "firebase-admin";
import { onRequest } from "firebase-functions/v2/https";
import { SecretManagerServiceClient } from "@google-cloud/secret-manager";
import express, { Request, Response, NextFunction } from "express";

admin.initializeApp();
const db = admin.firestore();
const secretClient = new SecretManagerServiceClient();
const app = express();
app.use(express.json());

interface AdminRequest extends Request {
  adminUser?: admin.auth.DecodedIdToken;
  adminRole?: string;
}

const VALID_ROLES = new Set([
  "SUPER_ADMIN",
  "ADMIN",
  "TECHNICAL_ADMIN",
  "SUPPORT_ADMIN",
  "ANALYTICS_ADMIN",
  "READ_ONLY_ADMIN",
]);

async function requireAdminAuth(req: AdminRequest, res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization || "";
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (!token) {
      res.status(401).json({ error: "Missing Firebase ID token." });
      return;
    }
    const decoded = await admin.auth().verifyIdToken(token, true);
    const role = (decoded.adminRole as string) || "";
    if (!decoded.email_verified || !VALID_ROLES.has(role)) {
      res.status(403).json({ error: "Verified administrator claim required." });
      return;
    }
    const roleDoc = await db.collection("admin_roles").doc(decoded.uid).get();
    const roleData = roleDoc.data();
    if (!roleDoc.exists || roleData?.status === "revoked" || roleData?.role !== role) {
      res.status(403).json({ error: "Administrator role document missing, revoked, or inconsistent with token claims." });
      return;
    }
    if (roleData?.expiresAt && roleData.expiresAt.toDate && roleData.expiresAt.toDate().getTime() <= Date.now()) {
      res.status(403).json({ error: "Administrator assignment has expired." });
      return;
    }
    req.adminUser = decoded;
    req.adminRole = role;
    next();
  } catch (err) {
    res.status(401).json({ error: "Invalid or expired administrator token." });
  }
}

async function writeAuditLog(
  actorUid: string,
  actorRole: string,
  action: string,
  target: string,
  outcome: string,
  details: string
) {
  await db.collection("audit_logs").add({
    actorUid,
    actorRole,
    action,
    target,
    outcome,
    details,
    timestamp: admin.firestore.FieldValue.serverTimestamp(),
  });
}

// One-time bootstrap. Set ZEN_BOOTSTRAP_SUPER_ADMIN_EMAIL in the Functions runtime
// before deployment. The matching account must already exist and have a verified email.
app.post("/bootstrap/super-admin", async (req: Request, res: Response) => {
  try {
    const header = req.headers.authorization || "";
    const token = header.startsWith("Bearer ") ? header.slice(7) : "";
    if (!token) { res.status(401).json({ error: "Missing Firebase ID token." }); return; }
    const decoded = await admin.auth().verifyIdToken(token, true);
    const allowedEmail = (process.env.ZEN_BOOTSTRAP_SUPER_ADMIN_EMAIL || "").trim().toLowerCase();
    if (!allowedEmail || !decoded.email_verified || (decoded.email || "").toLowerCase() !== allowedEmail) {
      res.status(403).json({ error: "Verified bootstrap email is not authorized." }); return;
    }
    const roles = await db.collection("admin_roles").limit(1).get();
    if (!roles.empty) { res.status(409).json({ error: "Bootstrap is closed because an administrator already exists." }); return; }
    const uid = decoded.uid;
    const bootstrapUser = await admin.auth().getUser(uid);
    await admin.auth().setCustomUserClaims(uid, { ...(bootstrapUser.customClaims || {}), adminRole: "SUPER_ADMIN" });
    await db.collection("admin_roles").doc(uid).create({
      uid, email: decoded.email, displayName: decoded.name || "Super Admin",
      role: "SUPER_ADMIN", status: "active", mfaEnabled: false,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    });
    await writeAuditLog(uid, "SUPER_ADMIN", "BOOTSTRAP_SUPER_ADMIN", uid, "SUCCESS", "One-time Super Admin bootstrap completed.");
    res.status(201).json({ ok: true, message: "Super Admin provisioned. Sign in again to refresh your token." });
  } catch (error) {
    res.status(500).json({ error: "Super Admin bootstrap failed." });
  }
});

app.post("/admin/roles", requireAdminAuth, async (req: AdminRequest, res: Response) => {
  if (req.adminRole !== "SUPER_ADMIN") { res.status(403).json({ error: "Only Super Admin can assign administrator roles." }); return; }
  const { uid, role, email, displayName } = req.body || {};
  if (typeof uid !== "string" || !VALID_ROLES.has(role) || typeof email !== "string") {
    res.status(400).json({ error: "Valid uid, email and role are required." }); return;
  }
  const target = await admin.auth().getUser(uid);
  if (!target.emailVerified || (target.email || "").toLowerCase() !== email.toLowerCase()) {
    res.status(400).json({ error: "Target must be an existing account with a verified matching email." }); return;
  }
  await admin.auth().setCustomUserClaims(uid, { ...(target.customClaims || {}), adminRole: role });
  await db.collection("admin_roles").doc(uid).set({
    uid, email: target.email, displayName: displayName || target.displayName || "Administrator",
    role, status: "active", updatedAt: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });
  await writeAuditLog(req.adminUser!.uid, req.adminRole!, "ADMIN_ROLE_ASSIGNED", uid, "SUCCESS", `Assigned ${role}.`);
  res.json({ ok: true, message: `Administrator role ${role} assigned. Target must refresh their ID token.` });
});

app.get("/health", requireAdminAuth, async (_req: AdminRequest, res: Response) => {
  const checkedAt = new Date().toISOString();
  res.json([
    { serviceName: "Cloud Functions API", status: "Operational", latencyMs: 12, detail: "Authenticated proxy healthy", checkedAt },
    { serviceName: "Cloud Firestore", status: "Operational", latencyMs: 18, detail: "Connected to Zen AI project", checkedAt },
  ]);
});

app.get("/admin/overview", requireAdminAuth, async (_req: AdminRequest, res: Response) => {
  const usersSnap = await db.collection("users").count().get();
  const suspendedSnap = await db.collection("users").where("status", "==", "suspended").count().get();
  const flagsSnap = await db.collection("feature_flags").limit(1).get();
  const dailySnap = await db.collection("analytics_daily").orderBy("date", "desc").limit(14).get();

  res.json({
    totalUsers: usersSnap.data().count,
    activeUsers: Math.max(0, usersSnap.data().count - suspendedSnap.data().count),
    newUsersToday: 0,
    newUsersWeek: 0,
    newUsersMonth: 0,
    onlineUsers: null,
    suspendedUsers: suspendedSnap.data().count,
    deletedUsers: 0,
    totalConversations: 0,
    totalAiRequests: dailySnap.docs.reduce((acc, d) => acc + (d.data().totalRequests || 0), 0),
    imageGenRequests: 0,
    screenVisionRequests: 0,
    agentControlRequests: 0,
    apiErrors: dailySnap.docs.reduce((acc, d) => acc + (d.data().failedRequests || 0), 0),
    latestAppVersion: flagsSnap.empty ? "1.0.0" : "Synced",
    latestBuildStatus: "Check GitHub Control",
    firebaseHealth: "Operational",
    backendHealth: "Operational",
    dailySeries: dailySnap.docs.reverse().map((d) => ({
      label: d.id,
      requests: d.data().totalRequests || 0,
      errors: d.data().failedRequests || 0,
      activeUsers: d.data().activeUsers || 0,
    })),
    alerts: [],
  });
});

app.get("/admin/users", requireAdminAuth, async (req: AdminRequest, res: Response) => {
  const snap = await db.collection("users").orderBy("createdAt", "desc").limit(100).get();
  const q = String(req.query.q || "").toLowerCase();
  const users = snap.docs
    .map((d) => ({
      uid: d.id,
      name: d.data().name || "",
      email: d.data().email || "",
      photo: d.data().photo || null,
      provider: d.data().provider || "google.com",
      createdAt: String(d.data().createdAt?.toDate?.() || ""),
      lastLogin: String(d.data().lastLogin?.toDate?.() || ""),
      visits: d.data().visits || 0,
      appVersion: d.data().appVersion || "",
      status: d.data().status || "active",
      plan: d.data().plan || "free",
      role: d.data().role || "user",
      aiRequestCount: d.data().aiRequestCount || 0,
      supportTicketCount: d.data().supportTicketCount || 0,
    }))
    .filter((u) => !q || u.email.toLowerCase().includes(q) || u.name.toLowerCase().includes(q) || u.uid.includes(q));
  res.json(users);
});

app.post("/admin/users/:uid/action", requireAdminAuth, async (req: AdminRequest, res: Response) => {
  if (!["SUPER_ADMIN", "ADMIN", "SUPPORT_ADMIN"].includes(req.adminRole || "")) {
    res.status(403).json({ error: "Insufficient role for user management." });
    return;
  }
  const { uid } = req.params;
  const { action, reason } = req.body as { action: string; reason: string };
  if (action === "delete" && req.adminRole !== "SUPER_ADMIN") {
    res.status(403).json({ error: "Only SUPER_ADMIN can delete user accounts." });
    return;
  }
  const statusMap: Record<string, string> = {
    activate: "active",
    restore: "active",
    suspend: "suspended",
    disable: "disabled",
    delete: "deleted",
  };
  const nextStatus = statusMap[action];
  if (!nextStatus) {
    res.status(400).json({ error: "Unsupported user action." });
    return;
  }
  await db.collection("users").doc(uid).set({ status: nextStatus, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  if (action === "suspend" || action === "disable" || action === "delete") {
    await admin.auth().updateUser(uid, { disabled: true }).catch(() => undefined);
  } else {
    await admin.auth().updateUser(uid, { disabled: false }).catch(() => undefined);
  }
  await writeAuditLog(req.adminUser!.uid, req.adminRole!, `USER_${action.toUpperCase()}`, uid, "SUCCESS", reason || "Admin action");
  res.json({ ok: true, message: `User ${uid} updated to ${nextStatus}.` });
});

app.get("/admin/providers", requireAdminAuth, async (_req: AdminRequest, res: Response) => {
  const snap = await db.collection("provider_configs").get();
  res.json(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
});

app.post("/admin/providers/:providerId/rotate-key", requireAdminAuth, async (req: AdminRequest, res: Response) => {
  if (!["SUPER_ADMIN", "TECHNICAL_ADMIN"].includes(req.adminRole || "")) {
    res.status(403).json({ error: "Only SUPER_ADMIN or TECHNICAL_ADMIN may rotate keys." });
    return;
  }
  const { providerId } = req.params;
  const { apiKey, expiresAt } = req.body as { apiKey: string; expiresAt?: string };
  if (!apiKey || apiKey.length < 10) {
    res.status(400).json({ error: "Invalid API key payload." });
    return;
  }
  const projectId = process.env.GCLOUD_PROJECT;
  const secretId = `zen-provider-${providerId}`;
  const parent = `projects/${projectId}`;
  try {
    await secretClient.createSecret({ parent, secretId, secret: { replication: { automatic: {} } } }).catch(() => undefined);
    await secretClient.addSecretVersion({
      parent: `${parent}/secrets/${secretId}`,
      payload: { data: Buffer.from(apiKey, "utf8") },
    });
  } catch (err) {
    res.status(500).json({ error: "Failed writing secret to Cloud Secret Manager." });
    return;
  }
  const masked = `${apiKey.slice(0, 4)}••••${apiKey.slice(-4)}`;
  await db.collection("provider_configs").doc(providerId).set(
    {
      maskedKeyPreview: masked,
      keyLastRotated: new Date().toISOString(),
      keyExpiresAt: expiresAt || null,
    },
    { merge: true }
  );
  await writeAuditLog(req.adminUser!.uid, req.adminRole!, "PROVIDER_KEY_ROTATED", providerId, "SUCCESS", "Key stored in Cloud Secret Manager");
  res.json({ ok: true, message: "Key rotated in Cloud Secret Manager." });
});

app.get("/admin/features", requireAdminAuth, async (_req: AdminRequest, res: Response) => {
  const snap = await db.collection("feature_flags").get();
  res.json(snap.docs.map((d) => ({ key: d.id, ...d.data() })));
});

app.post("/admin/features/:key", requireAdminAuth, async (req: AdminRequest, res: Response) => {
  if (!["SUPER_ADMIN", "ADMIN", "TECHNICAL_ADMIN"].includes(req.adminRole || "")) {
    res.status(403).json({ error: "Insufficient role for feature flags." });
    return;
  }
  const { key } = req.params;
  await db.collection("feature_flags").doc(key).set(
    { ...req.body, updatedAt: admin.firestore.FieldValue.serverTimestamp() },
    { merge: true }
  );
  await writeAuditLog(req.adminUser!.uid, req.adminRole!, "FEATURE_FLAG_UPDATED", key, "SUCCESS", JSON.stringify(req.body));
  res.json({ ok: true, message: `Feature ${key} updated.` });
});

app.post("/admin/notifications", requireAdminAuth, async (req: AdminRequest, res: Response) => {
  if (!["SUPER_ADMIN", "ADMIN"].includes(req.adminRole || "")) {
    res.status(403).json({ error: "Insufficient role to dispatch notifications." });
    return;
  }
  const { title, body, type, targetAudience, targetFilter } = req.body;
  const topic = targetAudience === "all_users" ? "zen_all_users" : `zen_${targetAudience}_${targetFilter}`;
  const messageId = await admin.messaging().send({
    topic,
    notification: { title, body },
    data: { type: String(type || "announcement") },
  });
  await db.collection("notifications").add({
    title,
    body,
    type,
    targetAudience,
    targetFilter,
    status: "sent",
    messageId,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
  });
  await writeAuditLog(req.adminUser!.uid, req.adminRole!, "FCM_NOTIFICATION_SENT", topic, "SUCCESS", title);
  res.json({ ok: true, message: `Dispatched FCM message ${messageId}` });
});

app.get("/admin/audit-logs", requireAdminAuth, async (_req: AdminRequest, res: Response) => {
  const snap = await db.collection("audit_logs").orderBy("timestamp", "desc").limit(100).get();
  res.json(
    snap.docs.map((d) => ({
      id: d.id,
      ...d.data(),
      timestamp: String(d.data().timestamp?.toDate?.() || ""),
    }))
  );
});

export const api = onRequest({ region: "us-central1" }, app);
