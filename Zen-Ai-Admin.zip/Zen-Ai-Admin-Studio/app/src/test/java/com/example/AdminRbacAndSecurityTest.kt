package com.example

import com.example.core.ai.AdminContextSnapshot
import com.example.core.ai.PlaceholderAdminAiRepository
import com.example.core.database.WorkspaceConfigEntity
import com.example.core.model.AdminPermission
import com.example.core.model.AdminRole
import com.example.core.model.ConnectionMode
import com.example.core.network.NetworkClientFactory
import com.example.ui.navigation.AdminModule
import kotlinx.coroutines.flow.last
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AdminRbacAndSecurityTest {

    @Test
    fun `rbac matrix enforces least privilege across all 6 roles`() {
        assertTrue(AdminRole.SUPER_ADMIN.permissions.containsAll(AdminPermission.entries))
        assertFalse(AdminRole.ADMIN.permissions.contains(AdminPermission.MANAGE_ROLES))
        assertFalse(AdminRole.ADMIN.permissions.contains(AdminPermission.MANAGE_PROVIDERS))
        assertTrue(AdminRole.TECHNICAL_ADMIN.permissions.contains(AdminPermission.MANAGE_GITHUB))
        assertFalse(AdminRole.SUPPORT_ADMIN.permissions.contains(AdminPermission.MANAGE_BACKUPS))
        assertFalse(AdminRole.READ_ONLY_ADMIN.permissions.contains(AdminPermission.MANAGE_USERS))
        assertFalse(AdminRole.READ_ONLY_ADMIN.permissions.contains(AdminPermission.MANAGE_FEATURES))
        assertTrue(AdminRole.READ_ONLY_ADMIN.permissions.contains(AdminPermission.VIEW_AUDIT_LOGS))
    }

    @Test
    fun `all 18 navigation modules are registered with unique routes`() {
        assertEquals(18, AdminModule.entries.size)
        val uniqueRoutes = AdminModule.entries.map { it.route }.toSet()
        assertEquals(18, uniqueRoutes.size)
    }

    @Test
    fun `network factory rejects plaintext http URLs and accepts https`() {
        assertNull(NetworkClientFactory.createBackendApi(""))
        assertNull(NetworkClientFactory.createBackendApi("http://insecure.example.com/api"))
        assertNotNull(NetworkClientFactory.createBackendApi("https://us-central1-zen.cloudfunctions.net/api"))
    }

    @Test
    fun `placeholder ai repository labels sample responses when firebase declined`() = runTest {
        val repo = PlaceholderAdminAiRepository()
        assertFalse(repo.isLiveGeminiEnabled)

        val chunk = repo.askAssistant(
            prompt = "Explain system health",
            context = AdminContextSnapshot(
                backendMode = ConnectionMode.FIREBASE_DECLINED,
                backendUrlConfigured = false,
                githubRepoConfigured = "zen-org/zen-ai",
                recentWorkflowFailureCount = 0,
                latestWorkflowName = "android-release",
                auditLogCount = 3,
                keystoreActive = true
            )
        ).last()

        assertTrue(chunk.isComplete)
        assertTrue(chunk.isPlaceholderSample)
        assertTrue(chunk.text.contains("SAMPLE DIAGNOSTIC RESPONSE"))
        assertTrue(chunk.text.contains("Firebase"))
    }

    @Test
    fun `workspace config entity defaults are safe and unprovisioned`() {
        val cfg = WorkspaceConfigEntity()
        assertEquals("", cfg.backendBaseUrl)
        assertTrue(cfg.darkThemeEnabled)
        assertEquals(90, cfg.retentionPolicyDays)
    }
}
