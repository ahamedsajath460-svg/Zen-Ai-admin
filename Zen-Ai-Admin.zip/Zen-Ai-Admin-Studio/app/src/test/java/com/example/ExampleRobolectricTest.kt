package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import com.example.core.security.AdminSessionState
import com.example.ui.screens.auth.AdminAuthScreen
import com.example.ui.theme.ZenAdminTheme
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun `app name matches Zen Admin`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Zen Admin", appName)
    }

    @Test
    fun `auth screen renders first run super admin vault setup`() {
        composeTestRule.setContent {
            ZenAdminTheme(darkTheme = true) {
                AdminAuthScreen(
                    sessionState = AdminSessionState(isVaultInitialized = false, keystoreActive = true),
                    authError = null,
                    isBusy = false,
                    onInitializeVault = { _, _, _ -> },
                    onSignIn = { _, _ -> }
                )
            }
        }
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("auth_email_input").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("auth_name_input").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("auth_passphrase_input").performScrollTo().assertIsDisplayed()
        composeTestRule.onNodeWithTag("auth_submit_button").performScrollTo().assertIsDisplayed()

        composeTestRule.onNodeWithTag("auth_email_input").performScrollTo().performTextInput("owner@zenai.dev")
        composeTestRule.onNodeWithTag("auth_name_input").performScrollTo().performTextInput("Root Owner")
        composeTestRule.onNodeWithTag("auth_passphrase_input").performScrollTo().performTextInput("StrongPass123!")
        composeTestRule.waitForIdle()
    }
}
