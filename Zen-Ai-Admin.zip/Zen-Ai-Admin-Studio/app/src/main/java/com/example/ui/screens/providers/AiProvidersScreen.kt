package com.example.ui.screens.providers

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.core.model.AiCapabilityChannel
import com.example.core.model.AiProviderConfig
import com.example.core.model.UiState
import com.example.ui.components.BackendSetupRequiredBanner
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.theme.LocalZenStatusColors
import com.example.ui.theme.MonoMetricStyle

private val supportedProvidersCatalog = listOf(
    "Gemini", "OpenAI", "Claude", "DeepSeek", "Groq",
    "OpenRouter", "Mistral", "Together AI", "Pollinations", "Tavily", "Custom API"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiProvidersScreen(
    providersState: UiState<List<AiProviderConfig>>,
    onRefresh: () -> Unit,
    onOpenSettings: () -> Unit,
    onUpdateProvider: (id: String, enabled: Boolean, model: String, shutdown: Boolean) -> Unit,
    onRotateKey: (id: String, key: String, expiresAt: String?) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedChannel by remember { mutableStateOf(AiCapabilityChannel.TEXT_CHAT) }
    var rotateTarget by remember { mutableStateOf<AiProviderConfig?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            EnterpriseGlassCard(accentBorder = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Zero-Leak Key Vault: API keys are stored encrypted in Cloud Secret Manager and never returned to the Admin APK. UI shows masked rotation status only.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            EnterpriseGlassCard {
                Text("Capability Routing Channels", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    AiCapabilityChannel.entries.forEach { ch ->
                        FilterChip(
                            selected = selectedChannel == ch,
                            onClick = { selectedChannel = ch },
                            label = { Text(ch.label) }
                        )
                    }
                }
            }
        }

        when (providersState) {
            UiState.Loading -> item { Text("Loading AI provider registry...", style = MaterialTheme.typography.bodyMedium) }
            is UiState.Error -> {
                item {
                    BackendSetupRequiredBanner(
                        moduleName = "AI Provider Control Center",
                        reason = providersState.message,
                        onOpenSettings = onOpenSettings,
                        onRetry = onRefresh
                    )
                }
                item {
                    EnterpriseGlassCard {
                        Text("Supported Provider Integrations (11)", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            supportedProvidersCatalog.forEach { name ->
                                StatusPill(name, PillTone.NEUTRAL)
                            }
                        }
                    }
                }
            }
            is UiState.Success -> {
                val list = providersState.data
                items(list, key = { it.id }) { provider ->
                    val isPrimary = provider.primaryFor.contains(selectedChannel.key)
                    val isFallback = provider.fallbackFor.contains(selectedChannel.key)
                    EnterpriseGlassCard(
                        accentBorder = if (provider.emergencyShutdown) LocalZenStatusColors.current.critical else null
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(provider.name, style = MaterialTheme.typography.titleMedium)
                                Text("Model: ${provider.activeModel}", style = MonoMetricStyle, color = MaterialTheme.colorScheme.primary)
                            }
                            Switch(
                                checked = provider.enabled && !provider.emergencyShutdown,
                                onCheckedChange = { enabled ->
                                    onUpdateProvider(provider.id, enabled, provider.activeModel, false)
                                }
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            StatusPill(
                                text = if (provider.emergencyShutdown) "EMERGENCY SHUTDOWN" else provider.status,
                                tone = if (provider.emergencyShutdown) PillTone.CRITICAL else if (provider.enabled) PillTone.HEALTHY else PillTone.WARNING
                            )
                            if (isPrimary) StatusPill("Primary · ${selectedChannel.label}", PillTone.INFO)
                            if (isFallback) StatusPill("Fallback · ${selectedChannel.label}", PillTone.WARNING)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Key: ${provider.maskedKeyPreview} · Rotated: ${provider.keyLastRotated}",
                            style = MonoMetricStyle,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Requests: ${provider.requestCount} · Errors: ${provider.errorCount} · Latency: ${provider.avgLatencyMs}ms",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { rotateTarget = provider }) {
                                Icon(Icons.Default.Key, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("Rotate Key")
                            }
                            Button(
                                onClick = {
                                    onUpdateProvider(provider.id, false, provider.activeModel, !provider.emergencyShutdown)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = LocalZenStatusColors.current.critical)
                            ) {
                                Icon(Icons.Default.PowerSettingsNew, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text(if (provider.emergencyShutdown) "Restore" else "Shutdown")
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    rotateTarget?.let { target ->
        var newKey by remember { mutableStateOf("") }
        var expiresAt by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { rotateTarget = null },
            title = { Text("Rotate ${target.name} Secret") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Secret is transmitted directly over TLS to Cloud Secret Manager and never persisted locally.", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = newKey,
                        onValueChange = { newKey = it },
                        label = { Text("New Provider API Key") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = expiresAt,
                        onValueChange = { expiresAt = it },
                        label = { Text("Expiration Date (optional, YYYY-MM-DD)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRotateKey(target.id, newKey, expiresAt.ifBlank { null })
                        rotateTarget = null
                    },
                    enabled = newKey.isNotBlank()
                ) { Text("Rotate Server-Side") }
            },
            dismissButton = {
                TextButton(onClick = { rotateTarget = null }) { Text("Cancel") }
            }
        )
    }
}
