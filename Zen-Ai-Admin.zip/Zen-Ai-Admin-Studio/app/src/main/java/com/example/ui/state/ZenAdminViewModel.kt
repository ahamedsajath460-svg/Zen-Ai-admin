package com.example.ui.state

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.ai.AdminAiRepository
import com.example.core.ai.AdminContextSnapshot
import com.example.core.database.DashboardWidgetEntity
import com.example.core.database.LocalAuditLogEntity
import com.example.core.database.WorkspaceConfigEntity
import com.example.core.model.AdminAccountRecord
import com.example.core.model.AdminPermission
import com.example.core.model.AdminRole
import com.example.core.model.AiProviderConfig
import com.example.core.model.AnalyticsSummaryDto
import com.example.core.model.AppReleaseDto
import com.example.core.model.AuditLogEntryDto
import com.example.core.model.AutomationRuleDto
import com.example.core.model.BackendOverviewResponse
import com.example.core.model.BackupRecordDto
import com.example.core.model.ConnectionMode
import com.example.core.model.DateRangeFilter
import com.example.core.model.FeatureFlagConfig
import com.example.core.model.NotificationCampaignDto
import com.example.core.model.PendingApprovalRequest
import com.example.core.model.SubscriptionPlanDto
import com.example.core.model.SupportTicketDto
import com.example.core.model.SystemHealthProbeDto
import com.example.core.model.UiState
import com.example.core.model.ZenUserRecord
import com.example.core.network.NotificationDispatchRequest
import com.example.core.network.ProviderUpdateRequest
import com.example.core.network.UserActionRequest
import com.example.core.security.AdminSessionManager
import com.example.core.security.FirebaseAdminAuthRepository
import com.example.core.security.AdminSessionState
import com.example.data.repository.AdminControlRepository
import com.example.data.repository.GitHubSnapshot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AiAssistantMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val isStreaming: Boolean = false,
    val isPlaceholderSample: Boolean = false
)

data class PendingSensitiveAction(
    val title: String,
    val description: String,
    val target: String,
    val onConfirmed: suspend () -> Unit
)

data class AdminDashboardUiState(
    val dateRange: DateRangeFilter = DateRangeFilter.DAYS_7,
    val connectionMode: ConnectionMode = ConnectionMode.FIREBASE_DECLINED,
    val isRefreshing: Boolean = false,
    val statusBanner: String? = null,
    val overviewState: UiState<BackendOverviewResponse> = UiState.Error("Firebase setup declined & no Backend Proxy URL configured."),
    val usersState: UiState<List<ZenUserRecord>> = UiState.Error("Backend not connected."),
    val adminsState: UiState<List<AdminAccountRecord>> = UiState.Error("Backend not connected."),
    val approvals: List<PendingApprovalRequest> = emptyList(),
    val providersState: UiState<List<AiProviderConfig>> = UiState.Error("Backend not connected."),
    val featuresState: UiState<List<FeatureFlagConfig>> = UiState.Error("Backend not connected."),
    val analyticsState: UiState<AnalyticsSummaryDto> = UiState.Error("Backend not connected."),
    val subscriptionsState: UiState<List<SubscriptionPlanDto>> = UiState.Error("Backend not connected."),
    val releasesState: UiState<List<AppReleaseDto>> = UiState.Error("Backend not connected."),
    val notificationsState: UiState<List<NotificationCampaignDto>> = UiState.Error("Backend not connected."),
    val supportState: UiState<List<SupportTicketDto>> = UiState.Error("Backend not connected."),
    val automationState: UiState<List<AutomationRuleDto>> = UiState.Error("Backend not connected."),
    val backupsState: UiState<List<BackupRecordDto>> = UiState.Error("Backend not connected."),
    val remoteAuditLogs: List<AuditLogEntryDto> = emptyList(),
    val healthProbes: List<SystemHealthProbeDto> = emptyList(),
    val gitHubState: UiState<GitHubSnapshot> = UiState.Error("Enter a GitHub Owner and Repo to load live repository & workflow data."),
    val hasGitHubToken: Boolean = false,
    val hasBackendToken: Boolean = false,
    val aiMessages: List<AiAssistantMessage> = emptyList(),
    val isAiGenerating: Boolean = false,
    val pendingSensitiveAction: PendingSensitiveAction? = null,
    val reAuthError: String? = null
)

class ZenAdminViewModel(
    private val repository: AdminControlRepository,
    private val sessionManager: AdminSessionManager,
    private val aiRepository: AdminAiRepository,
    private val firebaseAdminAuth: FirebaseAdminAuthRepository
) : ViewModel() {

    val sessionState: StateFlow<AdminSessionState> = repository.sessionState.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = AdminSessionState()
    )

    val workspaceConfig: StateFlow<WorkspaceConfigEntity> = repository.workspaceConfig.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = WorkspaceConfigEntity()
    )

    val widgets: StateFlow<List<DashboardWidgetEntity>> = repository.widgets.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = AdminControlRepository.defaultWidgets()
    )

    val localAuditLogs: StateFlow<List<LocalAuditLogEntity>> = repository.localAuditLogs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = emptyList()
    )

    private val _uiState = MutableStateFlow(AdminDashboardUiState())
    val uiState: StateFlow<AdminDashboardUiState> = _uiState.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _isAuthBusy = MutableStateFlow(false)
    val isAuthBusy: StateFlow<Boolean> = _isAuthBusy.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureDefaultsSeeded()
            refreshTokenIndicators()
            runSystemHealthProbes()
        }
    }

    private suspend fun refreshTokenIndicators() {
        _uiState.update {
            it.copy(
                hasGitHubToken = sessionManager.hasGitHubToken(),
                hasBackendToken = sessionManager.hasBackendToken()
            )
        }
    }

    @Deprecated("A local vault must never grant administrator privileges. Use Firebase administrator sign-in.")
    fun initializeVault(email: String, displayName: String, passphrase: String) {
        _authError.value = "Local Super Admin self-registration is disabled. Sign in with a Firebase account provisioned with an administrator role."
    }

    fun signIn(email: String, passphrase: String) {
        viewModelScope.launch {
            _isAuthBusy.value = true
            _authError.value = null
            val verified = firebaseAdminAuth.signInAndVerify(email, passphrase)
            verified.onSuccess { identity ->
                val localResult = if (sessionState.value.isVaultInitialized) {
                    sessionManager.signIn(identity.email, passphrase)
                } else {
                    sessionManager.initializeSuperAdminVault(
                        identity.email,
                        identity.displayName.ifBlank { "Administrator" },
                        passphrase,
                        identity.role
                    )
                }
                localResult.onSuccess {
                    repository.appendAudit(
                        actorEmail = identity.email,
                        actorRole = identity.role.displayName,
                        action = "ADMIN_SIGN_IN",
                        target = "FirebaseAdminSession",
                        outcome = "SUCCESS",
                        details = "Firebase ID token, verified email, adminRole claim and admin_roles document validated; local Keystore lock passed."
                    )
                    refreshAllConnectedData()
                }.onFailure { error ->
                    firebaseAdminAuth.signOut()
                    _authError.value = error.message ?: "Local device vault verification failed."
                }
            }.onFailure { error ->
                repository.appendAudit(
                    actorEmail = email,
                    actorRole = "UNAUTHENTICATED",
                    action = "ADMIN_SIGN_IN_FAILED",
                    target = "FirebaseAdminSession",
                    outcome = "DENIED",
                    details = error.message ?: "Firebase administrator authentication rejected"
                )
                _authError.value = error.message ?: "Firebase administrator sign-in failed."
            }
            _isAuthBusy.value = false
        }
    }

    fun signOut() {
        viewModelScope.launch {
            val actor = sessionState.value.adminEmail
            val role = sessionState.value.activeRole.displayName
            sessionManager.signOut()
            firebaseAdminAuth.signOut()
            repository.appendAudit(
                actorEmail = actor,
                actorRole = role,
                action = "ADMIN_SIGN_OUT",
                target = "AdminStudioSession",
                outcome = "SUCCESS",
                details = "Administrator locked session and cleared active token."
            )
        }
    }

    fun switchRolePreview(role: AdminRole) {
        requestSensitiveAction(
            title = "Switch Active RBAC Role",
            description = "Confirm administrator passphrase to switch active UI role simulation to ${role.displayName}.",
            target = role.displayName
        ) {
            sessionManager.setActiveRolePreview(role)
            repository.appendAudit(
                actorEmail = sessionState.value.adminEmail,
                actorRole = role.displayName,
                action = "RBAC_ROLE_SWITCH",
                target = role.name,
                outcome = "SUCCESS",
                details = "Active RBAC role set to ${role.displayName}."
            )
        }
    }

    fun setDateRange(range: DateRangeFilter) {
        _uiState.update { it.copy(dateRange = range) }
        refreshBackendOnly()
    }

    fun toggleDarkTheme(enabled: Boolean) {
        viewModelScope.launch {
            repository.setDarkTheme(enabled)
        }
    }

    fun toggleDashboardWidget(widgetId: String, enabled: Boolean) {
        viewModelScope.launch {
            repository.setWidgetEnabled(widgetId, enabled)
        }
    }

    fun clearStatusBanner() {
        _uiState.update { it.copy(statusBanner = null) }
    }

    fun saveWorkspaceSettings(
        backendBaseUrl: String,
        firebaseProjectId: String,
        githubOwner: String,
        githubRepo: String,
        githubTokenInput: String?,
        backendTokenInput: String?,
        darkTheme: Boolean,
        sessionTimeoutMinutes: Int,
        retentionDays: Int,
        maintenanceModeLocal: Boolean
    ) {
        viewModelScope.launch {
            repository.updateWorkspaceConfig(
                backendBaseUrl = backendBaseUrl,
                firebaseProjectId = firebaseProjectId,
                githubOwner = githubOwner,
                githubRepo = githubRepo,
                darkThemeEnabled = darkTheme,
                sessionTimeoutMinutes = sessionTimeoutMinutes,
                retentionPolicyDays = retentionDays,
                maintenanceModeLocal = maintenanceModeLocal
            )
            if (githubTokenInput != null) {
                sessionManager.saveEncryptedGitHubToken(githubTokenInput)
            }
            if (backendTokenInput != null) {
                sessionManager.saveEncryptedBackendToken(backendTokenInput)
            }
            refreshTokenIndicators()
            repository.appendAudit(
                actorEmail = sessionState.value.adminEmail,
                actorRole = sessionState.value.activeRole.displayName,
                action = "WORKSPACE_CONFIG_SAVED",
                target = "WorkspaceSettings",
                outcome = "SUCCESS",
                details = "Updated endpoints (GitHub: $githubOwner/$githubRepo, Backend configured: ${backendBaseUrl.isNotBlank()})."
            )
            _uiState.update { it.copy(statusBanner = "Workspace configuration encrypted & saved.") }
            refreshAllConnectedData()
        }
    }

    fun refreshAllConnectedData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshing = true) }
            runSystemHealthProbes()
            val cfg = workspaceConfig.value
            if (cfg.githubOwner.isNotBlank() && cfg.githubRepo.isNotBlank()) {
                refreshGitHub(cfg.githubOwner, cfg.githubRepo)
            }
            refreshBackendInternal(cfg.backendBaseUrl, _uiState.value.dateRange.apiValue)
            _uiState.update { it.copy(isRefreshing = false) }
        }
    }

    fun refreshBackendOnly() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshing = true) }
            refreshBackendInternal(workspaceConfig.value.backendBaseUrl, _uiState.value.dateRange.apiValue)
            _uiState.update { it.copy(isRefreshing = false) }
        }
    }

    fun refreshGitHub(owner: String, repo: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(gitHubState = UiState.Loading) }
            val result = repository.fetchGitHubSnapshot(owner, repo)
            result.onSuccess { snap ->
                _uiState.update { it.copy(gitHubState = UiState.Success(snap)) }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(gitHubState = UiState.Error(err.message ?: "Failed to reach GitHub API"))
                }
            }
        }
    }

    fun triggerWorkflow(workflowId: Long, workflowName: String, ref: String) {
        val cfg = workspaceConfig.value
        if (!sessionState.value.hasPermission(AdminPermission.MANAGE_GITHUB)) {
            _uiState.update { it.copy(statusBanner = "Permission denied: MANAGE_GITHUB required.") }
            return
        }
        requestSensitiveAction(
            title = "Trigger GitHub Workflow",
            description = "Confirm re-authentication to dispatch '$workflowName' on branch '$ref'.",
            target = "${cfg.githubOwner}/${cfg.githubRepo}#$workflowId"
        ) {
            val res = repository.triggerGitHubWorkflow(cfg.githubOwner, cfg.githubRepo, workflowId, ref)
            res.onSuccess {
                repository.appendAudit(
                    actorEmail = sessionState.value.adminEmail,
                    actorRole = sessionState.value.activeRole.displayName,
                    action = "GITHUB_WORKFLOW_DISPATCH",
                    target = "$workflowName ($ref)",
                    outcome = "SUCCESS",
                    details = "Dispatched workflow #$workflowId."
                )
                _uiState.update { it.copy(statusBanner = "Workflow '$workflowName' dispatched.") }
                refreshGitHub(cfg.githubOwner, cfg.githubRepo)
            }.onFailure { err ->
                _uiState.update { it.copy(statusBanner = err.message ?: "Workflow dispatch failed.") }
            }
        }
    }

    fun cancelWorkflowRun(runId: Long) {
        val cfg = workspaceConfig.value
        requestSensitiveAction(
            title = "Cancel Running Workflow",
            description = "Confirm cancellation of GitHub Actions run #$runId.",
            target = "Run #$runId"
        ) {
            val res = repository.cancelGitHubWorkflowRun(cfg.githubOwner, cfg.githubRepo, runId)
            res.onSuccess {
                repository.appendAudit(
                    actorEmail = sessionState.value.adminEmail,
                    actorRole = sessionState.value.activeRole.displayName,
                    action = "GITHUB_RUN_CANCELLED",
                    target = "Run #$runId",
                    outcome = "SUCCESS",
                    details = "Cancelled workflow run #$runId."
                )
                _uiState.update { it.copy(statusBanner = "Run #$runId cancellation requested.") }
                refreshGitHub(cfg.githubOwner, cfg.githubRepo)
            }.onFailure { err ->
                _uiState.update { it.copy(statusBanner = err.message ?: "Cancel failed.") }
            }
        }
    }

    fun runSystemHealthProbes() {
        viewModelScope.launch {
            val cfg = workspaceConfig.value
            val firebaseProbe = SystemHealthProbeDto(
                serviceName = "Firebase Core (Auth / Firestore / AI Logic)",
                status = "Setup Required",
                latencyMs = null,
                detail = "Firebase setup declined during onboarding. Provision Firebase to enable live cloud sync & Gemini AI.",
                checkedAt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            )
            val keystoreProbe = SystemHealthProbeDto(
                serviceName = "Android Keystore & Room Vault",
                status = if (sessionState.value.keystoreActive) "Operational" else "Degraded",
                latencyMs = 1L,
                detail = if (sessionState.value.keystoreActive) "AES-256-GCM hardware-backed keystore ready" else "Keystore unavailable",
                checkedAt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            )
            val githubProbe = repository.probeGitHubApiReachability()
            val backendProbe = repository.probeBackendHealth(cfg.backendBaseUrl)
            _uiState.update {
                it.copy(healthProbes = listOf(firebaseProbe, backendProbe, githubProbe, keystoreProbe))
            }
        }
    }

    private suspend fun refreshBackendInternal(baseUrl: String, range: String) {
        if (baseUrl.isBlank()) {
            val msg = "Backend Proxy URL is not configured yet. Set an HTTPS Cloud Functions URL in Settings to load live Zen AI telemetry."
            _uiState.update {
                it.copy(
                    connectionMode = ConnectionMode.FIREBASE_DECLINED,
                    overviewState = UiState.Error(msg, isRetryable = false),
                    usersState = UiState.Error(msg, isRetryable = false),
                    adminsState = UiState.Error(msg, isRetryable = false),
                    providersState = UiState.Error(msg, isRetryable = false),
                    featuresState = UiState.Error(msg, isRetryable = false),
                    analyticsState = UiState.Error(msg, isRetryable = false),
                    subscriptionsState = UiState.Error(msg, isRetryable = false),
                    releasesState = UiState.Error(msg, isRetryable = false),
                    notificationsState = UiState.Error(msg, isRetryable = false),
                    supportState = UiState.Error(msg, isRetryable = false),
                    automationState = UiState.Error(msg, isRetryable = false),
                    backupsState = UiState.Error(msg, isRetryable = false)
                )
            }
            return
        }

        _uiState.update { it.copy(connectionMode = ConnectionMode.CONNECTING) }
        val overviewRes = repository.fetchOverview(baseUrl, range)
        val usersRes = repository.fetchUsers(baseUrl, null, null)
        val adminsRes = repository.fetchAdmins(baseUrl)
        val approvalsRes = repository.fetchApprovals(baseUrl)
        val providersRes = repository.fetchProviders(baseUrl)
        val flagsRes = repository.fetchFeatureFlags(baseUrl)
        val analyticsRes = repository.fetchAnalytics(baseUrl, range)
        val subsRes = repository.fetchSubscriptions(baseUrl)
        val releasesRes = repository.fetchReleases(baseUrl)
        val notifRes = repository.fetchNotifications(baseUrl)
        val supportRes = repository.fetchSupportTickets(baseUrl)
        val autoRes = repository.fetchAutomationRules(baseUrl)
        val backupsRes = repository.fetchBackups(baseUrl)
        val auditRes = repository.fetchRemoteAuditLogs(baseUrl)

        val anySuccess = overviewRes.isSuccess || usersRes.isSuccess || providersRes.isSuccess || flagsRes.isSuccess
        _uiState.update { state ->
            state.copy(
                connectionMode = if (anySuccess) ConnectionMode.CONNECTED else ConnectionMode.ERROR,
                overviewState = overviewRes.fold({ UiState.Success(it) }, { UiState.Error(it.message ?: "Overview unavailable") }),
                usersState = usersRes.fold({ UiState.Success(it) }, { UiState.Error(it.message ?: "Users unavailable") }),
                adminsState = adminsRes.fold({ UiState.Success(it) }, { UiState.Error(it.message ?: "Roles unavailable") }),
                approvals = approvalsRes.getOrDefault(emptyList()),
                providersState = providersRes.fold({ UiState.Success(it) }, { UiState.Error(it.message ?: "Providers unavailable") }),
                featuresState = flagsRes.fold({ UiState.Success(it) }, { UiState.Error(it.message ?: "Feature flags unavailable") }),
                analyticsState = analyticsRes.fold({ UiState.Success(it) }, { UiState.Error(it.message ?: "Analytics unavailable") }),
                subscriptionsState = subsRes.fold({ UiState.Success(it) }, { UiState.Error(it.message ?: "Subscriptions unavailable") }),
                releasesState = releasesRes.fold({ UiState.Success(it) }, { UiState.Error(it.message ?: "Releases unavailable") }),
                notificationsState = notifRes.fold({ UiState.Success(it) }, { UiState.Error(it.message ?: "Notifications unavailable") }),
                supportState = supportRes.fold({ UiState.Success(it) }, { UiState.Error(it.message ?: "Support unavailable") }),
                automationState = autoRes.fold({ UiState.Success(it) }, { UiState.Error(it.message ?: "Automation unavailable") }),
                backupsState = backupsRes.fold({ UiState.Success(it) }, { UiState.Error(it.message ?: "Backups unavailable") }),
                remoteAuditLogs = auditRes.getOrDefault(emptyList())
            )
        }
    }

    // --- Backend Mutations with RBAC + Re-Authentication ---

    fun performUserAdminAction(uid: String, action: String, reason: String, role: String? = null) {
        if (!sessionState.value.hasPermission(AdminPermission.MANAGE_USERS)) {
            _uiState.update { it.copy(statusBanner = "Permission denied: MANAGE_USERS required.") }
            return
        }
        val baseUrl = workspaceConfig.value.backendBaseUrl
        val isDestructive = action in setOf("delete", "suspend", "disable")
        val execute: suspend () -> Unit = {
            val res = repository.performUserAction(baseUrl, uid, UserActionRequest(action, reason, role))
            res.onSuccess {
                repository.appendAudit(
                    actorEmail = sessionState.value.adminEmail,
                    actorRole = sessionState.value.activeRole.displayName,
                    action = "USER_${action.uppercase()}",
                    target = uid,
                    outcome = "SUCCESS",
                    details = "Reason: $reason"
                )
                _uiState.update { it.copy(statusBanner = "User action '$action' executed.") }
                refreshBackendOnly()
            }.onFailure { err ->
                _uiState.update { it.copy(statusBanner = err.message ?: "User action failed.") }
            }
        }
        if (isDestructive) {
            requestSensitiveAction(
                title = "Confirm User ${action.replaceFirstChar { it.uppercase() }}",
                description = "Retention-policy & security verification required before applying '$action' to UID $uid.",
                target = uid,
                onConfirmed = execute
            )
        } else {
            viewModelScope.launch { execute() }
        }
    }

    fun updateProviderConfig(providerId: String, enabled: Boolean, model: String, shutdown: Boolean) {
        if (!sessionState.value.hasPermission(AdminPermission.MANAGE_PROVIDERS)) {
            _uiState.update { it.copy(statusBanner = "Permission denied: MANAGE_PROVIDERS required.") }
            return
        }
        val baseUrl = workspaceConfig.value.backendBaseUrl
        val execute: suspend () -> Unit = {
            val res = repository.updateProvider(baseUrl, providerId, ProviderUpdateRequest(enabled, model, shutdown))
            res.onSuccess {
                repository.appendAudit(
                    actorEmail = sessionState.value.adminEmail,
                    actorRole = sessionState.value.activeRole.displayName,
                    action = if (shutdown) "PROVIDER_EMERGENCY_SHUTDOWN" else "PROVIDER_UPDATED",
                    target = providerId,
                    outcome = "SUCCESS",
                    details = "Model: $model, enabled: $enabled, shutdown: $shutdown"
                )
                _uiState.update { it.copy(statusBanner = "Provider '$providerId' updated.") }
                refreshBackendOnly()
            }.onFailure { err ->
                _uiState.update { it.copy(statusBanner = err.message ?: "Provider update failed.") }
            }
        }
        if (shutdown) {
            requestSensitiveAction(
                title = "Emergency Provider Shutdown",
                description = "Confirm emergency shutdown of AI provider '$providerId'. Active Zen AI requests will fail over.",
                target = providerId,
                onConfirmed = execute
            )
        } else {
            viewModelScope.launch { execute() }
        }
    }

    fun rotateProviderKey(providerId: String, newKey: String, expiresAt: String?) {
        if (!sessionState.value.hasPermission(AdminPermission.MANAGE_PROVIDERS)) {
            _uiState.update { it.copy(statusBanner = "Permission denied: MANAGE_PROVIDERS required.") }
            return
        }
        if (newKey.isBlank()) {
            _uiState.update { it.copy(statusBanner = "API key cannot be empty.") }
            return
        }
        requestSensitiveAction(
            title = "Server-Side Key Rotation",
            description = "Send new API key directly to Cloud Secret Manager for '$providerId'. Key is never stored locally.",
            target = providerId
        ) {
            val res = repository.rotateProviderKey(workspaceConfig.value.backendBaseUrl, providerId, newKey, expiresAt)
            res.onSuccess {
                repository.appendAudit(
                    actorEmail = sessionState.value.adminEmail,
                    actorRole = sessionState.value.activeRole.displayName,
                    action = "PROVIDER_KEY_ROTATED",
                    target = providerId,
                    outcome = "SUCCESS",
                    details = "Rotated secret server-side."
                )
                _uiState.update { it.copy(statusBanner = "Key rotated server-side for '$providerId'.") }
                refreshBackendOnly()
            }.onFailure { err ->
                _uiState.update { it.copy(statusBanner = err.message ?: "Key rotation failed.") }
            }
        }
    }

    fun updateFeatureFlag(flag: FeatureFlagConfig) {
        if (!sessionState.value.hasPermission(AdminPermission.MANAGE_FEATURES)) {
            _uiState.update { it.copy(statusBanner = "Permission denied: MANAGE_FEATURES required.") }
            return
        }
        viewModelScope.launch {
            val res = repository.updateFeatureFlag(workspaceConfig.value.backendBaseUrl, flag)
            res.onSuccess {
                repository.appendAudit(
                    actorEmail = sessionState.value.adminEmail,
                    actorRole = sessionState.value.activeRole.displayName,
                    action = "FEATURE_FLAG_UPDATED",
                    target = flag.key,
                    outcome = "SUCCESS",
                    details = "Enabled=${flag.enabled}, rollout=${flag.rolloutPercentage}%, maint=${flag.maintenanceMode}"
                )
                _uiState.update { it.copy(statusBanner = "Feature '${flag.displayName}' synced to backend.") }
                refreshBackendOnly()
            }.onFailure { err ->
                _uiState.update { it.copy(statusBanner = err.message ?: "Feature update failed.") }
            }
        }
    }

    fun sendNotificationCampaign(req: NotificationDispatchRequest) {
        if (!sessionState.value.hasPermission(AdminPermission.SEND_NOTIFICATIONS)) {
            _uiState.update { it.copy(statusBanner = "Permission denied: SEND_NOTIFICATIONS required.") }
            return
        }
        requestSensitiveAction(
            title = "Dispatch FCM Notification",
            description = "Send '${req.title}' targeting '${req.targetAudience}' via backend FCM worker.",
            target = req.targetAudience
        ) {
            val res = repository.sendNotification(workspaceConfig.value.backendBaseUrl, req)
            res.onSuccess {
                repository.appendAudit(
                    actorEmail = sessionState.value.adminEmail,
                    actorRole = sessionState.value.activeRole.displayName,
                    action = "FCM_CAMPAIGN_SENT",
                    target = req.title,
                    outcome = "SUCCESS",
                    details = "Audience=${req.targetAudience}"
                )
                _uiState.update { it.copy(statusBanner = "Notification campaign dispatched.") }
                refreshBackendOnly()
            }.onFailure { err ->
                _uiState.update { it.copy(statusBanner = err.message ?: "Notification dispatch failed.") }
            }
        }
    }

    // --- Re-Authentication Gate ---

    fun requestSensitiveAction(
        title: String,
        description: String,
        target: String,
        onConfirmed: suspend () -> Unit
    ) {
        _uiState.update {
            it.copy(
                pendingSensitiveAction = PendingSensitiveAction(title, description, target, onConfirmed),
                reAuthError = null
            )
        }
    }

    fun dismissSensitiveAction() {
        _uiState.update { it.copy(pendingSensitiveAction = null, reAuthError = null) }
    }

    fun confirmSensitiveAction(passphrase: String) {
        val pending = _uiState.value.pendingSensitiveAction ?: return
        viewModelScope.launch {
            val check = sessionManager.verifyReAuthentication(passphrase)
            check.onSuccess {
                _uiState.update { it.copy(pendingSensitiveAction = null, reAuthError = null) }
                pending.onConfirmed()
            }.onFailure { err ->
                repository.appendAudit(
                    actorEmail = sessionState.value.adminEmail,
                    actorRole = sessionState.value.activeRole.displayName,
                    action = "REAUTH_FAILED",
                    target = pending.target,
                    outcome = "DENIED",
                    details = err.message ?: "Invalid passphrase during re-authentication"
                )
                _uiState.update { it.copy(reAuthError = err.message ?: "Passphrase rejected.") }
            }
        }
    }

    // --- AI Admin Assistant ---

    fun sendAiAssistantPrompt(prompt: String) {
        val clean = prompt.trim()
        if (clean.isBlank() || _uiState.value.isAiGenerating) return

        val userMsg = AiAssistantMessage(
            id = "u_${System.currentTimeMillis()}",
            isUser = true,
            text = clean
        )
        val assistantMsgId = "a_${System.currentTimeMillis() + 1}"
        val placeholderMsg = AiAssistantMessage(
            id = assistantMsgId,
            isUser = false,
            text = "",
            isStreaming = true,
            isPlaceholderSample = !aiRepository.isLiveGeminiEnabled
        )

        _uiState.update {
            it.copy(
                aiMessages = it.aiMessages + userMsg + placeholderMsg,
                isAiGenerating = true
            )
        }

        val cfg = workspaceConfig.value
        val ghSnap = (_uiState.value.gitHubState as? UiState.Success)?.data
        val snapshot = AdminContextSnapshot(
            backendMode = _uiState.value.connectionMode,
            backendUrlConfigured = cfg.backendBaseUrl.isNotBlank(),
            githubRepoConfigured = if (cfg.githubOwner.isNotBlank() && cfg.githubRepo.isNotBlank()) "${cfg.githubOwner}/${cfg.githubRepo}" else "",
            recentWorkflowFailureCount = ghSnap?.workflowRuns?.count { it.conclusion == "failure" } ?: 0,
            latestWorkflowName = ghSnap?.workflowRuns?.firstOrNull()?.name,
            auditLogCount = localAuditLogs.value.size,
            keystoreActive = sessionState.value.keystoreActive
        )

        viewModelScope.launch {
            try {
                aiRepository.askAssistant(clean, snapshot).collect { chunk ->
                    _uiState.update { state ->
                        val updated = state.aiMessages.map { msg ->
                            if (msg.id == assistantMsgId) {
                                msg.copy(
                                    text = chunk.text,
                                    isStreaming = !chunk.isComplete,
                                    isPlaceholderSample = chunk.isPlaceholderSample
                                )
                            } else msg
                        }
                        state.copy(
                            aiMessages = updated,
                            isAiGenerating = !chunk.isComplete
                        )
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _uiState.update { state ->
                    val updated = state.aiMessages.map { msg ->
                        if (msg.id == assistantMsgId) {
                            msg.copy(text = "Assistant error: ${e.localizedMessage}", isStreaming = false)
                        } else msg
                    }
                    state.copy(aiMessages = updated, isAiGenerating = false)
                }
            }
        }
    }

    fun exportConfigReport(): String = repository.exportSanitizedConfigJson(workspaceConfig.value)

    fun observeNotes(targetType: String, targetId: String) = repository.observeNotes(targetType, targetId)

    fun addNote(targetType: String, targetId: String, body: String) {
        if (body.isBlank()) return
        viewModelScope.launch {
            repository.addAdminNote(targetType, targetId, sessionState.value.adminEmail, body)
            repository.appendAudit(
                actorEmail = sessionState.value.adminEmail,
                actorRole = sessionState.value.activeRole.displayName,
                action = "ADMIN_NOTE_ADDED",
                target = "$targetType:$targetId",
                outcome = "SUCCESS",
                details = "Stored local encrypted-vault note."
            )
        }
    }
}
