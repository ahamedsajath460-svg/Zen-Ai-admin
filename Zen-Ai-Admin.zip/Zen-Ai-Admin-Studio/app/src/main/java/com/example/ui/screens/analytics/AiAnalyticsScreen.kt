package com.example.ui.screens.analytics

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Token
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.core.model.AnalyticsSummaryDto
import com.example.core.model.DateRangeFilter
import com.example.core.model.UiState
import com.example.ui.components.BackendSetupRequiredBanner
import com.example.ui.components.BreakdownBarChart
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.MetricKpiTile
import com.example.ui.theme.LocalZenStatusColors
import com.example.ui.theme.MonoMetricStyle

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiAnalyticsScreen(
    analyticsState: UiState<AnalyticsSummaryDto>,
    selectedRange: DateRangeFilter,
    onSelectRange: (DateRangeFilter) -> Unit,
    onRefresh: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val statusColors = LocalZenStatusColors.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DateRangeFilter.entries.forEach { range ->
                    FilterChip(
                        selected = selectedRange == range,
                        onClick = { onSelectRange(range) },
                        label = { Text(range.label) }
                    )
                }
            }
        }

        when (analyticsState) {
            UiState.Loading -> item { Text("Loading AI telemetry...", style = MaterialTheme.typography.bodyMedium) }
            is UiState.Error -> item {
                BackendSetupRequiredBanner(
                    moduleName = "AI Usage Analytics",
                    reason = analyticsState.message,
                    onOpenSettings = onOpenSettings,
                    onRetry = onRefresh
                )
            }
            is UiState.Success -> {
                val data = analyticsState.data
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        MetricKpiTile(
                            label = "Total / Success",
                            value = "${data.totalRequests} / ${data.successfulRequests}",
                            subtitle = "Images: ${data.imageGenerations} · Search: ${data.searchRequests}",
                            icon = Icons.Default.Analytics,
                            modifier = Modifier.weight(1f)
                        )
                        MetricKpiTile(
                            label = "Failed Requests",
                            value = data.failedRequests.toString(),
                            subtitle = "Agent tasks: ${data.agentTasks}",
                            icon = Icons.Default.Error,
                            tint = statusColors.critical,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        MetricKpiTile(
                            label = "Avg Response Latency",
                            value = "${data.avgResponseMs} ms",
                            subtitle = "Observed across providers",
                            icon = Icons.Default.Speed,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.weight(1f)
                        )
                        MetricKpiTile(
                            label = "Reported Tokens",
                            value = data.totalTokens?.toString() ?: "Unavailable",
                            subtitle = "Provider-reported usage",
                            icon = Icons.Default.Token,
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                item {
                    EnterpriseGlassCard {
                        Text("Cost Transparency", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Estimated Cost (Model Pricing): ${data.estimatedCostUsd?.let { String.format("$%.4f", it) } ?: "Not available (missing provider pricing)"}",
                            style = MonoMetricStyle
                        )
                        Text(
                            text = "Actual Billed Cost (Provider Invoice): ${data.actualBilledUsd?.let { String.format("$%.4f", it) } ?: "Not connected to billing export"}",
                            style = MonoMetricStyle,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = {
                                val csv = buildString {
                                    appendLine("metric,value")
                                    appendLine("totalRequests,${data.totalRequests}")
                                    appendLine("successfulRequests,${data.successfulRequests}")
                                    appendLine("failedRequests,${data.failedRequests}")
                                    appendLine("avgResponseMs,${data.avgResponseMs}")
                                }
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/csv"
                                    putExtra(Intent.EXTRA_SUBJECT, "Zen AI Analytics (${selectedRange.label})")
                                    putExtra(Intent.EXTRA_TEXT, csv)
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Export Analytics CSV"))
                            }
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Export CSV Report")
                        }
                    }
                }
                item {
                    BreakdownBarChart(title = "Requests by AI Provider", items = data.byProvider)
                }
                item {
                    BreakdownBarChart(title = "Requests by Zen AI Feature", items = data.byFeature)
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
