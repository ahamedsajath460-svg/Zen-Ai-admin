package com.example.ui.screens.roles

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.model.AdminAccountRecord
import com.example.core.model.AdminRole
import com.example.core.model.PendingApprovalRequest
import com.example.core.model.UiState
import com.example.core.security.AdminSessionState
import com.example.ui.components.BackendSetupRequiredBanner
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.theme.MonoMetricStyle

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminRolesScreen(
    sessionState: AdminSessionState,
    adminsState: UiState<List<AdminAccountRecord>>,
    approvals: List<PendingApprovalRequest>,
    onSwitchRolePreview: (AdminRole) -> Unit,
    onRefresh: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            EnterpriseGlassCard(accentBorder = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Server-Enforced RBAC & Custom Claims", style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "Only verified Super Admins may create or promote administrators via Firebase custom claims and Cloud Functions. Client checks are UI guards only.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "Active Session: ${sessionState.adminEmail} · Role: ${sessionState.activeRole.displayName}",
                    style = MonoMetricStyle,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        item {
            EnterpriseGlassCard {
                Text("RBAC Role Matrix & Active Scope Test", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Switch active UI permission scope (requires vault re-authentication) to verify least-privilege visibility across all 18 modules:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AdminRole.entries.forEach { role ->
                        FilterChip(
                            selected = sessionState.activeRole == role,
                            onClick = { if (sessionState.activeRole != role) onSwitchRolePreview(role) },
                            label = { Text(role.displayName) }
                        )
                    }
                }
            }
        }

        items(AdminRole.entries, key = { it.name }) { role ->
            EnterpriseGlassCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(8.dp))
                        Text(role.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    }
                    StatusPill("Tier ${role.level}", if (role == AdminRole.SUPER_ADMIN) PillTone.INFO else PillTone.NEUTRAL)
                }
                Spacer(Modifier.height(4.dp))
                Text(role.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    role.permissions.take(6).forEach { perm ->
                        StatusPill(perm.label, PillTone.NEUTRAL)
                    }
                    if (role.permissions.size > 6) {
                        StatusPill("+${role.permissions.size - 6} more", PillTone.INFO)
                    }
                }
            }
        }

        item {
            Text("Provisioned Cloud Administrators", style = MaterialTheme.typography.titleMedium)
        }

        when (adminsState) {
            UiState.Loading -> item { Text("Loading administrator directory...", style = MaterialTheme.typography.bodyMedium) }
            is UiState.Error -> item {
                BackendSetupRequiredBanner(
                    moduleName = "Remote Admin Directory",
                    reason = adminsState.message,
                    onOpenSettings = onOpenSettings,
                    onRetry = onRefresh
                )
            }
            is UiState.Success -> {
                items(adminsState.data, key = { it.uid }) { admin ->
                    EnterpriseGlassCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(admin.displayName, style = MaterialTheme.typography.titleMedium)
                                Text(admin.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Sessions: ${admin.activeSessions} · MFA: ${if (admin.mfaEnabled) "Enforced" else "Pending"}", style = MonoMetricStyle)
                            }
                            StatusPill(admin.role, PillTone.INFO)
                        }
                    }
                }
                if (approvals.isNotEmpty()) {
                    item {
                        Text("Pending Sensitive Approvals", style = MaterialTheme.typography.titleMedium)
                    }
                    items(approvals, key = { it.id }) { req ->
                        EnterpriseGlassCard {
                            Text(req.actionType, style = MaterialTheme.typography.titleSmall)
                            Text("${req.requestedBy} -> ${req.targetSummary}", style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(6.dp))
                            OutlinedButton(onClick = onRefresh) { Text("Review in Backend") }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
