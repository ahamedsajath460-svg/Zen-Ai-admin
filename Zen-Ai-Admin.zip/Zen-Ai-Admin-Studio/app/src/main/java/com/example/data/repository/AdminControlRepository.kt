package com.example.data.repository

import android.content.Context
import com.example.core.database.CachedOverviewEntity
import com.example.core.database.DashboardWidgetEntity
import com.example.core.database.LocalAdminNoteEntity
import com.example.core.database.LocalAuditLogEntity
import com.example.core.database.WorkspaceConfigEntity
import com.example.core.database.ZenAdminDao
import com.example.core.model.AdminAccountRecord
import com.example.core.model.AiProviderConfig
import com.example.core.model.AnalyticsSummaryDto
import com.example.core.model.AppReleaseDto
import com.example.core.model.AuditLogEntryDto
import com.example.core.model.AutomationRuleDto
import com.example.core.model.BackendOverviewResponse
import com.example.core.model.BackupRecordDto
import com.example.core.model.FeatureFlagConfig
import com.example.core.model.GitHubArtifactDto
import com.example.core.model.GitHubBranchDto
import com.example.core.model.GitHubCommitItemDto
import com.example.core.model.GitHubReleaseDto
import com.example.core.model.GitHubRepoDto
import com.example.core.model.GitHubWorkflowDto
import com.example.core.model.GitHubWorkflowRunDto
import com.example.core.model.NotificationCampaignDto
import com.example.core.model.PendingApprovalRequest
import com.example.core.model.SubscriptionPlanDto
import com.example.core.model.SupportTicketDto
import com.example.core.model.SystemHealthProbeDto
import com.example.core.model.ZenUserRecord
import com.example.core.network.NetworkClientFactory
import com.example.core.network.NotificationDispatchRequest
import com.example.core.network.ProviderKeyRotateRequest
import com.example.core.network.ProviderUpdateRequest
import com.example.core.network.UserActionRequest
import com.example.core.network.WorkflowDispatchBody
import com.example.core.security.AdminSessionManager
import com.example.core.security.AdminSessionState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

data class GitHubSnapshot(
    val repo: GitHubRepoDto? = null,
    val branches: List<GitHubBranchDto> = emptyList(),
    val commits: List<GitHubCommitItemDto> = emptyList(),
    val workflows: List<GitHubWorkflowDto> = emptyList(),
    val workflowRuns: List<GitHubWorkflowRunDto> = emptyList(),
    val artifacts: List<GitHubArtifactDto> = emptyList(),
    val releases: List<GitHubReleaseDto> = emptyList(),
    val rateLimitStatus: String = "Not checked",
    val errorMessage: String? = null
)

class AdminControlRepository(
    private val dao: ZenAdminDao,
    private val sessionManager: AdminSessionManager
) {
    private val gitHubApi = NetworkClientFactory.gitHubApi

    val workspaceConfig: Flow<WorkspaceConfigEntity> = dao.observeWorkspaceConfig().map {
        it ?: WorkspaceConfigEntity()
    }

    val widgets: Flow<List<DashboardWidgetEntity>> = dao.observeWidgets().map { list ->
        if (list.isEmpty()) defaultWidgets() else list
    }

    val localAuditLogs: Flow<List<LocalAuditLogEntity>> = dao.observeAuditLogs()

    val sessionState: Flow<AdminSessionState> = sessionManager.sessionState

    suspend fun ensureDefaultsSeeded() {
        if (dao.getWorkspaceConfig() == null) {
            dao.upsertWorkspaceConfig(WorkspaceConfigEntity())
        }
        val currentWidgets = dao.observeWidgets().first()
        if (currentWidgets.isEmpty()) {
            dao.upsertWidgets(defaultWidgets())
        }
    }

    suspend fun updateWorkspaceConfig(
        backendBaseUrl: String,
        firebaseProjectId: String,
        githubOwner: String,
        githubRepo: String,
        darkThemeEnabled: Boolean,
        sessionTimeoutMinutes: Int,
        retentionPolicyDays: Int,
        maintenanceModeLocal: Boolean
    ) {
        val updated = WorkspaceConfigEntity(
            id = 1,
            backendBaseUrl = backendBaseUrl.trim(),
            firebaseProjectId = firebaseProjectId.trim(),
            githubOwner = githubOwner.trim(),
            githubRepo = githubRepo.trim(),
            darkThemeEnabled = darkThemeEnabled,
            sessionTimeoutMinutes = sessionTimeoutMinutes.coerceIn(5, 240),
            retentionPolicyDays = retentionPolicyDays.coerceIn(7, 3650),
            maintenanceModeLocal = maintenanceModeLocal,
            updatedAtMillis = System.currentTimeMillis()
        )
        dao.upsertWorkspaceConfig(updated)
    }

    suspend fun setDarkTheme(enabled: Boolean) {
        val current = dao.getWorkspaceConfig() ?: WorkspaceConfigEntity()
        dao.upsertWorkspaceConfig(current.copy(darkThemeEnabled = enabled, updatedAtMillis = System.currentTimeMillis()))
    }

    suspend fun setWidgetEnabled(widgetId: String, enabled: Boolean) {
        val currentWidgets = dao.observeWidgets().first()
        if (currentWidgets.isEmpty()) {
            dao.upsertWidgets(defaultWidgets())
        }
        dao.setWidgetEnabled(widgetId, enabled)
    }

    suspend fun appendAudit(
        actorEmail: String,
        actorRole: String,
        action: String,
        target: String,
        outcome: String,
        details: String
    ) {
        dao.appendAuditLog(
            LocalAuditLogEntity(
                actorEmail = actorEmail.ifBlank { "unauthenticated" },
                actorRole = actorRole,
                action = action,
                target = target,
                outcome = outcome,
                details = details
            )
        )
    }

    fun observeNotes(targetType: String, targetId: String): Flow<List<LocalAdminNoteEntity>> =
        dao.observeNotesForTarget(targetType, targetId)

    suspend fun addAdminNote(targetType: String, targetId: String, authorEmail: String, noteBody: String) {
        dao.insertNote(
            LocalAdminNoteEntity(
                targetType = targetType,
                targetId = targetId,
                authorEmail = authorEmail,
                noteBody = noteBody.trim()
            )
        )
    }

    // --- Live GitHub REST API Operations ---

    suspend fun fetchGitHubSnapshot(owner: String, repo: String): Result<GitHubSnapshot> {
        val cleanOwner = owner.trim()
        val cleanRepo = repo.trim()
        if (cleanOwner.isBlank() || cleanRepo.isBlank()) {
            return Result.failure(IllegalArgumentException("Configure GitHub Owner and Repository first."))
        }
        return try {
            val token = sessionManager.getDecryptedGitHubToken()
            val authHeader = if (token.isNotBlank()) "Bearer $token" else null

            val repoResp = gitHubApi.getRepository(cleanOwner, cleanRepo, authHeader)
            if (!repoResp.isSuccessful) {
                val msg = when (repoResp.code()) {
                    404 -> "Repository $cleanOwner/$cleanRepo not found (or private without token)."
                    401, 403 -> "GitHub API authorization or rate limit error (HTTP ${repoResp.code()})."
                    else -> "GitHub API error HTTP ${repoResp.code()}."
                }
                return Result.failure(IllegalStateException(msg))
            }

            val branchesResp = gitHubApi.listBranches(cleanOwner, cleanRepo, authHeader = authHeader)
            val commitsResp = gitHubApi.listCommits(cleanOwner, cleanRepo, authHeader = authHeader)
            val workflowsResp = gitHubApi.listWorkflows(cleanOwner, cleanRepo, authHeader = authHeader)
            val runsResp = gitHubApi.listWorkflowRuns(cleanOwner, cleanRepo, authHeader = authHeader)
            val artifactsResp = gitHubApi.listArtifacts(cleanOwner, cleanRepo, authHeader = authHeader)
            val releasesResp = gitHubApi.listReleases(cleanOwner, cleanRepo, authHeader = authHeader)

            val rateLimitRemaining = repoResp.headers()["X-RateLimit-Remaining"] ?: "N/A"
            val rateLimitTotal = repoResp.headers()["X-RateLimit-Limit"] ?: "N/A"

            Result.success(
                GitHubSnapshot(
                    repo = repoResp.body(),
                    branches = branchesResp.body().orEmpty(),
                    commits = commitsResp.body().orEmpty(),
                    workflows = workflowsResp.body()?.workflows.orEmpty(),
                    workflowRuns = runsResp.body()?.workflow_runs.orEmpty(),
                    artifacts = artifactsResp.body()?.artifacts.orEmpty(),
                    releases = releasesResp.body().orEmpty(),
                    rateLimitStatus = "$rateLimitRemaining / $rateLimitTotal remaining"
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun triggerGitHubWorkflow(
        owner: String,
        repo: String,
        workflowId: Long,
        ref: String
    ): Result<Unit> {
        return try {
            val token = sessionManager.getDecryptedGitHubToken()
            if (token.isBlank()) {
                return Result.failure(IllegalStateException("Workflow dispatch requires a Keystore-encrypted GitHub token or deployed Backend Proxy."))
            }
            val response = gitHubApi.triggerWorkflowDispatch(
                owner = owner.trim(),
                repo = repo.trim(),
                workflowId = workflowId,
                body = WorkflowDispatchBody(ref = ref.ifBlank { "main" }),
                authHeader = "Bearer $token"
            )
            if (response.isSuccessful) Result.success(Unit)
            else Result.failure(IllegalStateException("Workflow dispatch failed (HTTP ${response.code()})."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun cancelGitHubWorkflowRun(owner: String, repo: String, runId: Long): Result<Unit> {
        return try {
            val token = sessionManager.getDecryptedGitHubToken()
            if (token.isBlank()) {
                return Result.failure(IllegalStateException("Cancelling runs requires a GitHub token or deployed Backend Proxy."))
            }
            val response = gitHubApi.cancelWorkflowRun(
                owner = owner.trim(),
                repo = repo.trim(),
                runId = runId,
                authHeader = "Bearer $token"
            )
            if (response.isSuccessful) Result.success(Unit)
            else Result.failure(IllegalStateException("Cancel run failed (HTTP ${response.code()})."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun probeGitHubApiReachability(): SystemHealthProbeDto {
        val start = System.currentTimeMillis()
        return try {
            val token = sessionManager.getDecryptedGitHubToken()
            val authHeader = if (token.isNotBlank()) "Bearer $token" else null
            val resp = gitHubApi.getRateLimit(authHeader)
            val latency = System.currentTimeMillis() - start
            val remaining = resp.headers()["X-RateLimit-Remaining"] ?: "?"
            SystemHealthProbeDto(
                serviceName = "GitHub REST API",
                status = if (resp.isSuccessful) "Operational" else "Degraded",
                latencyMs = latency,
                detail = if (resp.isSuccessful) "Reachable · Rate limit remaining: $remaining" else "HTTP ${resp.code()}",
                checkedAt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            SystemHealthProbeDto(
                serviceName = "GitHub REST API",
                status = "Unavailable",
                latencyMs = null,
                detail = e.localizedMessage ?: "Network probe failed",
                checkedAt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            )
        }
    }

    // --- Live Backend Proxy API Operations (when configured) ---

    private suspend fun backendAuthHeader(): String? {
        val token = sessionManager.getDecryptedBackendToken()
        return if (token.isNotBlank()) "Bearer $token" else null
    }

    suspend fun probeBackendHealth(baseUrl: String): SystemHealthProbeDto {
        val api = NetworkClientFactory.createBackendApi(baseUrl)
            ?: return SystemHealthProbeDto(
                serviceName = "Zen Cloud Backend API",
                status = "Setup Required",
                latencyMs = null,
                detail = if (baseUrl.isBlank()) "No HTTPS Backend Proxy URL configured." else "Invalid URL (HTTPS required).",
                checkedAt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            )
        val start = System.currentTimeMillis()
        return try {
            val resp = api.getSystemHealth(backendAuthHeader())
            val latency = System.currentTimeMillis() - start
            if (resp.isSuccessful) {
                SystemHealthProbeDto(
                    serviceName = "Zen Cloud Backend API",
                    status = "Operational",
                    latencyMs = latency,
                    detail = "HTTP ${resp.code()} · ${resp.body()?.size ?: 0} service probes reported",
                    checkedAt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
                )
            } else {
                SystemHealthProbeDto(
                    serviceName = "Zen Cloud Backend API",
                    status = "Degraded",
                    latencyMs = latency,
                    detail = "HTTP ${resp.code()} from endpoint",
                    checkedAt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            SystemHealthProbeDto(
                serviceName = "Zen Cloud Backend API",
                status = "Unavailable",
                latencyMs = null,
                detail = e.localizedMessage ?: "Connection failed",
                checkedAt = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            )
        }
    }

    suspend fun fetchOverview(baseUrl: String, range: String): Result<BackendOverviewResponse> {
        val api = NetworkClientFactory.createBackendApi(baseUrl)
            ?: return Result.failure(IllegalStateException("Backend API URL not configured."))
        return try {
            val resp = api.getOverview(range, backendAuthHeader())
            val body = resp.body()
            if (resp.isSuccessful && body != null) {
                val adapter = NetworkClientFactory.moshi.adapter(BackendOverviewResponse::class.java)
                dao.saveCachedOverview(
                    CachedOverviewEntity(
                        id = 1,
                        jsonPayload = adapter.toJson(body),
                        syncedAtMillis = System.currentTimeMillis()
                    )
                )
                Result.success(body)
            } else {
                Result.failure(IllegalStateException("Backend returned HTTP ${resp.code()}"))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchUsers(baseUrl: String, query: String?, status: String?): Result<List<ZenUserRecord>> =
        executeBackendCall(baseUrl) { api, auth -> api.listUsers(query, status, auth) }

    suspend fun performUserAction(baseUrl: String, uid: String, req: UserActionRequest): Result<Unit> =
        executeBackendCall(baseUrl) { api, auth -> api.performUserAction(uid, req, auth) }.map { }

    suspend fun fetchAdmins(baseUrl: String): Result<List<AdminAccountRecord>> =
        executeBackendCall(baseUrl) { api, auth -> api.listAdmins(auth) }

    suspend fun fetchApprovals(baseUrl: String): Result<List<PendingApprovalRequest>> =
        executeBackendCall(baseUrl) { api, auth -> api.listApprovals(auth) }

    suspend fun fetchProviders(baseUrl: String): Result<List<AiProviderConfig>> =
        executeBackendCall(baseUrl) { api, auth -> api.listProviders(auth) }

    suspend fun updateProvider(baseUrl: String, id: String, req: ProviderUpdateRequest): Result<Unit> =
        executeBackendCall(baseUrl) { api, auth -> api.updateProvider(id, req, auth) }.map { }

    suspend fun rotateProviderKey(baseUrl: String, id: String, key: String, expiresAt: String?): Result<Unit> =
        executeBackendCall(baseUrl) { api, auth -> api.rotateProviderKey(id, ProviderKeyRotateRequest(key, expiresAt), auth) }.map { }

    suspend fun fetchFeatureFlags(baseUrl: String): Result<List<FeatureFlagConfig>> =
        executeBackendCall(baseUrl) { api, auth -> api.listFeatureFlags(auth) }

    suspend fun updateFeatureFlag(baseUrl: String, flag: FeatureFlagConfig): Result<Unit> =
        executeBackendCall(baseUrl) { api, auth -> api.updateFeatureFlag(flag.key, flag, auth) }.map { }

    suspend fun fetchAnalytics(baseUrl: String, range: String): Result<AnalyticsSummaryDto> =
        executeBackendCall(baseUrl) { api, auth -> api.getAnalytics(range, auth) }

    suspend fun fetchSubscriptions(baseUrl: String): Result<List<SubscriptionPlanDto>> =
        executeBackendCall(baseUrl) { api, auth -> api.listSubscriptions(auth) }

    suspend fun fetchReleases(baseUrl: String): Result<List<AppReleaseDto>> =
        executeBackendCall(baseUrl) { api, auth -> api.listReleases(auth) }

    suspend fun fetchNotifications(baseUrl: String): Result<List<NotificationCampaignDto>> =
        executeBackendCall(baseUrl) { api, auth -> api.listNotifications(auth) }

    suspend fun sendNotification(baseUrl: String, req: NotificationDispatchRequest): Result<Unit> =
        executeBackendCall(baseUrl) { api, auth -> api.sendNotification(req, auth) }.map { }

    suspend fun fetchSupportTickets(baseUrl: String): Result<List<SupportTicketDto>> =
        executeBackendCall(baseUrl) { api, auth -> api.listSupportTickets(auth) }

    suspend fun fetchAutomationRules(baseUrl: String): Result<List<AutomationRuleDto>> =
        executeBackendCall(baseUrl) { api, auth -> api.listAutomationRules(auth) }

    suspend fun fetchBackups(baseUrl: String): Result<List<BackupRecordDto>> =
        executeBackendCall(baseUrl) { api, auth -> api.listBackups(auth) }

    suspend fun fetchRemoteAuditLogs(baseUrl: String): Result<List<AuditLogEntryDto>> =
        executeBackendCall(baseUrl) { api, auth -> api.listAuditLogs(auth) }

    private suspend fun <T> executeBackendCall(
        baseUrl: String,
        call: suspend (com.example.core.network.ZenBackendApiService, String?) -> retrofit2.Response<T>
    ): Result<T> {
        val api = NetworkClientFactory.createBackendApi(baseUrl)
            ?: return Result.failure(IllegalStateException("Backend API URL is not configured."))
        return try {
            val resp = call(api, backendAuthHeader())
            val body = resp.body()
            if (resp.isSuccessful && body != null) Result.success(body)
            else Result.failure(IllegalStateException("Backend returned HTTP ${resp.code()}"))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun exportSanitizedConfigJson(config: WorkspaceConfigEntity): String {
        val safeMap = mapOf(
            "exportedAt" to java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).format(java.util.Date()),
            "app" to "Zen AI Super Admin Control Studio",
            "firebaseProvisioned" to false,
            "firebaseProjectId" to config.firebaseProjectId.ifBlank { "not-configured" },
            "backendBaseUrl" to config.backendBaseUrl.ifBlank { "not-configured" },
            "githubRepository" to if (config.githubOwner.isNotBlank() && config.githubRepo.isNotBlank()) "${config.githubOwner}/${config.githubRepo}" else "not-configured",
            "darkThemeEnabled" to config.darkThemeEnabled,
            "sessionTimeoutMinutes" to config.sessionTimeoutMinutes,
            "retentionPolicyDays" to config.retentionPolicyDays,
            "secretsIncluded" to false
        )
        val adapter = NetworkClientFactory.moshi.adapter(Map::class.java)
        return adapter.indent("  ").toJson(safeMap)
    }

    companion object {
        fun defaultWidgets(): List<DashboardWidgetEntity> = listOf(
            DashboardWidgetEntity("w_users", "User Growth & Accounts", true, 1),
            DashboardWidgetEntity("w_ai_volume", "AI Requests & Modalities", true, 2),
            DashboardWidgetEntity("w_health", "Backend & Firebase Health", true, 3),
            DashboardWidgetEntity("w_github", "GitHub Actions & Releases", true, 4),
            DashboardWidgetEntity("w_alerts", "System Alerts & Incidents", true, 5)
        )
    }
}
