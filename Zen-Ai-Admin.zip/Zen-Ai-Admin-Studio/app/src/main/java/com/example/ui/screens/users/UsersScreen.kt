package com.example.ui.screens.users

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.NoteAdd
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.core.database.LocalAdminNoteEntity
import com.example.core.model.UiState
import com.example.core.model.ZenUserRecord
import com.example.ui.components.BackendSetupRequiredBanner
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.theme.LocalZenStatusColors
import com.example.ui.theme.MonoMetricStyle
import kotlinx.coroutines.flow.Flow

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UsersScreen(
    usersState: UiState<List<ZenUserRecord>>,
    onRefresh: () -> Unit,
    onOpenSettings: () -> Unit,
    onUserAction: (uid: String, action: String, reason: String, role: String?) -> Unit,
    observeNotes: (String, String) -> Flow<List<LocalAdminNoteEntity>>,
    onAddNote: (String, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf("all") }
    var selectedUser by remember { mutableStateOf<ZenUserRecord?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            EnterpriseGlassCard(accentBorder = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = stringResource(R.string.privacy_chat_notice),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search by Name, Email, or UID") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("users_search_input")
            )
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("all", "active", "suspended", "disabled").forEach { status ->
                    FilterChip(
                        selected = statusFilter == status,
                        onClick = { statusFilter = status },
                        label = { Text(status.replaceFirstChar { it.uppercase() }) }
                    )
                }
            }
        }

        when (usersState) {
            UiState.Loading -> item {
                Row(modifier = Modifier.fillMaxWidth().padding(24.dp), horizontalArrangement = Arrangement.Center) {
                    CircularProgressIndicator()
                }
            }
            is UiState.Error -> item {
                BackendSetupRequiredBanner(
                    moduleName = "User Management Center",
                    reason = usersState.message,
                    onOpenSettings = onOpenSettings,
                    onRetry = onRefresh
                )
            }
            is UiState.Success -> {
                val filtered = usersState.data.filter { user ->
                    val q = searchQuery.trim().lowercase()
                    val matchesQuery = q.isBlank() ||
                        user.name.lowercase().contains(q) ||
                        user.email.lowercase().contains(q) ||
                        user.uid.lowercase().contains(q)
                    val matchesStatus = statusFilter == "all" || user.status.equals(statusFilter, ignoreCase = true)
                    matchesQuery && matchesStatus
                }
                if (filtered.isEmpty()) {
                    item {
                        EnterpriseGlassCard {
                            Text("No users match your search or status filter.", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                } else {
                    items(filtered, key = { it.uid }) { user ->
                        EnterpriseGlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedUser = user }
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(user.name.ifBlank { "Unnamed User" }, style = MaterialTheme.typography.titleMedium)
                                    Text(user.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("UID: ${user.uid}", style = MonoMetricStyle, color = MaterialTheme.colorScheme.primary)
                                }
                                val tone = when (user.status.lowercase()) {
                                    "active" -> PillTone.HEALTHY
                                    "suspended" -> PillTone.WARNING
                                    else -> PillTone.CRITICAL
                                }
                                StatusPill(user.status.uppercase(), tone)
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Plan: ${user.plan}", style = MaterialTheme.typography.labelMedium)
                                Text("Visits: ${user.visits}", style = MaterialTheme.typography.labelMedium)
                                Text("AI Req: ${user.aiRequestCount}", style = MaterialTheme.typography.labelMedium)
                                if (user.appVersion.isNotBlank()) {
                                    Text("v${user.appVersion}", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    selectedUser?.let { user ->
        UserDetailDialog(
            user = user,
            observeNotes = observeNotes,
            onAddNote = { body -> onAddNote("user", user.uid, body) },
            onAction = { action, reason, role ->
                onUserAction(user.uid, action, reason, role)
                selectedUser = null
            },
            onDismiss = { selectedUser = null }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun UserDetailDialog(
    user: ZenUserRecord,
    observeNotes: (String, String) -> Flow<List<LocalAdminNoteEntity>>,
    onAddNote: (String) -> Unit,
    onAction: (action: String, reason: String, role: String?) -> Unit,
    onDismiss: () -> Unit
) {
    val notes by observeNotes("user", user.uid).collectAsStateWithLifecycle(initialValue = emptyList())
    var reason by remember { mutableStateOf("") }
    var newNote by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(user.name.ifBlank { user.email }) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("UID: ${user.uid}", style = MonoMetricStyle, color = MaterialTheme.colorScheme.primary)
                Text("Email: ${user.email} · Provider: ${user.provider}", style = MaterialTheme.typography.bodySmall)
                Text("Created: ${user.createdAt} · Last Login: ${user.lastLogin}", style = MaterialTheme.typography.bodySmall)
                Text("App Version: ${user.appVersion.ifBlank { "Unknown" }} · Role: ${user.role}", style = MaterialTheme.typography.bodySmall)
                if (!user.deviceSummary.isNullOrBlank()) {
                    Text("Disclosed Device: ${user.deviceSummary}", style = MaterialTheme.typography.bodySmall)
                }
                Text(
                    "Metadata Only: AI Requests=${user.aiRequestCount}, Support Tickets=${user.supportTicketCount}. Private chat contents are inaccessible.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Action Reason / Audit Justification") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { onAction("activate", reason.ifBlank { "Admin activation" }, null) }) {
                        Text("Activate")
                    }
                    OutlinedButton(onClick = { onAction("suspend", reason.ifBlank { "Policy suspension" }, null) }) {
                        Text("Suspend")
                    }
                    OutlinedButton(onClick = { onAction("restore", reason.ifBlank { "Account restored" }, null) }) {
                        Text("Restore")
                    }
                    OutlinedButton(onClick = { onAction("disable", reason.ifBlank { "Account disabled" }, null) }) {
                        Text("Disable")
                    }
                    Button(
                        onClick = { onAction("delete", reason.ifBlank { "Retention verified deletion" }, null) },
                        colors = ButtonDefaults.buttonColors(containerColor = LocalZenStatusColors.current.critical)
                    ) {
                        Text("Delete")
                    }
                }

                Spacer(Modifier.height(4.dp))
                Text("Internal Admin Notes (${notes.size})", style = MaterialTheme.typography.titleSmall)
                notes.take(3).forEach { n ->
                    Text("• ${n.noteBody} (${n.authorEmail})", style = MaterialTheme.typography.bodySmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newNote,
                        onValueChange = { newNote = it },
                        label = { Text("Add private admin note") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(6.dp))
                    OutlinedButton(
                        onClick = {
                            if (newNote.isNotBlank()) {
                                onAddNote(newNote)
                                newNote = ""
                            }
                        }
                    ) {
                        Icon(Icons.AutoMirrored.Filled.NoteAdd, contentDescription = "Save note", modifier = Modifier.size(16.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
