package com.example.core.network

import com.example.core.model.GitHubArtifactsResponse
import com.example.core.model.GitHubBranchDto
import com.example.core.model.GitHubCommitItemDto
import com.example.core.model.GitHubReleaseDto
import com.example.core.model.GitHubRepoDto
import com.example.core.model.GitHubWorkflowRunsResponse
import com.example.core.model.GitHubWorkflowsResponse
import com.squareup.moshi.JsonClass
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

@JsonClass(generateAdapter = true)
data class WorkflowDispatchBody(
    val ref: String,
    val inputs: Map<String, String> = emptyMap()
)

interface GitHubApiService {
    @GET("rate_limit")
    suspend fun getRateLimit(
        @Header("Authorization") authHeader: String? = null
    ): Response<ResponseBody>

    @GET("repos/{owner}/{repo}")
    suspend fun getRepository(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Header("Authorization") authHeader: String? = null
    ): Response<GitHubRepoDto>

    @GET("repos/{owner}/{repo}/branches")
    suspend fun listBranches(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("per_page") perPage: Int = 20,
        @Header("Authorization") authHeader: String? = null
    ): Response<List<GitHubBranchDto>>

    @GET("repos/{owner}/{repo}/commits")
    suspend fun listCommits(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("per_page") perPage: Int = 20,
        @Header("Authorization") authHeader: String? = null
    ): Response<List<GitHubCommitItemDto>>

    @GET("repos/{owner}/{repo}/actions/workflows")
    suspend fun listWorkflows(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Header("Authorization") authHeader: String? = null
    ): Response<GitHubWorkflowsResponse>

    @GET("repos/{owner}/{repo}/actions/runs")
    suspend fun listWorkflowRuns(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("per_page") perPage: Int = 25,
        @Header("Authorization") authHeader: String? = null
    ): Response<GitHubWorkflowRunsResponse>

    @POST("repos/{owner}/{repo}/actions/workflows/{workflowId}/dispatches")
    suspend fun triggerWorkflowDispatch(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("workflowId") workflowId: Long,
        @Body body: WorkflowDispatchBody,
        @Header("Authorization") authHeader: String
    ): Response<Unit>

    @POST("repos/{owner}/{repo}/actions/runs/{runId}/cancel")
    suspend fun cancelWorkflowRun(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Path("runId") runId: Long,
        @Header("Authorization") authHeader: String
    ): Response<Unit>

    @GET("repos/{owner}/{repo}/actions/artifacts")
    suspend fun listArtifacts(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("per_page") perPage: Int = 20,
        @Header("Authorization") authHeader: String? = null
    ): Response<GitHubArtifactsResponse>

    @GET("repos/{owner}/{repo}/releases")
    suspend fun listReleases(
        @Path("owner") owner: String,
        @Path("repo") repo: String,
        @Query("per_page") perPage: Int = 15,
        @Header("Authorization") authHeader: String? = null
    ): Response<List<GitHubReleaseDto>>
}
