package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val ZenDarkColorScheme = darkColorScheme(
    primary = CyanElectric,
    onPrimary = OnCyanDark,
    primaryContainer = CyanContainerDark,
    onPrimaryContainer = CyanElectric,
    secondary = IndigoAccent,
    onSecondary = Color(0xFF0B0E32),
    secondaryContainer = IndigoContainerDark,
    onSecondaryContainer = Color(0xFFE0E7FF),
    tertiary = VioletTertiary,
    onTertiary = Color(0xFF220B38),
    tertiaryContainer = VioletContainerDark,
    onTertiaryContainer = Color(0xFFF3E8FF),
    background = ObsidianCanvas,
    onBackground = TextPrimaryDark,
    surface = ObsidianSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = ObsidianSurfaceHigh,
    onSurfaceVariant = TextSecondaryDark,
    surfaceContainerLowest = ObsidianCanvas,
    surfaceContainerLow = ObsidianSurfaceLow,
    surfaceContainer = ObsidianSurface,
    surfaceContainerHigh = ObsidianSurfaceHigh,
    surfaceContainerHighest = ObsidianSurfaceHighest,
    outline = ObsidianOutline,
    outlineVariant = ObsidianOutlineVariant,
    error = RoseCritical,
    onError = Color.White,
    errorContainer = RoseContainerDark,
    onErrorContainer = Color(0xFFFFD9E0)
)

private val ZenLightColorScheme = lightColorScheme(
    primary = CyanPrimaryLight,
    onPrimary = Color.White,
    primaryContainer = CyanContainerLight,
    onPrimaryContainer = Color(0xFF083344),
    secondary = IndigoSecondaryLight,
    onSecondary = Color.White,
    secondaryContainer = IndigoContainerLight,
    onSecondaryContainer = Color(0xFF1E1B4B),
    tertiary = VioletTertiaryLight,
    onTertiary = Color.White,
    tertiaryContainer = VioletContainerLight,
    onTertiaryContainer = Color(0xFF2E1065),
    background = SlateLightCanvas,
    onBackground = TextPrimaryLight,
    surface = SlateLightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = SlateLightSurfaceHigh,
    onSurfaceVariant = TextSecondaryLight,
    surfaceContainerLowest = SlateLightSurface,
    surfaceContainerLow = SlateLightSurfaceLow,
    surfaceContainer = SlateLightSurface,
    surfaceContainerHigh = SlateLightSurfaceHigh,
    surfaceContainerHighest = Color(0xFFD5DFEC),
    outline = SlateLightOutline,
    outlineVariant = Color(0xFFE2E8F0),
    error = Color(0xFFE11D48),
    onError = Color.White,
    errorContainer = Color(0xFFFFE4E6),
    onErrorContainer = Color(0xFF881337)
)

@Immutable
data class ZenStatusColors(
    val healthy: Color,
    val healthyContainer: Color,
    val warning: Color,
    val warningContainer: Color,
    val critical: Color,
    val criticalContainer: Color
)

val LocalZenStatusColors = staticCompositionLocalOf {
    ZenStatusColors(
        healthy = EmeraldHealthy,
        healthyContainer = EmeraldContainerDark,
        warning = AmberWarning,
        warningContainer = AmberContainerDark,
        critical = RoseCritical,
        criticalContainer = RoseContainerDark
    )
}

val ZenAdminShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp)
)

@Composable
fun ZenAdminTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) ZenDarkColorScheme else ZenLightColorScheme
    val statusColors = if (darkTheme) {
        ZenStatusColors(
            healthy = EmeraldHealthy,
            healthyContainer = EmeraldContainerDark,
            warning = AmberWarning,
            warningContainer = AmberContainerDark,
            critical = RoseCritical,
            criticalContainer = RoseContainerDark
        )
    } else {
        ZenStatusColors(
            healthy = Color(0xFF059669),
            healthyContainer = Color(0xFFD1FAE5),
            warning = Color(0xFFD97706),
            warningContainer = Color(0xFFFEF3C7),
            critical = Color(0xFFE11D48),
            criticalContainer = Color(0xFFFFE4E6)
        )
    }

    androidx.compose.runtime.CompositionLocalProvider(LocalZenStatusColors provides statusColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = ZenAdminTypography,
            shapes = ZenAdminShapes,
            content = content
        )
    }
}
