package com.example.ui.screens.github

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.database.WorkspaceConfigEntity
import com.example.core.model.UiState
import com.example.data.repository.GitHubSnapshot
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.theme.MonoMetricStyle

private enum class GitHubTab(val label: String) {
    WORKFLOWS("Workflows & Runs"),
    COMMITS("Commits & Branches"),
    ARTIFACTS("Artifacts & Releases")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GitHubControlScreen(
    config: WorkspaceConfigEntity,
    gitHubState: UiState<GitHubSnapshot>,
    hasToken: Boolean,
    onFetchRepo: (owner: String, repo: String) -> Unit,
    onTriggerWorkflow: (workflowId: Long, name: String, ref: String) -> Unit,
    onCancelRun: (runId: Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var ownerInput by remember(config.githubOwner) { mutableStateOf(config.githubOwner) }
    var repoInput by remember(config.githubRepo) { mutableStateOf(config.githubRepo) }
    var activeTab by remember { mutableStateOf(GitHubTab.WORKFLOWS) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            EnterpriseGlassCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Code, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("Live GitHub REST API v3", style = MaterialTheme.typography.titleMedium)
                    }
                    StatusPill(
                        text = if (hasToken) "Keystore PAT Active" else "Public Read Mode",
                        tone = if (hasToken) PillTone.HEALTHY else PillTone.INFO
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = ownerInput,
                        onValueChange = { ownerInput = it },
                        label = { Text("Owner / Org") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("github_owner_input")
                    )
                    OutlinedTextField(
                        value = repoInput,
                        onValueChange = { repoInput = it },
                        label = { Text("Repository") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("github_repo_input")
                    )
                }
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { onFetchRepo(ownerInput, repoInput) },
                    enabled = ownerInput.isNotBlank() && repoInput.isNotBlank(),
                    modifier = Modifier.testTag("github_fetch_btn")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Sync Live Repository Data")
                }
            }
        }

        item {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GitHubTab.entries.forEach { tab ->
                    FilterChip(
                        selected = activeTab == tab,
                        onClick = { activeTab = tab },
                        label = { Text(tab.label) }
                    )
                }
            }
        }

        when (gitHubState) {
            UiState.Loading -> item {
                Row(modifier = Modifier.fillMaxWidth().padding(24.dp), horizontalArrangement = Arrangement.Center) {
                    CircularProgressIndicator()
                }
            }
            is UiState.Error -> item {
                EnterpriseGlassCard(accentBorder = MaterialTheme.colorScheme.outline) {
                    Text("GitHub Connection Status", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(gitHubState.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Tip: You can inspect any public repository immediately (for example Owner: `JetBrains`, Repo: `kotlin`), or add a Keystore-encrypted token in Settings for private repos and workflow dispatch.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            is UiState.Success -> {
                val snap = gitHubState.data
                item {
                    EnterpriseGlassCard {
                        Text(snap.repo?.full_name ?: "$ownerInput/$repoInput", style = MaterialTheme.typography.titleLarge)
                        Text(
                            text = snap.repo?.description ?: "No repository description",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Branch: ${snap.repo?.default_branch ?: "main"} · Issues: ${snap.repo?.open_issues_count ?: 0} · Rate Limit: ${snap.rateLimitStatus}",
                            style = MonoMetricStyle,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                when (activeTab) {
                    GitHubTab.WORKFLOWS -> {
                        if (snap.workflows.isEmpty()) {
                            item {
                                EnterpriseGlassCard {
                                    Text("No GitHub Actions workflows found in this repository.", style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        } else {
                            items(snap.workflows, key = { it.id }) { wf ->
                                EnterpriseGlassCard {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(wf.name, style = MaterialTheme.typography.titleMedium)
                                            Text(wf.path, style = MonoMetricStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                onTriggerWorkflow(wf.id, wf.name, snap.repo?.default_branch ?: "main")
                                            }
                                        ) {
                                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Run")
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            Text("Recent Workflow Executions (${snap.workflowRuns.size})", style = MaterialTheme.typography.titleMedium)
                        }
                        items(snap.workflowRuns, key = { it.id }) { run ->
                            EnterpriseGlassCard {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${run.name ?: "Workflow"} #${run.run_number}", style = MaterialTheme.typography.titleSmall)
                                        Text(
                                            text = "Branch: ${run.head_branch ?: "?"} · SHA: ${run.head_sha.take(7)} · Event: ${run.event ?: "?"}",
                                            style = MonoMetricStyle,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    val conclusion = run.conclusion ?: run.status ?: "unknown"
                                    val tone = when (conclusion) {
                                        "success" -> PillTone.HEALTHY
                                        "failure", "cancelled" -> PillTone.CRITICAL
                                        else -> PillTone.WARNING
                                    }
                                    StatusPill(conclusion, tone)
                                }
                                if (run.status == "in_progress" || run.status == "queued") {
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedButton(onClick = { onCancelRun(run.id) }) {
                                        Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Cancel Run")
                                    }
                                }
                            }
                        }
                    }

                    GitHubTab.COMMITS -> {
                        item {
                            EnterpriseGlassCard {
                                Text("Branches (${snap.branches.size})", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(6.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    snap.branches.forEach { b ->
                                        StatusPill(if (b.protected) "${b.name} (protected)" else b.name, PillTone.INFO)
                                    }
                                }
                            }
                        }
                        items(snap.commits, key = { it.sha }) { c ->
                            EnterpriseGlassCard {
                                Text(c.commit.message.lines().firstOrNull().orEmpty(), style = MaterialTheme.typography.titleSmall)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "${c.sha.take(7)} · ${c.commit.author.name} · ${c.commit.author.date}",
                                    style = MonoMetricStyle,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    GitHubTab.ARTIFACTS -> {
                        item { Text("Build Artifacts (${snap.artifacts.size})", style = MaterialTheme.typography.titleMedium) }
                        items(snap.artifacts, key = { it.id }) { art ->
                            EnterpriseGlassCard {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(art.name, style = MaterialTheme.typography.titleSmall)
                                        Text("${art.size_in_bytes / 1024} KB · ${art.created_at}", style = MonoMetricStyle)
                                    }
                                    StatusPill(if (art.expired) "Expired" else "Ready", if (art.expired) PillTone.NEUTRAL else PillTone.HEALTHY)
                                }
                            }
                        }
                        item { Text("Releases (${snap.releases.size})", style = MaterialTheme.typography.titleMedium) }
                        items(snap.releases, key = { it.id }) { rel ->
                            EnterpriseGlassCard {
                                Text("${rel.tag_name} — ${rel.name ?: rel.tag_name}", style = MaterialTheme.typography.titleSmall)
                                Text(rel.published_at ?: "Draft", style = MonoMetricStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
