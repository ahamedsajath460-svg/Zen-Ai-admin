package com.example.core.model

import com.squareup.moshi.JsonClass

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String, val isRetryable: Boolean = true) : UiState<Nothing>
}

enum class ConnectionMode {
    NOT_CONFIGURED,
    FIREBASE_DECLINED,
    CONNECTING,
    CONNECTED,
    ERROR
}

enum class AdminRole(
    val displayName: String,
    val level: Int,
    val description: String,
    val permissions: Set<AdminPermission>
) {
    SUPER_ADMIN(
        displayName = "Super Admin",
        level = 100,
        description = "Full root governance, admin role grants, key rotation, and destructive approvals.",
        permissions = AdminPermission.entries.toSet()
    ),
    ADMIN(
        displayName = "Admin",
        level = 80,
        description = "User lifecycle, feature flags, releases, subscriptions, and support management.",
        permissions = setOf(
            AdminPermission.VIEW_DASHBOARD,
            AdminPermission.MANAGE_USERS,
            AdminPermission.MANAGE_FEATURES,
            AdminPermission.MANAGE_RELEASES,
            AdminPermission.MANAGE_SUBSCRIPTIONS,
            AdminPermission.SEND_NOTIFICATIONS,
            AdminPermission.MANAGE_SUPPORT,
            AdminPermission.USE_AI_ASSISTANT,
            AdminPermission.VIEW_AUDIT_LOGS
        )
    ),
    TECHNICAL_ADMIN(
        displayName = "Technical Admin",
        level = 70,
        description = "AI provider routing, GitHub Actions builds, system monitoring, and automation.",
        permissions = setOf(
            AdminPermission.VIEW_DASHBOARD,
            AdminPermission.MANAGE_PROVIDERS,
            AdminPermission.MANAGE_FEATURES,
            AdminPermission.MANAGE_RELEASES,
            AdminPermission.MANAGE_GITHUB,
            AdminPermission.VIEW_MONITORING,
            AdminPermission.MANAGE_AUTOMATION,
            AdminPermission.MANAGE_BACKUPS,
            AdminPermission.USE_AI_ASSISTANT,
            AdminPermission.VIEW_AUDIT_LOGS
        )
    ),
    SUPPORT_ADMIN(
        displayName = "Support Admin",
        level = 50,
        description = "User support queue, account status triage, and customer communications.",
        permissions = setOf(
            AdminPermission.VIEW_DASHBOARD,
            AdminPermission.MANAGE_USERS,
            AdminPermission.MANAGE_SUPPORT,
            AdminPermission.VIEW_AUDIT_LOGS
        )
    ),
    ANALYTICS_ADMIN(
        displayName = "Analytics Admin",
        level = 40,
        description = "Usage telemetry, cost diagnostics, report export, and AI insights.",
        permissions = setOf(
            AdminPermission.VIEW_DASHBOARD,
            AdminPermission.VIEW_ANALYTICS,
            AdminPermission.VIEW_MONITORING,
            AdminPermission.USE_AI_ASSISTANT,
            AdminPermission.VIEW_AUDIT_LOGS
        )
    ),
    READ_ONLY_ADMIN(
        displayName = "Read-Only Admin",
        level = 10,
        description = "Strict observer access across telemetry and logs with zero mutation rights.",
        permissions = setOf(
            AdminPermission.VIEW_DASHBOARD,
            AdminPermission.VIEW_ANALYTICS,
            AdminPermission.VIEW_MONITORING,
            AdminPermission.VIEW_AUDIT_LOGS
        )
    )
}

enum class AdminPermission(val label: String) {
    VIEW_DASHBOARD("View Executive Telemetry"),
    MANAGE_USERS("Suspend/Activate/Delete Users"),
    MANAGE_ROLES("Assign & Revoke Admin Roles"),
    MANAGE_PROVIDERS("Configure AI Providers & Key Rotation"),
    MANAGE_FEATURES("Toggle Global Feature Flags"),
    VIEW_ANALYTICS("Access Usage & Cost Analytics"),
    MANAGE_SUBSCRIPTIONS("Edit Plans & Quotas"),
    MANAGE_RELEASES("Approve Releases & Mandatory Updates"),
    MANAGE_GITHUB("Trigger & Cancel GitHub Workflows"),
    VIEW_MONITORING("Inspect System Health & Incidents"),
    SEND_NOTIFICATIONS("Dispatch FCM Announcements"),
    MANAGE_SUPPORT("Resolve Support Tickets"),
    MANAGE_AUTOMATION("Configure Automation Rules"),
    USE_AI_ASSISTANT("Query AI Admin Assistant"),
    MANAGE_SECURITY("Revoke Sessions & Enforce MFA"),
    MANAGE_BACKUPS("Run Exports & Restore Approvals"),
    VIEW_AUDIT_LOGS("Inspect Immutable Audit Logs")
}

enum class DateRangeFilter(val label: String, val apiValue: String) {
    DAY_24H("24h", "24h"),
    DAYS_7("7d", "7d"),
    DAYS_30("30d", "30d"),
    DAYS_90("90d", "90d")
}

enum class ServiceStatus(val label: String) {
    HEALTHY("Operational"),
    DEGRADED("Degraded"),
    UNCONFIGURED("Setup Required"),
    OFFLINE("Unavailable")
}

@JsonClass(generateAdapter = true)
data class BackendOverviewResponse(
    val totalUsers: Long = 0,
    val activeUsers: Long = 0,
    val newUsersToday: Long = 0,
    val newUsersWeek: Long = 0,
    val newUsersMonth: Long = 0,
    val onlineUsers: Long? = null,
    val suspendedUsers: Long = 0,
    val deletedUsers: Long = 0,
    val totalConversations: Long = 0,
    val totalAiRequests: Long = 0,
    val imageGenRequests: Long = 0,
    val screenVisionRequests: Long = 0,
    val agentControlRequests: Long = 0,
    val apiErrors: Long = 0,
    val latestAppVersion: String = "Not Reported",
    val latestBuildStatus: String = "Unknown",
    val firebaseHealth: String = "Unconfigured",
    val backendHealth: String = "Unconfigured",
    val dailySeries: List<DailyMetricPoint> = emptyList(),
    val alerts: List<SystemAlertDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class DailyMetricPoint(
    val label: String,
    val requests: Long,
    val errors: Long,
    val activeUsers: Long
)

@JsonClass(generateAdapter = true)
data class SystemAlertDto(
    val id: String,
    val severity: String,
    val title: String,
    val detail: String,
    val timestamp: String
)

@JsonClass(generateAdapter = true)
data class ZenUserRecord(
    val uid: String,
    val name: String,
    val email: String,
    val photo: String? = null,
    val provider: String = "google.com",
    val createdAt: String = "",
    val lastLogin: String = "",
    val visits: Long = 0,
    val appVersion: String = "",
    val status: String = "active",
    val plan: String = "free",
    val role: String = "user",
    val deviceSummary: String? = null,
    val aiRequestCount: Long = 0,
    val supportTicketCount: Int = 0,
    val adminNotes: String = ""
)

@JsonClass(generateAdapter = true)
data class AdminAccountRecord(
    val uid: String,
    val email: String,
    val displayName: String,
    val role: String,
    val mfaEnabled: Boolean = false,
    val lastLoginAt: String = "",
    val expiresAt: String? = null,
    val activeSessions: Int = 1,
    val status: String = "active"
)

@JsonClass(generateAdapter = true)
data class PendingApprovalRequest(
    val id: String,
    val requestedBy: String,
    val actionType: String,
    val targetSummary: String,
    val requestedAt: String,
    val status: String = "pending"
)

@JsonClass(generateAdapter = true)
data class AiProviderConfig(
    val id: String,
    val name: String,
    val enabled: Boolean,
    val status: String,
    val primaryFor: List<String> = emptyList(),
    val fallbackFor: List<String> = emptyList(),
    val activeModel: String,
    val availableModels: List<String> = emptyList(),
    val maskedKeyPreview: String = "Not Set",
    val keyLastRotated: String = "Never",
    val keyExpiresAt: String? = null,
    val requestCount: Long = 0,
    val errorCount: Long = 0,
    val avgLatencyMs: Long = 0,
    val rateLimitRemaining: Int? = null,
    val emergencyShutdown: Boolean = false
)

enum class AiCapabilityChannel(val label: String, val key: String) {
    TEXT_CHAT("Text Chat", "text_chat"),
    IMAGE_GEN("Image Generation", "image_gen"),
    WEB_SEARCH("Web Search", "web_search"),
    SCREEN_VISION("Screen Vision", "screen_vision"),
    VOICE_ASSIST("Voice Assistance", "voice_assist"),
    AI_AGENT("AI Agent", "ai_agent"),
    ADVANCED_REASONING("Advanced Reasoning", "advanced_reasoning")
}

@JsonClass(generateAdapter = true)
data class FeatureFlagConfig(
    val key: String,
    val displayName: String,
    val category: String,
    val enabled: Boolean,
    val maintenanceMode: Boolean = false,
    val rolloutPercentage: Int = 100,
    val minAppVersion: String = "1.0.0",
    val allowedRoles: List<String> = listOf("all"),
    val betaOnly: Boolean = false,
    val announcement: String = "",
    val clientEnforced: Boolean = false
)

@JsonClass(generateAdapter = true)
data class AnalyticsSummaryDto(
    val totalRequests: Long = 0,
    val successfulRequests: Long = 0,
    val failedRequests: Long = 0,
    val avgResponseMs: Long = 0,
    val totalTokens: Long? = null,
    val imageGenerations: Long = 0,
    val searchRequests: Long = 0,
    val agentTasks: Long = 0,
    val estimatedCostUsd: Double? = null,
    val actualBilledUsd: Double? = null,
    val byProvider: List<BreakdownMetric> = emptyList(),
    val byFeature: List<BreakdownMetric> = emptyList()
)

@JsonClass(generateAdapter = true)
data class BreakdownMetric(
    val name: String,
    val requests: Long,
    val errors: Long,
    val avgLatencyMs: Long
)

@JsonClass(generateAdapter = true)
data class SubscriptionPlanDto(
    val id: String,
    val name: String,
    val tier: String,
    val monthlyRequestsLimit: Long,
    val dailyImageLimit: Int,
    val voiceMinutesLimit: Int,
    val activeSubscribers: Long = 0,
    val trialDays: Int = 0,
    val enabled: Boolean = true,
    val billingProviderNote: String = "Managed externally via compliant billing processor"
)

@JsonClass(generateAdapter = true)
data class AppReleaseDto(
    val id: String,
    val versionName: String,
    val versionCode: Int,
    val channel: String,
    val minSupportedVersion: String,
    val mandatoryUpdate: Boolean,
    val maintenanceBanner: String = "",
    val releaseNotes: String = "",
    val apkDownloadUrl: String = "",
    val approvalStatus: String = "pending",
    val createdAt: String = ""
)

@JsonClass(generateAdapter = true)
data class NotificationCampaignDto(
    val id: String,
    val title: String,
    val body: String,
    val type: String,
    val targetAudience: String,
    val targetFilter: String = "all",
    val scheduledAt: String? = null,
    val status: String = "queued",
    val deliveredCount: Long = 0,
    val failedCount: Long = 0
)

@JsonClass(generateAdapter = true)
data class SupportTicketDto(
    val id: String,
    val uid: String,
    val userEmail: String,
    val category: String,
    val priority: String,
    val subject: String,
    val status: String,
    val createdAt: String,
    val adminNotes: String = ""
)

@JsonClass(generateAdapter = true)
data class AutomationRuleDto(
    val id: String,
    val name: String,
    val triggerCondition: String,
    val actionSummary: String,
    val enabled: Boolean,
    val requiresApproval: Boolean = false,
    val lastExecutedAt: String? = null,
    val lastOutcome: String = "Never executed"
)

@JsonClass(generateAdapter = true)
data class BackupRecordDto(
    val id: String,
    val scope: String,
    val status: String,
    val createdAt: String,
    val sizeBytes: Long = 0,
    val verified: Boolean = false
)

@JsonClass(generateAdapter = true)
data class AuditLogEntryDto(
    val id: String,
    val actorUid: String,
    val actorRole: String,
    val action: String,
    val target: String,
    val outcome: String,
    val timestamp: String,
    val details: String = ""
)

@JsonClass(generateAdapter = true)
data class SystemHealthProbeDto(
    val serviceName: String,
    val status: String,
    val latencyMs: Long?,
    val detail: String,
    val checkedAt: String
)

// GitHub REST API Models (Live Integration)
@JsonClass(generateAdapter = true)
data class GitHubRepoDto(
    val id: Long = 0,
    val name: String = "",
    val full_name: String = "",
    val description: String? = null,
    val default_branch: String = "main",
    val private: Boolean = false,
    val open_issues_count: Int = 0,
    val stargazers_count: Int = 0,
    val updated_at: String = ""
)

@JsonClass(generateAdapter = true)
data class GitHubBranchDto(
    val name: String = "",
    val protected: Boolean = false
)

@JsonClass(generateAdapter = true)
data class GitHubCommitItemDto(
    val sha: String = "",
    val commit: GitHubCommitMetaDto = GitHubCommitMetaDto()
)

@JsonClass(generateAdapter = true)
data class GitHubCommitMetaDto(
    val message: String = "",
    val author: GitHubCommitAuthorDto = GitHubCommitAuthorDto()
)

@JsonClass(generateAdapter = true)
data class GitHubCommitAuthorDto(
    val name: String = "",
    val date: String = ""
)

@JsonClass(generateAdapter = true)
data class GitHubWorkflowsResponse(
    val total_count: Int = 0,
    val workflows: List<GitHubWorkflowDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class GitHubWorkflowDto(
    val id: Long = 0,
    val name: String = "",
    val path: String = "",
    val state: String = ""
)

@JsonClass(generateAdapter = true)
data class GitHubWorkflowRunsResponse(
    val total_count: Int = 0,
    val workflow_runs: List<GitHubWorkflowRunDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class GitHubWorkflowRunDto(
    val id: Long = 0,
    val name: String? = null,
    val head_branch: String? = null,
    val head_sha: String = "",
    val status: String? = null,
    val conclusion: String? = null,
    val event: String? = null,
    val run_number: Int = 0,
    val created_at: String = "",
    val updated_at: String = "",
    val html_url: String = ""
)

@JsonClass(generateAdapter = true)
data class GitHubArtifactsResponse(
    val total_count: Int = 0,
    val artifacts: List<GitHubArtifactDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class GitHubArtifactDto(
    val id: Long = 0,
    val name: String = "",
    val size_in_bytes: Long = 0,
    val expired: Boolean = false,
    val created_at: String = "",
    val archive_download_url: String = ""
)

@JsonClass(generateAdapter = true)
data class GitHubReleaseDto(
    val id: Long = 0,
    val tag_name: String = "",
    val name: String? = null,
    val prerelease: Boolean = false,
    val draft: Boolean = false,
    val published_at: String? = null,
    val body: String? = null,
    val html_url: String = ""
)
