package com.example.core.network

import com.example.core.model.AdminAccountRecord
import com.example.core.model.AiProviderConfig
import com.example.core.model.AnalyticsSummaryDto
import com.example.core.model.AppReleaseDto
import com.example.core.model.AuditLogEntryDto
import com.example.core.model.AutomationRuleDto
import com.example.core.model.BackendOverviewResponse
import com.example.core.model.BackupRecordDto
import com.example.core.model.FeatureFlagConfig
import com.example.core.model.NotificationCampaignDto
import com.example.core.model.PendingApprovalRequest
import com.example.core.model.SubscriptionPlanDto
import com.example.core.model.SupportTicketDto
import com.example.core.model.SystemHealthProbeDto
import com.example.core.model.ZenUserRecord
import com.squareup.moshi.JsonClass
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

@JsonClass(generateAdapter = true)
data class UserActionRequest(
    val action: String,
    val reason: String = "",
    val role: String? = null,
    val adminNote: String? = null
)

@JsonClass(generateAdapter = true)
data class ProviderUpdateRequest(
    val enabled: Boolean,
    val activeModel: String,
    val emergencyShutdown: Boolean,
    val primaryFor: List<String> = emptyList(),
    val fallbackFor: List<String> = emptyList()
)

@JsonClass(generateAdapter = true)
data class ProviderKeyRotateRequest(
    val apiKey: String,
    val expiresAt: String? = null
)

@JsonClass(generateAdapter = true)
data class NotificationDispatchRequest(
    val title: String,
    val body: String,
    val type: String,
    val targetAudience: String,
    val targetFilter: String,
    val scheduledAt: String? = null
)

@JsonClass(generateAdapter = true)
data class GenericMutationResponse(
    val ok: Boolean = true,
    val message: String = ""
)

interface ZenBackendApiService {
    @GET("health")
    suspend fun getSystemHealth(
        @Header("Authorization") bearer: String? = null
    ): Response<List<SystemHealthProbeDto>>

    @GET("admin/overview")
    suspend fun getOverview(
        @Query("range") range: String,
        @Header("Authorization") bearer: String? = null
    ): Response<BackendOverviewResponse>

    @GET("admin/users")
    suspend fun listUsers(
        @Query("q") query: String? = null,
        @Query("status") status: String? = null,
        @Header("Authorization") bearer: String? = null
    ): Response<List<ZenUserRecord>>

    @POST("admin/users/{uid}/action")
    suspend fun performUserAction(
        @Path("uid") uid: String,
        @Body body: UserActionRequest,
        @Header("Authorization") bearer: String? = null
    ): Response<GenericMutationResponse>

    @GET("admin/roles")
    suspend fun listAdmins(
        @Header("Authorization") bearer: String? = null
    ): Response<List<AdminAccountRecord>>

    @GET("admin/approvals")
    suspend fun listApprovals(
        @Header("Authorization") bearer: String? = null
    ): Response<List<PendingApprovalRequest>>

    @GET("admin/providers")
    suspend fun listProviders(
        @Header("Authorization") bearer: String? = null
    ): Response<List<AiProviderConfig>>

    @POST("admin/providers/{providerId}")
    suspend fun updateProvider(
        @Path("providerId") providerId: String,
        @Body body: ProviderUpdateRequest,
        @Header("Authorization") bearer: String? = null
    ): Response<GenericMutationResponse>

    @POST("admin/providers/{providerId}/rotate-key")
    suspend fun rotateProviderKey(
        @Path("providerId") providerId: String,
        @Body body: ProviderKeyRotateRequest,
        @Header("Authorization") bearer: String? = null
    ): Response<GenericMutationResponse>

    @GET("admin/features")
    suspend fun listFeatureFlags(
        @Header("Authorization") bearer: String? = null
    ): Response<List<FeatureFlagConfig>>

    @POST("admin/features/{key}")
    suspend fun updateFeatureFlag(
        @Path("key") key: String,
        @Body flag: FeatureFlagConfig,
        @Header("Authorization") bearer: String? = null
    ): Response<GenericMutationResponse>

    @GET("admin/analytics")
    suspend fun getAnalytics(
        @Query("range") range: String,
        @Header("Authorization") bearer: String? = null
    ): Response<AnalyticsSummaryDto>

    @GET("admin/subscriptions")
    suspend fun listSubscriptions(
        @Header("Authorization") bearer: String? = null
    ): Response<List<SubscriptionPlanDto>>

    @GET("admin/releases")
    suspend fun listReleases(
        @Header("Authorization") bearer: String? = null
    ): Response<List<AppReleaseDto>>

    @POST("admin/releases")
    suspend fun createRelease(
        @Body release: AppReleaseDto,
        @Header("Authorization") bearer: String? = null
    ): Response<GenericMutationResponse>

    @GET("admin/notifications")
    suspend fun listNotifications(
        @Header("Authorization") bearer: String? = null
    ): Response<List<NotificationCampaignDto>>

    @POST("admin/notifications")
    suspend fun sendNotification(
        @Body request: NotificationDispatchRequest,
        @Header("Authorization") bearer: String? = null
    ): Response<GenericMutationResponse>

    @GET("admin/support")
    suspend fun listSupportTickets(
        @Header("Authorization") bearer: String? = null
    ): Response<List<SupportTicketDto>>

    @GET("admin/automation")
    suspend fun listAutomationRules(
        @Header("Authorization") bearer: String? = null
    ): Response<List<AutomationRuleDto>>

    @GET("admin/backups")
    suspend fun listBackups(
        @Header("Authorization") bearer: String? = null
    ): Response<List<BackupRecordDto>>

    @GET("admin/audit-logs")
    suspend fun listAuditLogs(
        @Header("Authorization") bearer: String? = null
    ): Response<List<AuditLogEntryDto>>
}
