package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Enterprise Obsidian Dark Palette
val ObsidianCanvas = Color(0xFF070B14)
val ObsidianSurface = Color(0xFF0D1424)
val ObsidianSurfaceLow = Color(0xFF0A101D)
val ObsidianSurfaceHigh = Color(0xFF151F34)
val ObsidianSurfaceHighest = Color(0xFF1D2A44)
val ObsidianOutline = Color(0xFF283755)
val ObsidianOutlineVariant = Color(0xFF1B263B)

val CyanElectric = Color(0xFF22D3EE)
val CyanContainerDark = Color(0xFF0A3A4A)
val OnCyanDark = Color(0xFF031F28)

val IndigoAccent = Color(0xFF818CF8)
val IndigoContainerDark = Color(0xFF1E2252)

val VioletTertiary = Color(0xFFC084FC)
val VioletContainerDark = Color(0xFF391D52)

val TextPrimaryDark = Color(0xFFF1F5F9)
val TextSecondaryDark = Color(0xFF94A3B8)

// Semantic Status Colors
val EmeraldHealthy = Color(0xFF10B981)
val EmeraldContainerDark = Color(0xFF0B3529)
val AmberWarning = Color(0xFFF59E0B)
val AmberContainerDark = Color(0xFF3F2A06)
val RoseCritical = Color(0xFFF43F5E)
val RoseContainerDark = Color(0xFF47111F)

// Optional Enterprise Light Palette
val SlateLightCanvas = Color(0xFFF4F7FB)
val SlateLightSurface = Color(0xFFFFFFFF)
val SlateLightSurfaceLow = Color(0xFFEDF2F8)
val SlateLightSurfaceHigh = Color(0xFFE2E8F0)
val SlateLightOutline = Color(0xFFCBD5E1)

val CyanPrimaryLight = Color(0xFF0891B2)
val CyanContainerLight = Color(0xFFCFFAFE)
val IndigoSecondaryLight = Color(0xFF4F46E5)
val IndigoContainerLight = Color(0xFFE0E7FF)
val VioletTertiaryLight = Color(0xFF7C3AED)
val VioletContainerLight = Color(0xFFEDE9FE)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
