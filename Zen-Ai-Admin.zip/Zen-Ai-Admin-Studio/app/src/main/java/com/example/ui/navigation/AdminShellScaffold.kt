package com.example.ui.navigation

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PermanentDrawerSheet
import androidx.compose.material3.PermanentNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.core.database.DashboardWidgetEntity
import com.example.core.database.LocalAuditLogEntity
import com.example.core.database.WorkspaceConfigEntity
import com.example.core.model.ConnectionMode
import com.example.core.model.UiState
import com.example.core.security.AdminSessionState
import com.example.ui.components.PillTone
import com.example.ui.components.ReAuthConfirmationDialog
import com.example.ui.components.StatusPill
import com.example.ui.screens.analytics.AiAnalyticsScreen
import com.example.ui.screens.assistant.AiAssistantScreen
import com.example.ui.screens.audit.AuditLogsScreen
import com.example.ui.screens.automation.AutomationScreen
import com.example.ui.screens.backup.BackupCenterScreen
import com.example.ui.screens.features.FeatureControlScreen
import com.example.ui.screens.github.GitHubControlScreen
import com.example.ui.screens.monitoring.SystemMonitoringScreen
import com.example.ui.screens.notifications.NotificationsScreen
import com.example.ui.screens.overview.OverviewScreen
import com.example.ui.screens.providers.AiProvidersScreen
import com.example.ui.screens.releases.AppReleasesScreen
import com.example.ui.screens.roles.AdminRolesScreen
import com.example.ui.screens.security.SecurityCenterScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.subscriptions.SubscriptionsScreen
import com.example.ui.screens.support.SupportCenterScreen
import com.example.ui.screens.users.UsersScreen
import com.example.ui.state.AdminDashboardUiState
import com.example.ui.state.ZenAdminViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminShellScaffold(
    viewModel: ZenAdminViewModel,
    sessionState: AdminSessionState,
    uiState: AdminDashboardUiState,
    config: WorkspaceConfigEntity,
    widgets: List<DashboardWidgetEntity>,
    localAuditLogs: List<LocalAuditLogEntity>
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: AdminModule.OVERVIEW.route
    val currentModule = AdminModule.entries.firstOrNull { it.route == currentRoute } ?: AdminModule.OVERVIEW

    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var showCommandCenter by remember { mutableStateOf(false) }
    var showNotificationsSheet by remember { mutableStateOf(false) }
    var sidebarCollapsed by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.statusBanner) {
        val msg = uiState.statusBanner
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusBanner()
        }
    }

    val navigateToModule: (AdminModule) -> Unit = { module ->
        navController.navigate(module.route) {
            popUpTo(AdminModule.OVERVIEW.route) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
        scope.launch { drawerState.close() }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 840.dp

        val shellContent: @Composable () -> Unit = {
            Scaffold(
                contentWindowInsets = WindowInsets.statusBars,
                snackbarHost = { SnackbarHost(snackbarHostState) },
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                        ),
                        navigationIcon = {
                            IconButton(
                                onClick = {
                                    if (isWideScreen) sidebarCollapsed = !sidebarCollapsed
                                    else scope.launch { drawerState.open() }
                                },
                                modifier = Modifier.testTag("nav_drawer_toggle_btn")
                            ) {
                                Icon(Icons.Default.Menu, contentDescription = "Toggle navigation sidebar")
                            }
                        },
                        title = {
                            Column {
                                Text(currentModule.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text(
                                    text = "${sessionState.activeRole.displayName} · ${sessionState.adminEmail}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        actions = {
                            val (statusText, statusTone) = when (uiState.connectionMode) {
                                ConnectionMode.CONNECTED -> "Online" to PillTone.HEALTHY
                                ConnectionMode.CONNECTING -> "Syncing" to PillTone.INFO
                                ConnectionMode.ERROR -> "Backend Err" to PillTone.CRITICAL
                                else -> "Local/Setup" to PillTone.WARNING
                            }
                            StatusPill(text = statusText, tone = statusTone, modifier = Modifier.padding(end = 4.dp))
                            IconButton(
                                onClick = { showCommandCenter = true },
                                modifier = Modifier.testTag("global_command_center_btn")
                            ) {
                                Icon(Icons.Default.Search, contentDescription = "Global Command Center")
                            }
                            IconButton(
                                onClick = { showNotificationsSheet = true },
                                modifier = Modifier.testTag("notification_center_btn")
                            ) {
                                Icon(Icons.Default.Notifications, contentDescription = "Notification Center")
                            }
                        }
                    )
                },
                bottomBar = {
                    if (!isWideScreen) {
                        NavigationBar(
                            windowInsets = WindowInsets.navigationBars,
                            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                        ) {
                            val quickModules = listOf(
                                AdminModule.OVERVIEW,
                                AdminModule.USERS,
                                AdminModule.GITHUB_CONTROL,
                                AdminModule.AI_ASSISTANT,
                                AdminModule.SETTINGS
                            )
                            quickModules.forEach { mod ->
                                NavigationBarItem(
                                    selected = currentModule == mod,
                                    onClick = { navigateToModule(mod) },
                                    icon = { Icon(mod.icon, contentDescription = mod.shortTitle) },
                                    label = { Text(mod.shortTitle) },
                                    modifier = Modifier.testTag("bottom_nav_${mod.route}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = AdminModule.OVERVIEW.route,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    composable(AdminModule.OVERVIEW.route) {
                        OverviewScreen(
                            uiState = uiState,
                            config = config,
                            widgets = widgets,
                            onSelectRange = viewModel::setDateRange,
                            onRefresh = viewModel::refreshAllConnectedData,
                            onToggleWidget = viewModel::toggleDashboardWidget,
                            onNavigate = navigateToModule,
                            onExportReport = viewModel::exportConfigReport
                        )
                    }
                    composable(AdminModule.USERS.route) {
                        UsersScreen(
                            usersState = uiState.usersState,
                            onRefresh = viewModel::refreshBackendOnly,
                            onOpenSettings = { navigateToModule(AdminModule.SETTINGS) },
                            onUserAction = viewModel::performUserAdminAction,
                            observeNotes = viewModel::observeNotes,
                            onAddNote = viewModel::addNote
                        )
                    }
                    composable(AdminModule.ADMIN_ROLES.route) {
                        AdminRolesScreen(
                            sessionState = sessionState,
                            adminsState = uiState.adminsState,
                            approvals = uiState.approvals,
                            onSwitchRolePreview = viewModel::switchRolePreview,
                            onRefresh = viewModel::refreshBackendOnly,
                            onOpenSettings = { navigateToModule(AdminModule.SETTINGS) }
                        )
                    }
                    composable(AdminModule.AI_PROVIDERS.route) {
                        AiProvidersScreen(
                            providersState = uiState.providersState,
                            onRefresh = viewModel::refreshBackendOnly,
                            onOpenSettings = { navigateToModule(AdminModule.SETTINGS) },
                            onUpdateProvider = viewModel::updateProviderConfig,
                            onRotateKey = viewModel::rotateProviderKey
                        )
                    }
                    composable(AdminModule.FEATURE_CONTROL.route) {
                        FeatureControlScreen(
                            featuresState = uiState.featuresState,
                            onRefresh = viewModel::refreshBackendOnly,
                            onOpenSettings = { navigateToModule(AdminModule.SETTINGS) },
                            onUpdateFlag = viewModel::updateFeatureFlag
                        )
                    }
                    composable(AdminModule.AI_ANALYTICS.route) {
                        AiAnalyticsScreen(
                            analyticsState = uiState.analyticsState,
                            selectedRange = uiState.dateRange,
                            onSelectRange = viewModel::setDateRange,
                            onRefresh = viewModel::refreshBackendOnly,
                            onOpenSettings = { navigateToModule(AdminModule.SETTINGS) }
                        )
                    }
                    composable(AdminModule.SUBSCRIPTIONS.route) {
                        SubscriptionsScreen(
                            subscriptionsState = uiState.subscriptionsState,
                            onRefresh = viewModel::refreshBackendOnly,
                            onOpenSettings = { navigateToModule(AdminModule.SETTINGS) }
                        )
                    }
                    composable(AdminModule.APP_RELEASES.route) {
                        AppReleasesScreen(
                            releasesState = uiState.releasesState,
                            gitHubState = uiState.gitHubState,
                            onRefresh = viewModel::refreshAllConnectedData,
                            onOpenSettings = { navigateToModule(AdminModule.SETTINGS) },
                            onOpenGitHub = { navigateToModule(AdminModule.GITHUB_CONTROL) }
                        )
                    }
                    composable(AdminModule.GITHUB_CONTROL.route) {
                        GitHubControlScreen(
                            config = config,
                            gitHubState = uiState.gitHubState,
                            hasToken = uiState.hasGitHubToken,
                            onFetchRepo = viewModel::refreshGitHub,
                            onTriggerWorkflow = viewModel::triggerWorkflow,
                            onCancelRun = viewModel::cancelWorkflowRun
                        )
                    }
                    composable(AdminModule.SYSTEM_MONITORING.route) {
                        SystemMonitoringScreen(
                            probes = uiState.healthProbes,
                            onRunProbes = viewModel::runSystemHealthProbes
                        )
                    }
                    composable(AdminModule.NOTIFICATIONS.route) {
                        NotificationsScreen(
                            notificationsState = uiState.notificationsState,
                            onSendCampaign = viewModel::sendNotificationCampaign,
                            onRefresh = viewModel::refreshBackendOnly,
                            onOpenSettings = { navigateToModule(AdminModule.SETTINGS) }
                        )
                    }
                    composable(AdminModule.SUPPORT_CENTER.route) {
                        SupportCenterScreen(
                            supportState = uiState.supportState,
                            onRefresh = viewModel::refreshBackendOnly,
                            onOpenSettings = { navigateToModule(AdminModule.SETTINGS) }
                        )
                    }
                    composable(AdminModule.AUTOMATION.route) {
                        AutomationScreen(
                            automationState = uiState.automationState,
                            onRefresh = viewModel::refreshBackendOnly,
                            onOpenSettings = { navigateToModule(AdminModule.SETTINGS) }
                        )
                    }
                    composable(AdminModule.AI_ASSISTANT.route) {
                        AiAssistantScreen(
                            messages = uiState.aiMessages,
                            isGenerating = uiState.isAiGenerating,
                            onSendPrompt = viewModel::sendAiAssistantPrompt
                        )
                    }
                    composable(AdminModule.SECURITY_CENTER.route) {
                        SecurityCenterScreen(
                            sessionState = sessionState,
                            config = config,
                            localAuditLogs = localAuditLogs,
                            hasGitHubToken = uiState.hasGitHubToken,
                            hasBackendToken = uiState.hasBackendToken,
                            onLockSessionNow = viewModel::signOut
                        )
                    }
                    composable(AdminModule.BACKUP_CENTER.route) {
                        BackupCenterScreen(
                            backupsState = uiState.backupsState,
                            config = config,
                            onExportSanitizedConfig = viewModel::exportConfigReport,
                            onRefresh = viewModel::refreshBackendOnly,
                            onOpenSettings = { navigateToModule(AdminModule.SETTINGS) }
                        )
                    }
                    composable(AdminModule.AUDIT_LOGS.route) {
                        AuditLogsScreen(
                            localLogs = localAuditLogs,
                            remoteLogs = uiState.remoteAuditLogs
                        )
                    }
                    composable(AdminModule.SETTINGS.route) {
                        SettingsScreen(
                            config = config,
                            hasGitHubToken = uiState.hasGitHubToken,
                            hasBackendToken = uiState.hasBackendToken,
                            onSaveConfig = viewModel::saveWorkspaceSettings,
                            onToggleTheme = viewModel::toggleDarkTheme,
                            onSignOut = viewModel::signOut
                        )
                    }
                }
            }
        }

        if (isWideScreen && !sidebarCollapsed) {
            PermanentNavigationDrawer(
                drawerContent = {
                    PermanentDrawerSheet(
                        modifier = Modifier.width(276.dp),
                        drawerContainerColor = MaterialTheme.colorScheme.surfaceContainerLow
                    ) {
                        SidebarMenuList(
                            currentModule = currentModule,
                            sessionState = sessionState,
                            onSelectModule = navigateToModule
                        )
                    }
                },
                content = shellContent
            )
        } else {
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        modifier = Modifier.width(288.dp),
                        drawerContainerColor = MaterialTheme.colorScheme.surfaceContainerLow
                    ) {
                        SidebarMenuList(
                            currentModule = currentModule,
                            sessionState = sessionState,
                            onSelectModule = navigateToModule
                        )
                    }
                },
                content = shellContent
            )
        }
    }

    if (showCommandCenter) {
        GlobalCommandCenterDialog(
            sessionState = sessionState,
            onSelectModule = { mod ->
                showCommandCenter = false
                navigateToModule(mod)
            },
            onDismiss = { showCommandCenter = false }
        )
    }

    if (showNotificationsSheet) {
        NotificationCenterDialog(
            uiState = uiState,
            localAuditLogs = localAuditLogs,
            onDismiss = { showNotificationsSheet = false }
        )
    }

    ReAuthConfirmationDialog(
        pending = uiState.pendingSensitiveAction,
        errorMessage = uiState.reAuthError,
        onConfirm = viewModel::confirmSensitiveAction,
        onDismiss = viewModel::dismissSensitiveAction
    )
}

@Composable
private fun SidebarMenuList(
    currentModule: AdminModule,
    sessionState: AdminSessionState,
    onSelectModule: (AdminModule) -> Unit
) {
    Column(modifier = Modifier.fillMaxHeight().padding(vertical = 12.dp)) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Text("ZEN ADMIN STUDIO", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Text(
                text = sessionState.activeRole.displayName,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            ModuleSection.entries.forEach { section ->
                val modulesInSection = AdminModule.entries.filter { it.section == section }
                item(key = "sec_${section.name}") {
                    Text(
                        text = section.title.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp)
                    )
                }
                items(modulesInSection, key = { it.route }) { mod ->
                    val permitted = mod.requiredPermission == null || sessionState.hasPermission(mod.requiredPermission)
                    NavigationDrawerItem(
                        selected = currentModule == mod,
                        onClick = { if (permitted) onSelectModule(mod) },
                        icon = {
                            Icon(
                                imageVector = mod.icon,
                                contentDescription = mod.title,
                                tint = if (permitted) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                            )
                        },
                        label = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = mod.title,
                                    color = if (permitted) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                                )
                                if (!permitted) {
                                    Text("RBAC", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                }
                            }
                        },
                        modifier = Modifier
                            .padding(horizontal = 10.dp, vertical = 2.dp)
                            .testTag("drawer_item_${mod.route}")
                    )
                }
            }
        }
    }
}

@Composable
private fun GlobalCommandCenterDialog(
    sessionState: AdminSessionState,
    onSelectModule: (AdminModule) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        AdminModule.entries.filter {
            query.isBlank() || it.title.contains(query, ignoreCase = true) || it.section.title.contains(query, ignoreCase = true)
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Global Command Center") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Jump to module (18 available)...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                LazyColumn(modifier = Modifier.height(280.dp)) {
                    items(filtered, key = { it.route }) { mod ->
                        val allowed = mod.requiredPermission == null || sessionState.hasPermission(mod.requiredPermission)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = allowed) { onSelectModule(mod) }
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(mod.icon, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(mod.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                Text(mod.section.title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (!allowed) StatusPill("Restricted", PillTone.CRITICAL)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
private fun NotificationCenterDialog(
    uiState: AdminDashboardUiState,
    localAuditLogs: List<LocalAuditLogEntity>,
    onDismiss: () -> Unit
) {
    val alerts = (uiState.overviewState as? UiState.Success)?.data?.alerts.orEmpty()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Control Studio Notification Center") },
        text = {
            LazyColumn(modifier = Modifier.height(260.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (alerts.isEmpty() && localAuditLogs.isEmpty()) {
                    item {
                        Text("No notifications or alerts recorded yet.", style = MaterialTheme.typography.bodySmall)
                    }
                }
                items(alerts, key = { "a_${it.id}" }) { alert ->
                    Column {
                        Text(alert.title, style = MaterialTheme.typography.titleSmall)
                        Text(alert.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                items(localAuditLogs.take(6), key = { "n_${it.id}" }) { log ->
                    Column {
                        Text("${log.action} · ${log.outcome}", style = MaterialTheme.typography.titleSmall)
                        Text("${log.target} — ${log.details}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
