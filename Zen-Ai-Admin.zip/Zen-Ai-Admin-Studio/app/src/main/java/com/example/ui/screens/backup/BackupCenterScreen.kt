package com.example.ui.screens.backup

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.core.database.WorkspaceConfigEntity
import com.example.core.model.BackupRecordDto
import com.example.core.model.UiState
import com.example.ui.components.BackendSetupRequiredBanner
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.theme.MonoMetricStyle

@Composable
fun BackupCenterScreen(
    backupsState: UiState<List<BackupRecordDto>>,
    config: WorkspaceConfigEntity,
    onExportSanitizedConfig: () -> String,
    onRefresh: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            EnterpriseGlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Backup, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Sanitized Configuration Export", style = MaterialTheme.typography.titleMedium)
                        Text(
                            text = "Retention Policy: ${config.retentionPolicyDays} days. Exports strictly exclude passwords, authentication tokens, and API secrets.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        val json = onExportSanitizedConfig()
                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "application/json"
                            putExtra(Intent.EXTRA_SUBJECT, "Zen Admin Sanitized Configuration Backup")
                            putExtra(Intent.EXTRA_TEXT, json)
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Export Sanitized Config"))
                    }
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Export Sanitized Config JSON")
                }
            }
        }

        when (backupsState) {
            UiState.Loading -> item { Text("Loading Firestore backup records...", style = MaterialTheme.typography.bodyMedium) }
            is UiState.Error -> item {
                BackendSetupRequiredBanner(
                    moduleName = "Cloud Firestore Backups",
                    reason = backupsState.message,
                    onOpenSettings = onOpenSettings,
                    onRetry = onRefresh
                )
            }
            is UiState.Success -> {
                items(backupsState.data, key = { it.id }) { b ->
                    EnterpriseGlassCard {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(b.scope, style = MaterialTheme.typography.titleSmall)
                                Text("${b.createdAt} · ${b.sizeBytes / 1024} KB", style = MonoMetricStyle)
                            }
                            StatusPill(if (b.verified) "Verified" else b.status, if (b.verified) PillTone.HEALTHY else PillTone.WARNING)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
