package com.example.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ZenAdminDao {
    @Query("SELECT * FROM workspace_config WHERE id = 1")
    fun observeWorkspaceConfig(): Flow<WorkspaceConfigEntity?>

    @Query("SELECT * FROM workspace_config WHERE id = 1")
    suspend fun getWorkspaceConfig(): WorkspaceConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWorkspaceConfig(config: WorkspaceConfigEntity)

    @Query("SELECT * FROM dashboard_widgets ORDER BY sortOrder ASC")
    fun observeWidgets(): Flow<List<DashboardWidgetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWidgets(widgets: List<DashboardWidgetEntity>)

    @Query("UPDATE dashboard_widgets SET enabled = :enabled WHERE widgetId = :widgetId")
    suspend fun setWidgetEnabled(widgetId: String, enabled: Boolean)

    // Append-only audit logs: NO delete or update methods are exposed by design.
    @Query("SELECT * FROM local_audit_logs ORDER BY timestampMillis DESC LIMIT 250")
    fun observeAuditLogs(): Flow<List<LocalAuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun appendAuditLog(entry: LocalAuditLogEntity)

    @Query("SELECT * FROM cached_overview WHERE id = 1")
    fun observeCachedOverview(): Flow<CachedOverviewEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveCachedOverview(cached: CachedOverviewEntity)

    @Query("SELECT * FROM local_admin_notes WHERE targetType = :targetType AND targetId = :targetId ORDER BY createdAtMillis DESC")
    fun observeNotesForTarget(targetType: String, targetId: String): Flow<List<LocalAdminNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: LocalAdminNoteEntity)
}
