package com.example.ui.screens.subscriptions

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.core.model.SubscriptionPlanDto
import com.example.core.model.UiState
import com.example.ui.components.BackendSetupRequiredBanner
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.theme.MonoMetricStyle

private val planTiers = listOf("Free", "Basic", "Pro", "Premium", "Enterprise", "Custom")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SubscriptionsScreen(
    subscriptionsState: UiState<List<SubscriptionPlanDto>>,
    onRefresh: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            EnterpriseGlassCard(accentBorder = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CreditCard, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Payment Separation Guarantee: Billing receipts and payment processing remain isolated in your compliant payment provider (Stripe / Google Play Billing). Never fabricate payment records.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        when (subscriptionsState) {
            UiState.Loading -> item { Text("Loading subscription plans...", style = MaterialTheme.typography.bodyMedium) }
            is UiState.Error -> {
                item {
                    BackendSetupRequiredBanner(
                        moduleName = "Subscriptions & Quota Plans",
                        reason = subscriptionsState.message,
                        onOpenSettings = onOpenSettings,
                        onRetry = onRefresh
                    )
                }
                item {
                    EnterpriseGlassCard {
                        Text("Configured Tier Architecture", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            planTiers.forEach { StatusPill(it, PillTone.NEUTRAL) }
                        }
                    }
                }
            }
            is UiState.Success -> {
                items(subscriptionsState.data, key = { it.id }) { plan ->
                    EnterpriseGlassCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(plan.name, style = MaterialTheme.typography.titleMedium)
                                Text("Tier: ${plan.tier}", style = MonoMetricStyle, color = MaterialTheme.colorScheme.primary)
                            }
                            StatusPill(
                                if (plan.enabled) "Active" else "Archived",
                                if (plan.enabled) PillTone.HEALTHY else PillTone.NEUTRAL
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Quotas: ${plan.monthlyRequestsLimit} req/mo · ${plan.dailyImageLimit} imgs/day · ${plan.voiceMinutesLimit} voice min",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "Subscribers: ${plan.activeSubscribers} · Trial: ${plan.trialDays} days",
                            style = MonoMetricStyle,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
