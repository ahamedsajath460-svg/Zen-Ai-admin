package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.core.model.AdminPermission

enum class ModuleSection(val title: String) {
    COMMAND("Command"),
    IDENTITY("Identity & Access"),
    AI_PLATFORM("AI & Feature Platform"),
    RELEASE_OPS("Release & Infrastructure"),
    GOVERNANCE("Governance & Security")
}

enum class AdminModule(
    val route: String,
    val title: String,
    val shortTitle: String,
    val section: ModuleSection,
    val icon: ImageVector,
    val requiredPermission: AdminPermission? = null
) {
    OVERVIEW("overview", "Overview", "Overview", ModuleSection.COMMAND, Icons.Default.Dashboard, AdminPermission.VIEW_DASHBOARD),
    USERS("users", "Users", "Users", ModuleSection.IDENTITY, Icons.Default.Group, AdminPermission.MANAGE_USERS),
    ADMIN_ROLES("admin_roles", "Admin Roles", "Roles", ModuleSection.IDENTITY, Icons.Default.AdminPanelSettings, AdminPermission.MANAGE_ROLES),
    AI_PROVIDERS("ai_providers", "AI Providers", "Providers", ModuleSection.AI_PLATFORM, Icons.Default.Hub, AdminPermission.MANAGE_PROVIDERS),
    FEATURE_CONTROL("feature_control", "Feature Control", "Features", ModuleSection.AI_PLATFORM, Icons.Default.Flag, AdminPermission.MANAGE_FEATURES),
    AI_ANALYTICS("ai_analytics", "AI Analytics", "Analytics", ModuleSection.AI_PLATFORM, Icons.Default.Analytics, AdminPermission.VIEW_ANALYTICS),
    SUBSCRIPTIONS("subscriptions", "Subscriptions", "Plans", ModuleSection.AI_PLATFORM, Icons.Default.CreditCard, AdminPermission.MANAGE_SUBSCRIPTIONS),
    APP_RELEASES("app_releases", "App Releases", "Releases", ModuleSection.RELEASE_OPS, Icons.Default.RocketLaunch, AdminPermission.MANAGE_RELEASES),
    GITHUB_CONTROL("github_control", "GitHub Control", "GitHub", ModuleSection.RELEASE_OPS, Icons.Default.Code, AdminPermission.MANAGE_GITHUB),
    SYSTEM_MONITORING("system_monitoring", "System Monitoring", "Monitor", ModuleSection.RELEASE_OPS, Icons.Default.MonitorHeart, AdminPermission.VIEW_MONITORING),
    NOTIFICATIONS("notifications", "Notifications", "Alerts", ModuleSection.RELEASE_OPS, Icons.Default.NotificationsActive, AdminPermission.SEND_NOTIFICATIONS),
    SUPPORT_CENTER("support_center", "Support Center", "Support", ModuleSection.RELEASE_OPS, Icons.Default.SupportAgent, AdminPermission.MANAGE_SUPPORT),
    AUTOMATION("automation", "Automation", "Rules", ModuleSection.COMMAND, Icons.Default.AutoMode, AdminPermission.MANAGE_AUTOMATION),
    AI_ASSISTANT("ai_assistant", "AI Admin Assistant", "AI Ops", ModuleSection.COMMAND, Icons.Default.AutoAwesome, AdminPermission.USE_AI_ASSISTANT),
    SECURITY_CENTER("security_center", "Security Center", "Security", ModuleSection.GOVERNANCE, Icons.Default.Security, AdminPermission.MANAGE_SECURITY),
    BACKUP_CENTER("backup_center", "Backup Center", "Backups", ModuleSection.GOVERNANCE, Icons.Default.Backup, AdminPermission.MANAGE_BACKUPS),
    AUDIT_LOGS("audit_logs", "Audit Logs", "Audits", ModuleSection.GOVERNANCE, Icons.Default.HistoryEdu, AdminPermission.VIEW_AUDIT_LOGS),
    SETTINGS("settings", "Settings", "Settings", ModuleSection.GOVERNANCE, Icons.Default.Settings, null)
}
