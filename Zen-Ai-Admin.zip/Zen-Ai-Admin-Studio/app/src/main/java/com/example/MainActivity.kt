package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.core.ai.PlaceholderAdminAiRepository
import com.example.core.database.ZenAdminDatabase
import com.example.core.security.AdminSessionManager
import com.example.core.security.FirebaseAdminAuthRepository
import com.example.core.security.KeystoreCryptoManager
import com.example.data.repository.AdminControlRepository
import com.example.ui.navigation.AdminShellScaffold
import com.example.ui.screens.auth.AdminAuthScreen
import com.example.ui.state.ZenAdminViewModel
import com.example.ui.theme.ZenAdminTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val adminViewModel: ZenAdminViewModel = viewModel(
                factory = viewModelFactory {
                    initializer {
                        val app = checkNotNull(this[APPLICATION_KEY])
                        val crypto = KeystoreCryptoManager()
                        val sessionManager = AdminSessionManager(app, crypto)
                        val db = ZenAdminDatabase.getInstance(app)
                        val repository = AdminControlRepository(db.adminDao(), sessionManager)
                        val aiRepository = PlaceholderAdminAiRepository()
                        val firebaseAdminAuth = FirebaseAdminAuthRepository()
                        ZenAdminViewModel(repository, sessionManager, aiRepository, firebaseAdminAuth)
                    }
                }
            )

            val sessionState by adminViewModel.sessionState.collectAsStateWithLifecycle()
            val config by adminViewModel.workspaceConfig.collectAsStateWithLifecycle()
            val uiState by adminViewModel.uiState.collectAsStateWithLifecycle()
            val widgets by adminViewModel.widgets.collectAsStateWithLifecycle()
            val localAuditLogs by adminViewModel.localAuditLogs.collectAsStateWithLifecycle()
            val authError by adminViewModel.authError.collectAsStateWithLifecycle()
            val isAuthBusy by adminViewModel.isAuthBusy.collectAsStateWithLifecycle()

            ZenAdminTheme(darkTheme = config.darkThemeEnabled) {
                if (!sessionState.isAuthenticated) {
                    AdminAuthScreen(
                        sessionState = sessionState,
                        authError = authError,
                        isBusy = isAuthBusy,
                        onInitializeVault = adminViewModel::initializeVault,
                        onSignIn = adminViewModel::signIn
                    )
                } else {
                    AdminShellScaffold(
                        viewModel = adminViewModel,
                        sessionState = sessionState,
                        uiState = uiState,
                        config = config,
                        widgets = widgets,
                        localAuditLogs = localAuditLogs
                    )
                }
            }
        }
    }
}
