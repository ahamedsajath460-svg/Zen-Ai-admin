package com.example.core.security

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.model.AdminPermission
import com.example.core.model.AdminRole
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.adminAuthStore by preferencesDataStore(name = "zen_admin_auth_vault")

data class AdminSessionState(
    val isVaultInitialized: Boolean = false,
    val isAuthenticated: Boolean = false,
    val adminEmail: String = "",
    val adminDisplayName: String = "",
    val activeRole: AdminRole = AdminRole.READ_ONLY_ADMIN,
    val sessionStartedAtMillis: Long = 0L,
    val lastAuthCheckMillis: Long = 0L,
    val keystoreActive: Boolean = false,
    val firebaseAuthClaimStatus: String = "Firebase Auth Not Provisioned (Local Keystore Session)"
) {
    fun hasPermission(permission: AdminPermission): Boolean {
        return isAuthenticated && activeRole.permissions.contains(permission)
    }
}

class AdminSessionManager(
    private val context: Context,
    private val crypto: KeystoreCryptoManager
) {
    private object Keys {
        val ADMIN_EMAIL = stringPreferencesKey("admin_email")
        val ADMIN_NAME = stringPreferencesKey("admin_name")
        val PASS_HASH = stringPreferencesKey("pass_hash")
        val PASS_SALT = stringPreferencesKey("pass_salt")
        val ROLE_NAME = stringPreferencesKey("role_name")
        val SESSION_TOKEN_ENC = stringPreferencesKey("session_token_enc")
        val SESSION_ACTIVE = stringPreferencesKey("session_active")
        val SESSION_STARTED = longPreferencesKey("session_started")
        val LAST_AUTH_CHECK = longPreferencesKey("last_auth_check")
        val GITHUB_PAT_ENC = stringPreferencesKey("github_pat_enc")
        val BACKEND_TOKEN_ENC = stringPreferencesKey("backend_token_enc")
    }

    val sessionState: Flow<AdminSessionState> = context.adminAuthStore.data.map { prefs ->
        val hash = prefs[Keys.PASS_HASH].orEmpty()
        val salt = prefs[Keys.PASS_SALT].orEmpty()
        val initialized = hash.isNotBlank() && salt.isNotBlank()
        val active = prefs[Keys.SESSION_ACTIVE] == "true" && FirebaseAuth.getInstance().currentUser != null
        val role = AdminRole.entries.firstOrNull { it.name == prefs[Keys.ROLE_NAME] } ?: AdminRole.READ_ONLY_ADMIN
        AdminSessionState(
            isVaultInitialized = initialized,
            isAuthenticated = initialized && active,
            adminEmail = prefs[Keys.ADMIN_EMAIL].orEmpty(),
            adminDisplayName = prefs[Keys.ADMIN_NAME].orEmpty(),
            activeRole = role,
            sessionStartedAtMillis = prefs[Keys.SESSION_STARTED] ?: 0L,
            lastAuthCheckMillis = prefs[Keys.LAST_AUTH_CHECK] ?: 0L,
            keystoreActive = crypto.isHardwareKeyReady()
        )
    }

    suspend fun initializeSuperAdminVault(
        email: String,
        displayName: String,
        passphrase: String,
        role: AdminRole
    ): Result<Unit> {
        val cleanEmail = email.trim().lowercase()
        val cleanName = displayName.trim()
        if (!cleanEmail.contains("@") || cleanEmail.length < 5) {
            return Result.failure(IllegalArgumentException("Enter a valid administrator email address."))
        }
        if (cleanName.length < 2) {
            return Result.failure(IllegalArgumentException("Enter an administrator display name."))
        }
        if (passphrase.length < 8) {
            return Result.failure(IllegalArgumentException("Vault passphrase must be at least 8 characters."))
        }
        val salt = crypto.generateSaltBase64()
        val hash = crypto.hashPassphrasePbkdf2(passphrase, salt)
        val now = System.currentTimeMillis()
        context.adminAuthStore.edit { prefs ->
            prefs[Keys.ADMIN_EMAIL] = cleanEmail
            prefs[Keys.ADMIN_NAME] = cleanName
            prefs[Keys.PASS_SALT] = salt
            prefs[Keys.PASS_HASH] = hash
            prefs[Keys.ROLE_NAME] = role.name
            prefs[Keys.SESSION_ACTIVE] = "true"
            prefs[Keys.SESSION_STARTED] = now
            prefs[Keys.LAST_AUTH_CHECK] = now
        }
        return Result.success(Unit)
    }

    suspend fun signIn(email: String, passphrase: String): Result<Unit> {
        val prefs = context.adminAuthStore.data.first()
        val storedEmail = prefs[Keys.ADMIN_EMAIL].orEmpty()
        val storedSalt = prefs[Keys.PASS_SALT].orEmpty()
        val storedHash = prefs[Keys.PASS_HASH].orEmpty()
        if (storedHash.isBlank() || storedSalt.isBlank()) {
            return Result.failure(IllegalStateException("Admin vault is not initialized yet."))
        }
        if (email.trim().lowercase() != storedEmail) {
            return Result.failure(SecurityException("Administrator email does not match registered vault identity."))
        }
        val candidateHash = crypto.hashPassphrasePbkdf2(passphrase, storedSalt)
        if (!crypto.constantTimeEquals(candidateHash, storedHash)) {
            return Result.failure(SecurityException("Invalid administrator passphrase."))
        }
        val now = System.currentTimeMillis()
        context.adminAuthStore.edit { editPrefs ->
            editPrefs[Keys.SESSION_ACTIVE] = "true"
            editPrefs[Keys.SESSION_STARTED] = now
            editPrefs[Keys.LAST_AUTH_CHECK] = now
        }
        return Result.success(Unit)
    }

    suspend fun verifyReAuthentication(passphrase: String): Result<Unit> {
        val prefs = context.adminAuthStore.data.first()
        val storedSalt = prefs[Keys.PASS_SALT].orEmpty()
        val storedHash = prefs[Keys.PASS_HASH].orEmpty()
        if (storedHash.isBlank() || storedSalt.isBlank()) {
            return Result.failure(IllegalStateException("Vault credentials unavailable."))
        }
        val candidateHash = crypto.hashPassphrasePbkdf2(passphrase, storedSalt)
        if (!crypto.constantTimeEquals(candidateHash, storedHash)) {
            return Result.failure(SecurityException("Re-authentication failed. Sensitive operation blocked."))
        }
        context.adminAuthStore.edit { it[Keys.LAST_AUTH_CHECK] = System.currentTimeMillis() }
        return Result.success(Unit)
    }

    suspend fun setActiveRolePreview(role: AdminRole) {
        context.adminAuthStore.edit { it[Keys.ROLE_NAME] = role.name }
    }

    suspend fun saveEncryptedGitHubToken(token: String) {
        context.adminAuthStore.edit { prefs ->
            if (token.isBlank()) prefs.remove(Keys.GITHUB_PAT_ENC)
            else prefs[Keys.GITHUB_PAT_ENC] = crypto.encrypt(token.trim())
        }
    }

    suspend fun getDecryptedGitHubToken(): String {
        val enc = context.adminAuthStore.data.first()[Keys.GITHUB_PAT_ENC].orEmpty()
        return crypto.decrypt(enc)
    }

    suspend fun hasGitHubToken(): Boolean {
        return context.adminAuthStore.data.first()[Keys.GITHUB_PAT_ENC].orEmpty().isNotBlank()
    }

    suspend fun saveEncryptedBackendToken(token: String) {
        context.adminAuthStore.edit { prefs ->
            if (token.isBlank()) prefs.remove(Keys.BACKEND_TOKEN_ENC)
            else prefs[Keys.BACKEND_TOKEN_ENC] = crypto.encrypt(token.trim())
        }
    }

    suspend fun getDecryptedBackendToken(): String {
        val enc = context.adminAuthStore.data.first()[Keys.BACKEND_TOKEN_ENC].orEmpty()
        return crypto.decrypt(enc)
    }

    suspend fun hasBackendToken(): Boolean {
        return context.adminAuthStore.data.first()[Keys.BACKEND_TOKEN_ENC].orEmpty().isNotBlank()
    }

    suspend fun signOut() {
        FirebaseAuth.getInstance().signOut()
        context.adminAuthStore.edit { prefs ->
            prefs[Keys.SESSION_ACTIVE] = "false"
            prefs.remove(Keys.SESSION_TOKEN_ENC)
        }
    }
}
