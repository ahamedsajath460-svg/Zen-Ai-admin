package com.example.core.ai

import com.example.core.model.ConnectionMode
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

data class AdminContextSnapshot(
    val backendMode: ConnectionMode,
    val backendUrlConfigured: Boolean,
    val githubRepoConfigured: String,
    val recentWorkflowFailureCount: Int,
    val latestWorkflowName: String?,
    val auditLogCount: Int,
    val keystoreActive: Boolean
)

data class AiAssistantChunk(
    val text: String,
    val isComplete: Boolean,
    val isPlaceholderSample: Boolean = true
)

/**
 * Abstraction for the AI Admin Assistant.
 * Live Gemini inference in AI Studio Android apps runs via Firebase AI Logic (Firebase.ai).
 * When Firebase setup is declined or not yet provisioned, [PlaceholderAdminAiRepository]
 * provides clearly labeled diagnostic sample responses without making direct LLM calls or embedding API keys.
 */
interface AdminAiRepository {
    val isLiveGeminiEnabled: Boolean
    fun askAssistant(prompt: String, context: AdminContextSnapshot): Flow<AiAssistantChunk>
}

class PlaceholderAdminAiRepository : AdminAiRepository {
    override val isLiveGeminiEnabled: Boolean = false

    override fun askAssistant(prompt: String, context: AdminContextSnapshot): Flow<AiAssistantChunk> = flow {
        val lower = prompt.lowercase()
        val responseBody = buildString {
            appendLine("[SAMPLE DIAGNOSTIC RESPONSE — FIREBASE AI LOGIC NOT PROVISIONED]")
            appendLine()
            when {
                "build" in lower || "github" in lower || "workflow" in lower -> {
                    appendLine("GitHub & Release Diagnostic Summary:")
                    if (context.githubRepoConfigured.isBlank()) {
                        appendLine("• No GitHub repository is linked yet. Open GitHub Control or Settings and enter `owner/repo` to stream live Actions runs and commit history.")
                    } else {
                        appendLine("• Connected repository: `${context.githubRepoConfigured}`")
                        appendLine("• Observed workflow failures in latest fetch: ${context.recentWorkflowFailureCount}")
                        appendLine("• Latest tracked workflow: ${context.latestWorkflowName ?: "None loaded yet"}")
                    }
                    appendLine("• Security Note: Workflow dispatches and artifact downloads should route through the Cloud Functions GitHub proxy so PATs stay off the device.")
                }
                "health" in lower || "status" in lower || "system" in lower -> {
                    appendLine("System Health Assessment:")
                    appendLine("• Firebase Backend: ${if (context.backendMode == ConnectionMode.FIREBASE_DECLINED) "Declined / Not Provisioned" else context.backendMode.name}")
                    appendLine("• Backend Proxy Endpoint: ${if (context.backendUrlConfigured) "Configured" else "Not Configured"}")
                    appendLine("• Android Keystore AES-256-GCM Vault: ${if (context.keystoreActive) "Active & Verified" else "Unavailable"}")
                    appendLine("• Local Audit Entries Recorded: ${context.auditLogCount}")
                }
                "security" in lower || "audit" in lower || "role" in lower -> {
                    appendLine("Security & RBAC Posture Check:")
                    appendLine("• Sensitive mutations enforce local vault re-authentication before dispatch.")
                    appendLine("• Private user chat transcripts remain blocked by design (privacy-first metadata only).")
                    appendLine("• Recommendation: Deploy `backend/firestore.rules` and `backend/functions` so Firebase custom claims verify every server request.")
                }
                else -> {
                    appendLine("Operational Overview:")
                    appendLine("• Query received: \"${prompt.take(120)}\"")
                    appendLine("• Live Gemini 3.8 Flash reasoning is inactive because Firebase setup was declined.")
                    appendLine("• Enable Firebase AI Logic in AI Studio to unlock live anomaly detection, log root-cause analysis, and natural-language audit search.")
                }
            }
            appendLine()
            append("Next Step: Accept Firebase setup in AI Studio to connect this assistant to Gemini via Firebase AI Logic (zero client API keys required).")
        }

        val words = responseBody.split(" ")
        val sb = StringBuilder()
        for ((index, word) in words.withIndex()) {
            if (index > 0) sb.append(' ')
            sb.append(word)
            if (index % 8 == 0 || index == words.lastIndex) {
                emit(
                    AiAssistantChunk(
                        text = sb.toString(),
                        isComplete = index == words.lastIndex,
                        isPlaceholderSample = true
                    )
                )
                delay(28)
            }
        }
    }
}
