package com.example.ui.screens.features

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.core.model.FeatureFlagConfig
import com.example.core.model.UiState
import com.example.ui.components.BackendSetupRequiredBanner
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.theme.MonoMetricStyle

private val zenFeatureCatalog = listOf(
    "AI Chat", "Image Generation", "Voice Assistant", "Screen Sharing",
    "Advanced Vision", "Screen OCR", "Screen Translation", "Agent Control",
    "Autonomous Assistant", "Floating AI Assistant", "AI Search",
    "Web Research", "Memory", "File Generation", "Cloud Studio"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FeatureControlScreen(
    featuresState: UiState<List<FeatureFlagConfig>>,
    onRefresh: () -> Unit,
    onOpenSettings: () -> Unit,
    onUpdateFlag: (FeatureFlagConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            EnterpriseGlassCard(accentBorder = MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Client Enforcement Policy: Remote flags take effect on Zen AI clients that actively read and enforce the `feature_flags` / Remote Config document.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        when (featuresState) {
            UiState.Loading -> item { Text("Loading feature flags...", style = MaterialTheme.typography.bodyMedium) }
            is UiState.Error -> {
                item {
                    BackendSetupRequiredBanner(
                        moduleName = "Feature Control Center",
                        reason = featuresState.message,
                        onOpenSettings = onOpenSettings,
                        onRetry = onRefresh
                    )
                }
                item {
                    EnterpriseGlassCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Flag, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("Managed Zen AI Feature Matrix (15)", style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(Modifier.height(10.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            zenFeatureCatalog.forEach { name ->
                                StatusPill(name, PillTone.NEUTRAL)
                            }
                        }
                    }
                }
            }
            is UiState.Success -> {
                items(featuresState.data, key = { it.key }) { flag ->
                    EnterpriseGlassCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(flag.displayName, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "key: ${flag.key} · min v${flag.minAppVersion}",
                                    style = MonoMetricStyle,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Switch(
                                checked = flag.enabled,
                                onCheckedChange = { onUpdateFlag(flag.copy(enabled = it)) }
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            StatusPill(if (flag.enabled) "Enabled" else "Disabled", if (flag.enabled) PillTone.HEALTHY else PillTone.CRITICAL)
                            if (flag.maintenanceMode) StatusPill("Maintenance", PillTone.WARNING)
                            if (flag.betaOnly) StatusPill("Beta", PillTone.INFO)
                            StatusPill(
                                text = if (flag.clientEnforced) "Client Enforced" else "Pending Client Sync",
                                tone = if (flag.clientEnforced) PillTone.HEALTHY else PillTone.WARNING
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Rollout: ${flag.rolloutPercentage}%", style = MonoMetricStyle)
                        Slider(
                            value = flag.rolloutPercentage.toFloat(),
                            onValueChange = { },
                            onValueChangeFinished = { },
                            valueRange = 0f..100f
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Maintenance Mode", style = MaterialTheme.typography.bodySmall)
                            Switch(
                                checked = flag.maintenanceMode,
                                onCheckedChange = { onUpdateFlag(flag.copy(maintenanceMode = it)) }
                            )
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
