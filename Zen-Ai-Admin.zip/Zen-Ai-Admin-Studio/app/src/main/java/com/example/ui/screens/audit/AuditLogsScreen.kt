package com.example.ui.screens.audit

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.core.database.LocalAuditLogEntity
import com.example.core.model.AuditLogEntryDto
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.theme.MonoMetricStyle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AuditLogsScreen(
    localLogs: List<LocalAuditLogEntity>,
    remoteLogs: List<AuditLogEntryDto>,
    modifier: Modifier = Modifier
) {
    var query by remember { mutableStateOf("") }
    val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            EnterpriseGlassCard(accentBorder = MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.HistoryEdu, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = "Immutable Audit Trail: Append-only security records. Administrators cannot edit or erase audit history.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search action, actor, or target") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (remoteLogs.isNotEmpty()) {
            item { Text("Cloud Audit Stream (${remoteLogs.size})", style = MaterialTheme.typography.titleMedium) }
            val filteredRemote = remoteLogs.filter {
                query.isBlank() || it.action.contains(query, true) || it.actorUid.contains(query, true) || it.target.contains(query, true)
            }
            items(filteredRemote, key = { "r_${it.id}" }) { log ->
                EnterpriseGlassCard {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(log.action, style = MaterialTheme.typography.titleSmall)
                        StatusPill(log.outcome, if (log.outcome.equals("SUCCESS", true)) PillTone.HEALTHY else PillTone.CRITICAL)
                    }
                    Text("${log.actorUid} (${log.actorRole}) -> ${log.target}", style = MonoMetricStyle, color = MaterialTheme.colorScheme.primary)
                    Text("${log.timestamp} · ${log.details}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        item { Text("Local Studio Security Vault Log (${localLogs.size})", style = MaterialTheme.typography.titleMedium) }
        val filteredLocal = localLogs.filter {
            query.isBlank() || it.action.contains(query, true) || it.actorEmail.contains(query, true) || it.target.contains(query, true)
        }
        items(filteredLocal, key = { "l_${it.id}" }) { log ->
            EnterpriseGlassCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(log.action, style = MaterialTheme.typography.titleSmall)
                    StatusPill(log.outcome, if (log.outcome == "SUCCESS") PillTone.HEALTHY else PillTone.CRITICAL)
                }
                Spacer(Modifier.height(4.dp))
                Text("${log.actorEmail} (${log.actorRole}) -> ${log.target}", style = MonoMetricStyle, color = MaterialTheme.colorScheme.primary)
                Text("${fmt.format(Date(log.timestampMillis))} · ${log.details}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
