package com.example.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.core.database.WorkspaceConfigEntity
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.theme.LocalZenStatusColors

@Composable
fun SettingsScreen(
    config: WorkspaceConfigEntity,
    hasGitHubToken: Boolean,
    hasBackendToken: Boolean,
    onSaveConfig: (
        backendUrl: String,
        firebaseProjectId: String,
        githubOwner: String,
        githubRepo: String,
        githubToken: String?,
        backendToken: String?,
        darkTheme: Boolean,
        timeoutMinutes: Int,
        retentionDays: Int,
        maintenanceLocal: Boolean
    ) -> Unit,
    onToggleTheme: (Boolean) -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    var backendUrl by remember(config.backendBaseUrl) { mutableStateOf(config.backendBaseUrl) }
    var firebaseProjectId by remember(config.firebaseProjectId) { mutableStateOf(config.firebaseProjectId) }
    var githubOwner by remember(config.githubOwner) { mutableStateOf(config.githubOwner) }
    var githubRepo by remember(config.githubRepo) { mutableStateOf(config.githubRepo) }
    var githubToken by remember { mutableStateOf("") }
    var backendToken by remember { mutableStateOf("") }
    var timeoutMinutes by remember(config.sessionTimeoutMinutes) { mutableStateOf(config.sessionTimeoutMinutes.toString()) }
    var retentionDays by remember(config.retentionPolicyDays) { mutableStateOf(config.retentionPolicyDays.toString()) }
    var maintenanceLocal by remember(config.maintenanceModeLocal) { mutableStateOf(config.maintenanceModeLocal) }
    var showSetupGuide by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            EnterpriseGlassCard {
                Text("Appearance & Studio Preferences", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Enterprise Obsidian Dark Theme", style = MaterialTheme.typography.bodyMedium)
                        Text("Toggle between Obsidian Dark and Slate Light theme", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = config.darkThemeEnabled,
                        onCheckedChange = onToggleTheme,
                        modifier = Modifier.testTag("settings_theme_switch")
                    )
                }
            }
        }

        item {
            EnterpriseGlassCard {
                Text("Cloud Backend & Firebase Reference", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = backendUrl,
                    onValueChange = { backendUrl = it },
                    label = { Text("Cloud Functions HTTPS Base URL") },
                    placeholder = { Text("https://us-central1-your-zen-project.cloudfunctions.net/api") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_backend_url_input")
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = firebaseProjectId,
                    onValueChange = { firebaseProjectId = it },
                    label = { Text("Target Zen AI Firebase Project ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = backendToken,
                    onValueChange = { backendToken = it },
                    label = { Text(if (hasBackendToken) "Replace Backend Bearer Token (encrypted)" else "Backend Bearer Token (encrypted in Keystore)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item {
            EnterpriseGlassCard {
                Text("GitHub Repository & Actions Integration", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = githubOwner,
                        onValueChange = { githubOwner = it },
                        label = { Text("GitHub Owner") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = githubRepo,
                        onValueChange = { githubRepo = it },
                        label = { Text("Repository") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = githubToken,
                    onValueChange = { githubToken = it },
                    label = { Text(if (hasGitHubToken) "Replace Keystore-Encrypted GitHub PAT" else "Optional GitHub PAT (stored in Keystore)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        item {
            EnterpriseGlassCard {
                Text("Governance & Retention Policies", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = timeoutMinutes,
                        onValueChange = { timeoutMinutes = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Session Timeout (min)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = retentionDays,
                        onValueChange = { retentionDays = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Retention Policy (days)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            onSaveConfig(
                                backendUrl,
                                firebaseProjectId,
                                githubOwner,
                                githubRepo,
                                githubToken.ifBlank { null },
                                backendToken.ifBlank { null },
                                config.darkThemeEnabled,
                                timeoutMinutes.toIntOrNull() ?: 30,
                                retentionDays.toIntOrNull() ?: 90,
                                maintenanceLocal
                            )
                            githubToken = ""
                            backendToken = ""
                        },
                        modifier = Modifier.testTag("settings_save_btn")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Save & Sync")
                    }
                    OutlinedButton(onClick = { showSetupGuide = true }) {
                        Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Setup Guide")
                    }
                }
            }
        }

        item {
            EnterpriseGlassCard {
                Text("Session Control", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = onSignOut,
                    colors = ButtonDefaults.buttonColors(containerColor = LocalZenStatusColors.current.critical),
                    modifier = Modifier.testTag("settings_logout_btn")
                ) {
                    Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Secure Logout & Lock Vault")
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }

    if (showSetupGuide) {
        AlertDialog(
            onDismissRequest = { showSetupGuide = false },
            title = { Text("Backend & Firebase Setup Guide") },
            text = {
                Text(
                    text = "1. Deploy `backend/firestore.rules`, `backend/firestore.indexes.json`, and `backend/functions/` to your Zen AI Firebase project.\n\n" +
                        "2. Store AI provider keys & GitHub PAT in Cloud Secret Manager (never inside the APK).\n\n" +
                        "3. Paste your deployed Cloud Functions HTTPS URL above and save.\n\n" +
                        "4. To enable live Gemini AI Admin Assistant, enable Firebase provisioning in AI Studio so Firebase AI Logic & App Check are registered.",
                    style = MaterialTheme.typography.bodySmall
                )
            },
            confirmButton = {
                TextButton(onClick = { showSetupGuide = false }) { Text("Close") }
            }
        )
    }
}
