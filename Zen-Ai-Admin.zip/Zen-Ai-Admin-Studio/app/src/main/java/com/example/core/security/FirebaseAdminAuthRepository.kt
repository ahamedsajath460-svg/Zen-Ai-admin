package com.example.core.security

import com.example.core.model.AdminRole
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/** Firebase identity is authoritative; the local Keystore vault is only an additional device lock. */
class FirebaseAdminAuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    data class VerifiedAdmin(val uid: String, val email: String, val displayName: String, val role: AdminRole)

    suspend fun signInAndVerify(email: String, password: String): Result<VerifiedAdmin> = runCatching {
        require(email.isNotBlank() && password.isNotBlank()) { "Enter your Firebase administrator email and password." }
        val result = auth.signInWithEmailAndPassword(email.trim(), password).await()
        val user = result.user ?: error("Firebase did not return an authenticated user.")
        if (user.isEmailVerified.not()) error("Verify your administrator email before signing in.")
        var token = user.getIdToken(true).await()
        var roleName = token.claims["adminRole"] as? String
        if (roleName == null) {
            // The backend only bootstraps the single verified email configured by the owner.
            // Every other account is rejected by the server-side allowlist and one-time lock.
            bootstrapFirstAdmin(token.token ?: error("Firebase ID token unavailable."))
            token = user.getIdToken(true).await()
            roleName = token.claims["adminRole"] as? String
        }
        roleName ?: error("This Firebase account has no administrator role. Ask the Super Admin to provision it.")
        val role = AdminRole.entries.firstOrNull { it.name == roleName }
            ?: error("The assigned administrator role is not recognized.")
        val roleDoc = firestore.collection("admin_roles").document(user.uid).get().await()
        if (!roleDoc.exists()) error("Administrator role record is missing. Access denied.")
        if (roleDoc.getString("status") == "revoked") error("This administrator account has been revoked.")
        if (roleDoc.getString("role") != roleName) error("Administrator role claim and Firestore record do not match.")
        VerifiedAdmin(user.uid, user.email ?: email.trim(), user.displayName ?: "Administrator", role)
    }

    private suspend fun bootstrapFirstAdmin(idToken: String) = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url("https://us-central1-own-project-bdeee.cloudfunctions.net/api/bootstrap/super-admin")
            .header("Authorization", "Bearer $idToken")
            .post(ByteArray(0).toRequestBody(null))
            .build()
        OkHttpClient().newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val message = response.body?.string().orEmpty()
                error("First-admin bootstrap not permitted or not deployed (${response.code}). ${message.take(180)}")
            }
        }
    }

    suspend fun signOut() {
        auth.signOut()
    }
}
