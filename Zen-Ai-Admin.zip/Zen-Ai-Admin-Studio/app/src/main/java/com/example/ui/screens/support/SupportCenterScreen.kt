package com.example.ui.screens.support

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.core.model.SupportTicketDto
import com.example.core.model.UiState
import com.example.ui.components.BackendSetupRequiredBanner
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.theme.MonoMetricStyle

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SupportCenterScreen(
    supportState: UiState<List<SupportTicketDto>>,
    onRefresh: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var priorityFilter by remember { mutableStateOf("all") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("all", "critical", "high", "normal").forEach { p ->
                    FilterChip(
                        selected = priorityFilter == p,
                        onClick = { priorityFilter = p },
                        label = { Text(p.replaceFirstChar { it.uppercase() }) }
                    )
                }
            }
        }

        when (supportState) {
            UiState.Loading -> item { Text("Loading support tickets...", style = MaterialTheme.typography.bodyMedium) }
            is UiState.Error -> item {
                BackendSetupRequiredBanner(
                    moduleName = "Support & Feedback Center",
                    reason = supportState.message,
                    onOpenSettings = onOpenSettings,
                    onRetry = onRefresh
                )
            }
            is UiState.Success -> {
                val filtered = supportState.data.filter {
                    priorityFilter == "all" || it.priority.equals(priorityFilter, ignoreCase = true)
                }
                items(filtered, key = { it.id }) { ticket ->
                    EnterpriseGlassCard {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(ticket.subject, style = MaterialTheme.typography.titleMedium)
                                Text("${ticket.userEmail} · ${ticket.category}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            StatusPill(
                                ticket.priority.uppercase(),
                                when (ticket.priority.lowercase()) {
                                    "critical" -> PillTone.CRITICAL
                                    "high" -> PillTone.WARNING
                                    else -> PillTone.INFO
                                }
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Text("Status: ${ticket.status} · Created: ${ticket.createdAt}", style = MonoMetricStyle)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
