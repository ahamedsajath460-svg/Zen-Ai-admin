package com.example.core.network

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object NetworkClientFactory {

    val moshi: Moshi by lazy {
        Moshi.Builder()
            .addLast(KotlinJsonAdapterFactory())
            .build()
    }

    private val okHttpClient: OkHttpClient by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
            redactHeader("Authorization")
            redactHeader("X-Admin-Key")
        }
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val req = chain.request().newBuilder()
                    .header("Accept", "application/vnd.github+json, application/json")
                    .header("User-Agent", "Zen-Super-Admin-Control-Studio-Android/1.0")
                    .build()
                chain.proceed(req)
            }
            .addInterceptor(logging)
            .build()
    }

    val gitHubApi: GitHubApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.github.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GitHubApiService::class.java)
    }

    fun createBackendApi(baseUrl: String): ZenBackendApiService? {
        val trimmed = baseUrl.trim()
        if (trimmed.isBlank()) return null
        val normalized = if (trimmed.endsWith("/")) trimmed else "$trimmed/"
        if (!normalized.startsWith("https://") && !normalized.startsWith("http://10.0.2.2")) {
            return null
        }
        return try {
            Retrofit.Builder()
                .baseUrl(normalized)
                .client(okHttpClient)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(ZenBackendApiService::class.java)
        } catch (_: Exception) {
            null
        }
    }
}
