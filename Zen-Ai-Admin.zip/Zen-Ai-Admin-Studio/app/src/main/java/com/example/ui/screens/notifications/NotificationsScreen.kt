package com.example.ui.screens.notifications

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.core.model.NotificationCampaignDto
import com.example.core.model.UiState
import com.example.core.network.NotificationDispatchRequest
import com.example.ui.components.BackendSetupRequiredBanner
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.theme.MonoMetricStyle

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NotificationsScreen(
    notificationsState: UiState<List<NotificationCampaignDto>>,
    onSendCampaign: (NotificationDispatchRequest) -> Unit,
    onRefresh: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("announcement") }
    var audience by remember { mutableStateOf("all_users") }
    var filterValue by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            EnterpriseGlassCard {
                Text("FCM Announcement Composer", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Requires Firebase Cloud Messaging enabled on your Zen AI Firebase project & Backend Proxy.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("announcement", "maintenance", "update", "feature").forEach { t ->
                        FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t.replaceFirstChar { it.uppercase() }) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("all_users" to "All Users", "plan" to "Specific Plan", "app_version" to "App Version", "uids" to "Selected UIDs").forEach { (k, label) ->
                        FilterChip(selected = audience == k, onClick = { audience = k }, label = { Text(label) })
                    }
                }
                if (audience != "all_users") {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = filterValue,
                        onValueChange = { filterValue = it },
                        label = { Text("Target Filter (plan / version / comma UIDs)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Notification Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = body,
                    onValueChange = { body = it },
                    label = { Text("Message Body") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        onSendCampaign(
                            NotificationDispatchRequest(
                                title = title.trim(),
                                body = body.trim(),
                                type = type,
                                targetAudience = audience,
                                targetFilter = filterValue.ifBlank { "all" }
                            )
                        )
                    },
                    enabled = title.isNotBlank() && body.isNotBlank()
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Dispatch Campaign")
                }
            }
        }

        when (notificationsState) {
            UiState.Loading -> item { Text("Loading notification history...", style = MaterialTheme.typography.bodyMedium) }
            is UiState.Error -> item {
                BackendSetupRequiredBanner(
                    moduleName = "FCM Notification History",
                    reason = notificationsState.message,
                    onOpenSettings = onOpenSettings,
                    onRetry = onRefresh
                )
            }
            is UiState.Success -> {
                items(notificationsState.data, key = { it.id }) { item ->
                    EnterpriseGlassCard {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(item.title, style = MaterialTheme.typography.titleSmall)
                            StatusPill(item.status, if (item.failedCount > 0) PillTone.WARNING else PillTone.HEALTHY)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(item.body, style = MaterialTheme.typography.bodySmall)
                        Text(
                            text = "Target: ${item.targetAudience} · Delivered: ${item.deliveredCount} · Failed: ${item.failedCount}",
                            style = MonoMetricStyle,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
