package com.example.ui.screens.security

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.core.database.LocalAuditLogEntity
import com.example.core.database.WorkspaceConfigEntity
import com.example.core.security.AdminSessionState
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.theme.LocalZenStatusColors
import com.example.ui.theme.MonoMetricStyle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SecurityCenterScreen(
    sessionState: AdminSessionState,
    config: WorkspaceConfigEntity,
    localAuditLogs: List<LocalAuditLogEntity>,
    hasGitHubToken: Boolean,
    hasBackendToken: Boolean,
    onLockSessionNow: () -> Unit,
    modifier: Modifier = Modifier
) {
    val failedLogins = localAuditLogs.count { it.action.contains("FAILED") }
    val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            EnterpriseGlassCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("Hardware & Vault Posture", style = MaterialTheme.typography.titleMedium)
                    }
                    StatusPill(
                        if (sessionState.keystoreActive) "Keystore Active" else "Software Fallback",
                        if (sessionState.keystoreActive) PillTone.HEALTHY else PillTone.WARNING
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text("Cipher: AES-256-GCM (AndroidKeyStore) · Passphrase KDF: PBKDF2-HMAC-SHA256 (120,000 rounds)", style = MonoMetricStyle)
                Spacer(Modifier.height(4.dp))
                Text("Active Admin: ${sessionState.adminEmail} (${sessionState.activeRole.displayName})", style = MaterialTheme.typography.bodySmall)
                Text("Session Started: ${fmt.format(Date(sessionState.sessionStartedAtMillis))}", style = MonoMetricStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Session Timeout Policy: ${config.sessionTimeoutMinutes} minutes", style = MaterialTheme.typography.bodySmall)
            }
        }

        item {
            EnterpriseGlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Key, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    Spacer(Modifier.width(8.dp))
                    Text("Encrypted Token Inventory", style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("GitHub PAT (Optional Local)", style = MaterialTheme.typography.bodyMedium)
                    StatusPill(if (hasGitHubToken) "Encrypted in Keystore" else "Not Stored", if (hasGitHubToken) PillTone.HEALTHY else PillTone.NEUTRAL)
                }
                Spacer(Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Backend Proxy Bearer Token", style = MaterialTheme.typography.bodyMedium)
                    StatusPill(if (hasBackendToken) "Encrypted in Keystore" else "Not Stored", if (hasBackendToken) PillTone.HEALTHY else PillTone.NEUTRAL)
                }
                Spacer(Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Failed Auth / Re-Auth Attempts", style = MaterialTheme.typography.bodyMedium)
                    StatusPill("$failedLogins recorded", if (failedLogins > 0) PillTone.CRITICAL else PillTone.HEALTHY)
                }
            }
        }

        item {
            EnterpriseGlassCard {
                Text("Session & Re-Authentication Enforcement", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Destructive actions (user deletion, emergency AI provider shutdown, key rotation, workflow dispatch, and RBAC changes) require live passphrase re-authentication and generate immutable audit entries.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onLockSessionNow,
                    colors = ButtonDefaults.buttonColors(containerColor = LocalZenStatusColors.current.critical)
                ) {
                    Icon(Icons.Default.LockReset, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Revoke & Lock Current Session")
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
