package com.example.ui.screens.releases

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.core.model.AppReleaseDto
import com.example.core.model.UiState
import com.example.data.repository.GitHubSnapshot
import com.example.ui.components.BackendSetupRequiredBanner
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.theme.MonoMetricStyle

@Composable
fun AppReleasesScreen(
    releasesState: UiState<List<AppReleaseDto>>,
    gitHubState: UiState<GitHubSnapshot>,
    onRefresh: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenGitHub: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ghSnap = (gitHubState as? UiState.Success)?.data

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            EnterpriseGlassCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("CI/CD Build Pipeline Feed (GitHub Actions)", style = MaterialTheme.typography.titleMedium)
                    OutlinedButton(onClick = onOpenGitHub) { Text("GitHub Control") }
                }
                Spacer(Modifier.height(8.dp))
                if (ghSnap != null && ghSnap.workflowRuns.isNotEmpty()) {
                    ghSnap.workflowRuns.take(5).forEach { run ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${run.name ?: "Build"} #${run.run_number}", style = MaterialTheme.typography.bodyMedium)
                                Text("Branch: ${run.head_branch ?: "?"} · ${run.head_sha.take(7)}", style = MonoMetricStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            val conclusion = run.conclusion ?: run.status ?: "queued"
                            val tone = when (conclusion) {
                                "success" -> PillTone.HEALTHY
                                "failure", "cancelled" -> PillTone.CRITICAL
                                else -> PillTone.WARNING
                            }
                            StatusPill(conclusion, tone)
                        }
                    }
                } else {
                    Text(
                        text = "Link your Zen AI GitHub repository in GitHub Control to monitor live debug, release, and test Android builds.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        when (releasesState) {
            UiState.Loading -> item { Text("Loading release registry...", style = MaterialTheme.typography.bodyMedium) }
            is UiState.Error -> item {
                BackendSetupRequiredBanner(
                    moduleName = "App Version & Release Registry",
                    reason = releasesState.message,
                    onOpenSettings = onOpenSettings,
                    onRetry = onRefresh
                )
            }
            is UiState.Success -> {
                items(releasesState.data, key = { it.id }) { release ->
                    EnterpriseGlassCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("v${release.versionName} (${release.versionCode})", style = MaterialTheme.typography.titleMedium)
                                Text("Channel: ${release.channel} · Min Supported: v${release.minSupportedVersion}", style = MonoMetricStyle)
                            }
                            StatusPill(
                                text = if (release.mandatoryUpdate) "Mandatory" else release.approvalStatus,
                                tone = if (release.mandatoryUpdate) PillTone.WARNING else PillTone.INFO
                            )
                        }
                        if (release.releaseNotes.isNotBlank()) {
                            Spacer(Modifier.height(6.dp))
                            Text(release.releaseNotes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}
