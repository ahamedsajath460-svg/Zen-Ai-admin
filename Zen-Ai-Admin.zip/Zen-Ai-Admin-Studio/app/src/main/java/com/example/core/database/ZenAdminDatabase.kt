package com.example.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        WorkspaceConfigEntity::class,
        DashboardWidgetEntity::class,
        LocalAuditLogEntity::class,
        CachedOverviewEntity::class,
        LocalAdminNoteEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ZenAdminDatabase : RoomDatabase() {
    abstract fun adminDao(): ZenAdminDao

    companion object {
        @Volatile
        private var INSTANCE: ZenAdminDatabase? = null

        fun getInstance(context: Context): ZenAdminDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ZenAdminDatabase::class.java,
                    "zen_super_admin_cache.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
