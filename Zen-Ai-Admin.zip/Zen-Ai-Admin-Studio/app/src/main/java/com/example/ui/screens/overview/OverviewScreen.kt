package com.example.ui.screens.overview

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.core.database.DashboardWidgetEntity
import com.example.core.database.WorkspaceConfigEntity
import com.example.core.model.DateRangeFilter
import com.example.core.model.UiState
import com.example.ui.components.BackendSetupRequiredBanner
import com.example.ui.components.EnterpriseGlassCard
import com.example.ui.components.ExecutiveTrendChart
import com.example.ui.components.MetricKpiTile
import com.example.ui.components.PillTone
import com.example.ui.components.StatusPill
import com.example.ui.navigation.AdminModule
import com.example.ui.state.AdminDashboardUiState
import com.example.ui.theme.LocalZenStatusColors
import com.example.ui.theme.MonoMetricStyle

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OverviewScreen(
    uiState: AdminDashboardUiState,
    config: WorkspaceConfigEntity,
    widgets: List<DashboardWidgetEntity>,
    onSelectRange: (DateRangeFilter) -> Unit,
    onRefresh: () -> Unit,
    onToggleWidget: (String, Boolean) -> Unit,
    onNavigate: (AdminModule) -> Unit,
    onExportReport: () -> String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val statusColors = LocalZenStatusColors.current
    var showCustomizeDialog by remember { mutableStateOf(false) }

    val enabledIds = remember(widgets) { widgets.filter { it.enabled }.map { it.widgetId }.toSet() }
    val overviewData = (uiState.overviewState as? UiState.Success)?.data
    val ghData = (uiState.gitHubState as? UiState.Success)?.data

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(148.dp)
                    .clip(MaterialTheme.shapes.large)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_admin_hero_banner),
                    contentDescription = "Zen AI Super Admin Control Center",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    MaterialTheme.colorScheme.background.copy(alpha = 0.92f),
                                    MaterialTheme.colorScheme.background.copy(alpha = 0.45f)
                                )
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        StatusPill(
                            text = if (overviewData != null) "Cloud Backend Connected" else "Firebase Not Provisioned",
                            tone = if (overviewData != null) PillTone.HEALTHY else PillTone.WARNING
                        )
                        StatusPill(
                            text = if (ghData != null) "GitHub Live" else "GitHub Standby",
                            tone = if (ghData != null) PillTone.INFO else PillTone.NEUTRAL
                        )
                    }
                    Column {
                        Text(
                            text = "Executive Command Overview",
                            style = MaterialTheme.typography.headlineSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Remote telemetry, AI routing, GitHub CI/CD & governance for Zen AI",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        item {
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DateRangeFilter.entries.forEach { filter ->
                    FilterChip(
                        selected = uiState.dateRange == filter,
                        onClick = { onSelectRange(filter) },
                        label = { Text(filter.label) },
                        modifier = Modifier.testTag("overview_range_${filter.apiValue}")
                    )
                }
                Spacer(Modifier.width(4.dp))
                OutlinedButton(
                    onClick = onRefresh,
                    modifier = Modifier.testTag("overview_refresh_btn")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Refresh")
                }
                OutlinedButton(
                    onClick = { showCustomizeDialog = true },
                    modifier = Modifier.testTag("overview_customize_btn")
                ) {
                    Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Widgets")
                }
                OutlinedButton(
                    onClick = {
                        val json = onExportReport()
                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "application/json"
                            putExtra(Intent.EXTRA_SUBJECT, "Zen Admin Studio Executive Report")
                            putExtra(Intent.EXTRA_TEXT, json)
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "Export Sanitized Report"))
                    },
                    modifier = Modifier.testTag("overview_export_btn")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Export")
                }
            }
        }

        if (overviewData == null) {
            item {
                BackendSetupRequiredBanner(
                    moduleName = "Cloud Telemetry",
                    reason = (uiState.overviewState as? UiState.Error)?.message
                        ?: "Firebase setup declined and no Backend Proxy URL is configured.",
                    onOpenSettings = { onNavigate(AdminModule.SETTINGS) },
                    onRetry = onRefresh
                )
            }
        }

        if ("w_users" in enabledIds) {
            item {
                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                    val twoCols = maxWidth >= 560.dp
                    val totalUsers = overviewData?.totalUsers?.toString() ?: "—"
                    val activeUsers = overviewData?.activeUsers?.toString() ?: "—"
                    val newGrowth = if (overviewData != null) {
                        "+${overviewData.newUsersToday} today · +${overviewData.newUsersWeek} wk · +${overviewData.newUsersMonth} mo"
                    } else "Requires connected backend"
                    val suspendedDeleted = if (overviewData != null) {
                        "${overviewData.suspendedUsers} suspended · ${overviewData.deletedUsers} deleted"
                    } else "Presence & lifecycle awaiting backend"

                    if (twoCols) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            MetricKpiTile(
                                label = "Registered / Active Users",
                                value = "$totalUsers / $activeUsers",
                                subtitle = newGrowth,
                                icon = Icons.Default.Group,
                                modifier = Modifier.weight(1f)
                            )
                            MetricKpiTile(
                                label = "Online / Suspended / Deleted",
                                value = overviewData?.onlineUsers?.toString() ?: "N/A",
                                subtitle = suspendedDeleted,
                                icon = Icons.Default.Visibility,
                                tint = statusColors.warning,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricKpiTile(
                                label = "Registered / Active Users",
                                value = "$totalUsers / $activeUsers",
                                subtitle = newGrowth,
                                icon = Icons.Default.Group
                            )
                            MetricKpiTile(
                                label = "Online Presence & Account Status",
                                value = overviewData?.onlineUsers?.toString() ?: "N/A",
                                subtitle = suspendedDeleted,
                                icon = Icons.Default.Visibility,
                                tint = statusColors.warning
                            )
                        }
                    }
                }
            }
        }

        if ("w_ai_volume" in enabledIds) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricKpiTile(
                            label = "AI Conversations / Requests",
                            value = if (overviewData != null) "${overviewData.totalConversations} / ${overviewData.totalAiRequests}" else "—",
                            subtitle = "Total routed requests",
                            icon = Icons.Default.AutoAwesome,
                            modifier = Modifier.weight(1f)
                        )
                        MetricKpiTile(
                            label = "API Errors",
                            value = overviewData?.apiErrors?.toString() ?: "—",
                            subtitle = "Across active providers",
                            icon = Icons.Default.ErrorOutline,
                            tint = statusColors.critical,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricKpiTile(
                            label = "Image Gen",
                            value = overviewData?.imageGenRequests?.toString() ?: "—",
                            subtitle = "Visual generation",
                            icon = Icons.Default.Image,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.weight(1f)
                        )
                        MetricKpiTile(
                            label = "Screen Vision & Agent",
                            value = if (overviewData != null) "${overviewData.screenVisionRequests} / ${overviewData.agentControlRequests}" else "—",
                            subtitle = "Vision / Agent control",
                            icon = Icons.Default.SmartToy,
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
            item {
                ExecutiveTrendChart(points = overviewData?.dailySeries.orEmpty())
            }
        }

        if ("w_github" in enabledIds) {
            item {
                EnterpriseGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Code, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("GitHub Actions & Release Pulse", style = MaterialTheme.typography.titleMedium)
                        }
                        TextButton(onClick = { onNavigate(AdminModule.GITHUB_CONTROL) }) {
                            Text("Open GitHub")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    if (ghData != null) {
                        val latestRun = ghData.workflowRuns.firstOrNull()
                        val latestRelease = ghData.releases.firstOrNull()
                        Text(
                            text = "Repo: ${ghData.repo?.full_name ?: "${config.githubOwner}/${config.githubRepo}"} · Default branch: ${ghData.repo?.default_branch ?: "main"}",
                            style = MonoMetricStyle,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Latest Build: ${latestRun?.name ?: "None"} (#${latestRun?.run_number ?: 0}) · ${latestRun?.conclusion ?: latestRun?.status ?: "N/A"}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "Latest Release: ${latestRelease?.tag_name ?: overviewData?.latestAppVersion ?: "No published tag"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text(
                            text = "Configure GitHub Owner & Repository in Settings or GitHub Control to monitor live Android CI builds and artifacts.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        if ("w_health" in enabledIds) {
            item {
                EnterpriseGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Build, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                            Spacer(Modifier.width(8.dp))
                            Text("Live Infrastructure Probes", style = MaterialTheme.typography.titleMedium)
                        }
                        TextButton(onClick = { onNavigate(AdminModule.SYSTEM_MONITORING) }) {
                            Text("Diagnostics")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    uiState.healthProbes.forEach { probe ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(probe.serviceName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                Text(probe.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            val tone = when (probe.status) {
                                "Operational" -> PillTone.HEALTHY
                                "Degraded" -> PillTone.WARNING
                                "Setup Required" -> PillTone.WARNING
                                else -> PillTone.CRITICAL
                            }
                            StatusPill(
                                text = if (probe.latencyMs != null) "${probe.status} (${probe.latencyMs}ms)" else probe.status,
                                tone = tone
                            )
                        }
                    }
                }
            }
        }

        if ("w_alerts" in enabledIds) {
            item {
                EnterpriseGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("System Alerts", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    val alerts = overviewData?.alerts.orEmpty()
                    if (alerts.isEmpty()) {
                        Text(
                            text = if (overviewData == null) {
                                "Connect Backend Proxy to receive automated threshold and incident alerts."
                            } else {
                                "No active system incidents reported."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        alerts.forEach { alert ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(alert.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Text(alert.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                StatusPill(alert.severity, if (alert.severity.equals("critical", true)) PillTone.CRITICAL else PillTone.WARNING)
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }

    if (showCustomizeDialog) {
        AlertDialog(
            onDismissRequest = { showCustomizeDialog = false },
            title = { Text("Customize Dashboard Widgets") },
            text = {
                Column {
                    widgets.forEach { widget ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = widget.enabled,
                                onCheckedChange = { onToggleWidget(widget.widgetId, it) }
                            )
                            Text(widget.title, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCustomizeDialog = false }) { Text("Done") }
            }
        )
    }
}
