package com.example.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workspace_config")
data class WorkspaceConfigEntity(
    @PrimaryKey val id: Int = 1,
    val backendBaseUrl: String = "",
    val firebaseProjectId: String = "",
    val githubOwner: String = "",
    val githubRepo: String = "",
    val darkThemeEnabled: Boolean = true,
    val sessionTimeoutMinutes: Int = 30,
    val retentionPolicyDays: Int = 90,
    val maintenanceModeLocal: Boolean = false,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "dashboard_widgets")
data class DashboardWidgetEntity(
    @PrimaryKey val widgetId: String,
    val title: String,
    val enabled: Boolean,
    val sortOrder: Int
)

@Entity(tableName = "local_audit_logs")
data class LocalAuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val actorEmail: String,
    val actorRole: String,
    val action: String,
    val target: String,
    val outcome: String,
    val details: String,
    val timestampMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_overview")
data class CachedOverviewEntity(
    @PrimaryKey val id: Int = 1,
    val jsonPayload: String,
    val syncedAtMillis: Long
)

@Entity(tableName = "local_admin_notes")
data class LocalAdminNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val targetType: String,
    val targetId: String,
    val authorEmail: String,
    val noteBody: String,
    val createdAtMillis: Long = System.currentTimeMillis()
)
