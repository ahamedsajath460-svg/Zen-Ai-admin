-keepattributes Signature
-keepattributes *Annotation*
-keepclassmembers class * {
    @com.squareup.moshi.Json <fields>;
}
-keep class com.example.core.model.** { *; }
-keep class com.example.core.network.** { *; }
-keep class com.example.core.database.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn retrofit2.**
